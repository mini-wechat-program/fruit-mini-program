const outputRoot = 'dist';
const copyDist = ''; // /path_to_main_app_root/package_activity/garden

const replaceMap = {
    'dist/pages/index/index.js': [{
        search: /^"use strict";(?!require)/,
        replacer: '"use strict";require(\'../../app.js\');'
    }],
    'dist/app.js': [{
        search: /App\(require\(.\.\/npm\/@tarojs\/taro-weapp\/index\.js.\)\.default\.createApp\(_App\)\)./,
        replacer: ''
    }]
};

function adapter() {
    const fs = require('fs');
    const path = require('path');

    Object.keys(replaceMap).forEach(function (relativePath) {
       const filePath = path.resolve(__dirname, relativePath);
       let fileContent = fs.readFileSync(filePath).toString();
       
       replaceMap[relativePath].forEach(function (config) {
           fileContent = fileContent.replace(config.search, config.replacer);
       });

        fs.writeFileSync(filePath, fileContent);
    });
}

adapter();

if (copyDist) {
    require('child_process').exec(`rm -rf ${copyDist} && mkdir -p ${copyDist} && cp -f -r ${outputRoot}/* ${copyDist}`);
}