/**
 * 果园主页的通用请求
 * 
 */
import { baseRequest } from "../utils/requestUtil";
import { getAntiContent } from "../utils/garden/global";

/**
 * 完成任务后的请求
 * @param {number} missionType 任务类型
 * @param {Object} param {shareUid, friendUid, goodsID, rainGameScore}
 */
export const completeMission = (missionType, { shareUid, friendUid, goodsID, rainGameScore } = {}) => {
    const params = {
        'mission_type': missionType,
        'share_uid': shareUid,
        'friend_uid': friendUid,
        'mission_param': goodsID,
        'water_rain_score': rainGameScore,
    };
    return baseRequest(`api/manor/mission/complete?ts=${Date.now()}`, {
        params
    })
};

/**
 * 领水
 * @param {number} missionType 任务类型
 * @param {number}} gainTime 领取次数
 * @param {string} antiContent 风控字段
 */
export const gainWater = (missionType, gainTime = 1, antiContent) => {
    const params = {
        'mission_type': missionType,
        'gain_time': gainTime,
        'screen_token': antiContent,
    }
    return baseRequest('api/manor/water/gain', {
        params
    })
};

/**
 * 带风控的领水
 * @param {number} missionType 任务类型
 * @param {number} gainTime 领取次数
 */
export const gainWaterWithAnti = (missionType, gainTime) =>{
    return gainWater(missionType, gainTime, getAntiContent());
}