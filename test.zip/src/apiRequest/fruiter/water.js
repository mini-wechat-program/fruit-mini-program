import { baseRequest } from "../../utils/requestUtil";

export const costWater = (antContent) => {
    return baseRequest('api/manor/water/cost', {
        params: { 'screen_token': antContent }
    });
};

export function minusWaterCD(cdTime) {
    return baseRequest('api/manor/cost/water/speed', {
        params: {
            time: cdTime
        }
    });
};
