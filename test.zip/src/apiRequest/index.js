import { baseRequest } from "../utils/requestUtil";

// 任务领水接口调用
export const gainWater = ({ mission_type, gain_time, screen_token }) => {
    return baseRequest(`api/manor/water/gain`, {
        params: { mission_type, gain_time, screen_token }
    });
};

let _localTime0 = 0;
let _serverTime0 = 0;
export const getServerTime = ({ is_force_server = false }) => {
    // 强制获取服务器最新时间
    if (is_force_server || !_serverTime0) {
        return baseRequest(`api/server/_stm`, {
            params: {}
        }).then((data) => {
            let { server_time: serverTime } = (data || {});
            _localTime0 = Date.now();
            _serverTime0 = serverTime || _localTime0;
            resolve({ serverTime });
        }).catch((ex) => {
            _localTime0 = Date.now();
            _serverTime0 = _localTime0;
            resolve({
                serverTime: _serverTime0
            });
        });
    }
    return Promise.resolve({
        serverTime: _serverTime0 + (Date.now() - _localTime0)
    });

}