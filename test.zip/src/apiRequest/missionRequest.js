import { baseRequest } from "../utils/requestUtil";

// 获取果园任务列表信息
export const getMissionList = ({ shared_uid = '' } = {}) => {
    return baseRequest('api/manor/mission/list', {
        params: { shared_uid: shared_uid }
    });
};

// 
export const getWitheMission = () => {
    return baseRequest('api/manor-gateway/manor/query/withered/mission', {
        params: null
    });
}

// 任务完成接口调用
export const completeMission = ({ mission_type = 0 }) => {
    return baseRequest(`api/manor/mission/complete?ts=${Date.now()}`, {
        params: { mission_type: mission_type }
    });
};

// 任务领水接口调用
export const gainWater = ({ mission_type, gain_time, screen_token }) => {
    return baseRequest(`api/manor/water/gain`, {
        params: { mission_type, gain_time, screen_token }
    });
};