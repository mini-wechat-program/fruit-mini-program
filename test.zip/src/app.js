import Taro, { Component } from '@tarojs/taro';
import '@tarojs/async-await';
import { Provider } from '@tarojs/mobx';
import page from '@wx_common/page/index';
import request from '@wx_common/baseRequest/baseRequest';
import user from '@wx_common/user/index';
import util from '@wx_common/util/page_util'

import { globalStore } from './store/userInfo';

import './app.scss';
import Index from './pages/index';
import UserStorage from './wx_common/storage/user_storage';


// console.log(util.getPageInfo())

// page.prepare().then(() => {
//     console.log('request')
//     const accessToken = UserStorage.getAccessToken()
//     console.log(accessToken)
//     request.apiRequest('POST', 'https://api.pinduoduo.com/api/manor-gateway/manor/query/new/user/plant/info', {}, data => {
//         wx.showToast({
//             title: 'success'
//         })
//         console.log('data...', data)
//     }, err => {
//         wx.showToast({
//             title: 'error'
//         })
//         console.log('error...', err)
//     })
// }).catch(e => {
//     console.log('error', e)
// })

// 如果需要在 h5 环境中开启 React Devtools
// 取消以下注释：
// if (process.env.NODE_ENV !== 'production' && process.env.TARO_ENV === 'h5')  {
//   require('nerv-devtools')
// }

const store = {
    globalStore
};

class App extends Component {
  config = {
      pages: [
          'pages/index/index',
          'pages/garden/garden', // 本地测试使用，上线删除
      ],
      window: {
          backgroundTextStyle: 'light',
          navigationBarBackgroundColor: '#fff',
          navigationBarTitleText: 'WeChat',
          navigationBarTextStyle: 'black'
      }
  }

  componentDidMount () {
  }

  componentDidShow () {}

  componentDidHide () {}

  componentDidCatchError () {}

  // 在 App 类中的 render() 函数没有实际作用
  // 请勿修改此函数
  render () {
      return (
          <Provider store={store}>
              <Index />
          </Provider>
      );
  }
}

Taro.render(<App />, document.getElementById('app'));
