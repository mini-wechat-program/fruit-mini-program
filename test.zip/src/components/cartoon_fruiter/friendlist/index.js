import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import { imageUtil } from '@utils/imageUtil';
import { observer, inject } from '@tarojs/mobx'
import firendListStore from './store'

import { getFriendList } from './request'

import './index.scss';

const TREE_TYPE_MAP = {
    1: 'Apple',
    2: 'Pear',
    3: 'Orange',
    4: 'Mango',
    5: 'Papaya',
    6: 'Lemon',
    7: 'Kiwi',
    8: 'Shiliu',
    9: 'Youzi',
    10: 'Hetao',
    11: 'Hongzao',
    12: 'Chengzi',
};

const INVITE_AWARD_AMOUNT = 35;

@observer
class FriendList extends Component {
    constructor(props) {}

    componentDidMount = () => {
        getFriendList().then((data) => {
            firendListStore.init(data)
        })
    }

    toFriendGarden = (item) => {
        firendListStore.setCurrentUid(item.uid);
    }

    render () {
        const arr = firendListStore.friendList || []
        const currentUid = firendListStore.currentUid
        return (
            firendListStore.ifShow && <View className='friend-list-wrapper'>
                <View className='friend-list-container'>
                    {arr.map((item, index) => {
                        return (
                            <View key={index} className='friend-list-item' onClick={this.toFriendGarden.bind(this, item)}>
                                {currentUid === item.uid ? <Image className='friend-avatar-select' src={item.avatar} /> : <Image className='friend-avatar' src={item.avatar} />}
                                {item.type === 0 ? <View className='friend-unplant'>
                                    <View className='friend-unplant-award'>{INVITE_AWARD_AMOUNT}g</View>
                                    <Image className='friend-unplant-img' src={imageUtil('avatar-drip')} />
                                </View> : <Image className='friend-fruit' src={imageUtil('fl' + TREE_TYPE_MAP[item.type] + 'Mature')} />}
                                <View className='friend-name' style={{ color: currentUid === item.uid ? '#FFC423' : '#DBDBDB' }}>{item.nickname}</View>
                            </View>
                        )
                    })}
                </View>
            </View>
        );
    }
}

export default FriendList;