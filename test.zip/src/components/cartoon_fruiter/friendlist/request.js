import { baseRequest } from "@utils/requestUtil";

// 查询好友列表
export const getFriendList = () => {
    return baseRequest('api/manor/friend/list', {})
};