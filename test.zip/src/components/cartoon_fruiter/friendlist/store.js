import { observable, action } from 'mobx';

class firendListStore {
    @observable ifShow = false;
    @observable friendList = [];
    @observable currentUid = 0;

    @action
    init = (data) => {
        this.friendList = data.friend_list
        this.showPanel()
    }

    @action
    showPanel = () => {
        this.ifShow = true;
    }

    @action
    setCurrentUid = (uid) => {
        this.currentUid = uid;
    }
}

export default firendListStore = new firendListStore()