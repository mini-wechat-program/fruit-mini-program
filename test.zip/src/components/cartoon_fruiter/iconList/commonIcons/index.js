import Taro, { Component } from '@tarojs/taro'
import { View, Image } from '@tarojs/components'
import { observer, inject } from '@tarojs/mobx'
import iconsControlStore from '../iconsControl'
import { imageUtil } from '@utils/imageUtil';
import ICON_LIST from '../constants'
import missionListStore from '../../missionlist/store'

import './index.scss'

@observer
export default class CommonIcons extends Component {

    constructor(props) {
        this.treeLevel = 3;
        this.isMyGarden = true;
    }

    componentWillMount() {  }

    componentDidMount() { 
        if (this.isMyGarden) {
            iconsControlStore.addCommonIcon(ICON_LIST[4])
            iconsControlStore.addCommonIcon(ICON_LIST[5])
        }
        if (this.treeLevel > 3) {
            iconsControlStore.addCommonIcon(ICON_LIST[6])
        }
    }

    // 处理图标点击逻辑
    iconClick = (item) => {
        if (item.type === 5) {
            missionListStore.onShow()
        }
        console.log('图标类型:', item.name);
    }

    render() {
        const commonIconList = iconsControlStore.commonIconList || [];
        return (
            <View className='common-icons-container'>
                {commonIconList.map((item, index) => {
                    return (
                        <View key={index} className='common-icons-item' onClick={this.iconClick.bind(this, item)}>
                            <Image className='common-icon' src={imageUtil(item.imgSrc)} />
                            <View className='common-icon-text' style={{ 'top': Taro.pxTransform(item.toTop) }}>{item.text}</View>
                        </View>
                    )
                })}
            </View>
        )
    }
}