const ICON_LIST = {
    4: {
        imgSrc: 'message_v3',
        tapUrl: '111',
        type: 4,
        name: '动态'
    },
    5: {
        imgSrc: 'getWater_v3',
        tapUrl: '222',
        type: 5,
        name: '领水滴'
    },
    6: {
        imgSrc: 'amusement_icon',
        tapUrl: '333',
        type: 6,
        name: '水滴娱乐'
    },
    13: {
        imgSrc: 'highWaterIcon_v4',
        tapUrl: '333',
        type: 13,
        name: '高额奖励任务'
    },
    15: {
        imgSrc: 'extraWaterMissionToComplete',
        tapUrl: '333',
        type: 15,
        name: '额外水滴任务',
        text: '200g水滴'
    },
    21: {
        imgSrc: 'high-water-invite',
        tapUrl: '333',
        type: 21,
        name: '高额邀请任务',
        text: '100g水滴'
    },
    23: {
        imgSrc: 'forceContactIcon_v2',
        tapUrl: '333',
        type: 23,
        name: '强关icon'
    },
    30: {
        imgSrc: 'help-icon-v2',
        tapUrl: '333',
        type: 30,
        name: '助力领水',
        text: '助力领水'
    },
    31: {
        imgSrc: 'downloadMissionIcon_v2',
        tapUrl: '333',
        type: 31,
        name: '新人导下载'
    },
    34: {
        imgSrc: 'collection',
        tapUrl: '333',
        type: 34,
        name: '收藏果园链接'
    },
    37: {
        imgSrc: 'fertilizer_gift_icon',
        tapUrl: '333',
        type: 37,
        name: '化肥大礼包',
        text: '化肥礼包'
    },
    'new_fruiter': {
        imgSrc: 'newFruitIconV2',
        tapUrl: '333',
        type: 'new_fruiter',
        name: '解锁新果树'
    },
    'fresher_limited': {
        imgSrc: 'fresherLimited',
        tapUrl: '333',
        toTop: '50',
        type: 'fresher_limited',
        name: '新用户专享'
    },
    'fruit_shop': {
        imgSrc: 'fruitShop_v2',
        tapUrl: '111',
        toTop: '50',
        type: 'fruit_shop',
        name: '水果摊'
    },
    'garden_coupons_card': {
        imgSrc: 'gardenCouponsCard_v3',
        tapUrl: '111',
        toTop: '50',
        type: 'garden_coupons_card',
        name: '优惠券'
    }
}

export default ICON_LIST
