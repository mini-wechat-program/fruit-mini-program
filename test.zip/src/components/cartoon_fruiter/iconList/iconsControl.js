import { observable, action, computed, get } from 'mobx';
import ICON_LIST from './constants'

class iconsControlStore {
    @observable missionIconList = [];
    @observable commonIconList = [];

    @action
    init = () => {
        this.missionIconList = []
        this.commonIconList = []
    }

    // 按需加载图标
    @action
    addCommonIcon = (src) => {
        this.commonIconList = this.commonIconList.concat(src)
    }

    @action
    addMissionIcon = (src) => {
        this.missionIconList = this.missionIconList.concat(src)
    }

    // 领取完任务奖励后移除icon
    @action
    rermoveMissionIcon = (type) => {
        for (let i = 0; i < this.missionIconList.length; i++) {
            if (this.missionIconList[i].type === type) {
                this.missionIconList.splice(i, 1);
            }
        }
    }
}

export default iconsControlStore = new iconsControlStore()