import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import { MissionIcons } from './missionIcons/index'
import { CommonIcons } from './commonIcons/index'

import iconsControlStore from './iconsControl'

import './index.scss';

class IconList extends Component {
    constructor(props) {
        iconsControlStore.init()
    }

    render () {
        return (
            <View>
                <MissionIcons />
                <CommonIcons />
            </View>
        );
    }
}

export default IconList;
