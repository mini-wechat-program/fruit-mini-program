import Taro, { Component } from '@tarojs/taro'
import { View, Image } from '@tarojs/components'
import { observer, inject } from '@tarojs/mobx'
import navigation from '@wx_common/navigation';

import iconsControlStore from '../iconsControl'
import { imageUtil } from '@utils/imageUtil';
import ICON_LIST from '../constants'
import missionListStore from '../../missionlist/store';
import { ifShowIcon } from '@utils/garden/missionUtil'
import { getCouponsData } from '../request'

import './index.scss'

@observer
export default class MissionIcons extends Component {

    constructor(props) {
        this.missionList = missionListStore.list;
    }

    componentWillMount() { }

    componentDidMount() {
        this.initOtherIcon()
        this.initMissionIcon()

        getCouponsData().then((data) => {
            this.initCouponsData(data)
        })
    }

    // 渲染右侧除任务外其他Icon
    initOtherIcon = () => {
        const otherIconList = ['fruit_shop'];
        otherIconList.map((item, index) => {
            ICON_LIST[item].missionStatus = 1;
            iconsControlStore.addMissionIcon(ICON_LIST[item])
        })
    }

    // 初始化右侧任务图标
    initMissionIcon = () => {
        // 可展示任务列表
        const missionTypeList = [13, 15, 21, 23, 30, 31, 34, 37];
        missionTypeList.map((item, index) => {
            const misssionStatus = ifShowIcon(this.missionList, item, 1544630300);
            if (misssionStatus === 1) {
                !ICON_LIST[item].text && (ICON_LIST[item].text = this.missionList[item].reward_amount + 'g');
                ICON_LIST[item].toTop = 76;
                ICON_LIST[item].missionStatus = 1;
                iconsControlStore.addMissionIcon(ICON_LIST[item])
            } else if (misssionStatus === 2) {
                !ICON_LIST[item].text && (ICON_LIST[item].text = '可领取');
                ICON_LIST[item].toTop = 76;
                ICON_LIST[item].missionStatus = 2;
                iconsControlStore.addMissionIcon(ICON_LIST[item])
            }
        })
    }

    // 初始化优惠券图标
    initCouponsData = (data) => {
        if (data.platform_coupons && data.platform_coupons[0]) {
            const iconInfo = ICON_LIST['garden_coupons_card'];
            iconInfo.text = '￥' + data.platform_coupons[0].discount / 100;
            iconInfo.toTop = 40;
            iconInfo.missionStatus = 1;
            iconsControlStore.addMissionIcon(iconInfo);
        }
    }

    iconClick = (item) => {
        if (item.type === 'fruit_shop') {
            navigation.forward(`cartoon_fruit_goods.html?page=1&size=20&opt_id=13&scene_id=59&only_fruit=1&app_name=ddgy_fruit`);
        }
        if (item.missionStatus === 1) {
            console.log(item.name, '任务正在进行...');
        } else if (item.missionStatus === 2) {
            iconsControlStore.rermoveMissionIcon(item.type);
            console.log(item.name, '任务已完成！');
        }
    }

    render() {
        const missionIconList = iconsControlStore.missionIconList || [];
        return (
            <View className='mission-icons-container'>
                {missionIconList.map((item, index) => {
                    return (
                        <View key={index} className='mission-icons-item' onClick={this.iconClick.bind(this, item)}>
                            <Image className='misssion-icon' src={imageUtil(item.imgSrc)} />
                            <View className='misssion-icon-text' style={{ 'top': Taro.pxTransform(item.toTop) }}>{item.text}</View>
                        </View>
                    )
                })}
            </View>
        )
    }
}