import { baseRequest } from "@utils/requestUtil";

// 查询优惠券信息
export const getCouponsData = () => {
    return baseRequest('api/lisbon/query_usable_duo_duo_orchard_coupon', {})
};