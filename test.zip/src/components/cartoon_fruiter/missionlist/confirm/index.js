import Taro, { Component, Button } from '@tarojs/taro';
import { Text } from '@tarojs/components';
import './index.scss';

class Confirm extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount () {

    }
  
    componentWillUnmount () { 

    }
    render() {
        return <View className='confirm-container'>
            <View className='confirm-body'>
                <View className='confirm-close' onClick={this.onClose}></View>
                <View className='confirm-title'>每天5次定时领水</View>
                <View className='confirm-content'>
                    <Text>奖励10-20g</Text>
                    <Text className='water-img'></Text>
                    <Text>,间隔10分钟</Text>
                </View>
                <Button className='button' onClick={this.onConfirm}>确定领取</Button>
            </View>
        </View>
    }
    onClose = (ev) => {
        (ev || {}).stopPropagation && ev.stopPropagation();
        this.props.onClose && this.props.onClose();
    }
    onConfirm = (ev) => {
        (ev || {}).stopPropagation && ev.stopPropagation();
        this.props.onConfirm && this.props.onConfirm();
    }
}

export default Confirm;
