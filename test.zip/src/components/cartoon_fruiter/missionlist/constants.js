// 任务KEY和ID映射关系
export const MISSION_KEYS_2_ID = {
    'SHARE': 1, // 每日领水任务
    'COLLECTION': 2, // 收藏任务
    'COLLAGE': 3, // 成功拼团
    'INVITE_DOWNLOAD': 4, // 拉新
    'INVITE': 5, // 邀请
    'UPGRADE': 6, // 升级
    'VISIT_FRIEND': 7, // 拜访好友
    'NEW_USER_AGAIN_LOGIN': 8, // 新用户再次登录
    'BROWSE_GOODS': 9, // 浏览商品
    'WATER': 10, // 随机触发送水滴
    'PLATFORM_COUPON': 11, // 随机触发送平台无门槛券
    'MERCHANT_COUPON': 12, // 随机触发送店铺商品券
    'TIME_LIMIT_WATER': 13, // 限时拼单送水滴
    'LIMIT_TIME_SHARE': 14, // 福袋定时分享
    'EXTRA_WATER': 15, // 额外水滴
    'NEW_USER_ADVERT_ORDER': 16, // 新人首单拼团页拼单送水滴
    'NEW_USER_ZONE_ORDER': 17, // 新人专区页拼单送水滴
    'BROWSE_GOODS_ONE_MINUTE': 18, // 浏览商品一分钟
    'COST_WATER_FOR_WITHERED_FRIEND': 19, // 给枯萎好友浇水
    'LIMIT_TIME_TWO_SHARE': 20, // 二次定时福袋分享
    'RANDOM_INVITE_WATER': 21, // 随机触发邀请送水滴
    'NEXT_DAY_LOGIN_REWARD_FOR_WITHERED_PRODUCT': 22, // 给枯萎果树浇水生成第二天登录奖励任务
    'SUBSCRIBE_OFFICIAL_ACCOUNTS': 23, // 关注微信公众号送水滴
    'SET_FLOAT_WINDOW': 24, // 设置浮窗送水滴
    'POOR_ORCHARD_WATER': 25, // 贫困果农页面拼单送水滴
    'SEVEN_DAY_NO_COST_WATER': 26, // 用户七天没有浇水送水滴
    'FERTILIZER_INVITE': 27, // 化肥邀请任务
    'CLEARANCE_INVITE': 28, // 闯关邀请任务
    'BROWSE_GOODS_ONE_MINUTE_TWICE_PER_DAY': 29, // 浏览商品一分钟每天两次间隔三小时
    'FRIEND_ASSIST_REWARD_WATER': 30, // 好友助力送水滴
    'NEW_PERSON_GO_APP_REWARD_WATER': 31, // 新人去app领取水滴任务
    'SHARE_INVITE_WITHERED_FRIEND_REWARD_WATER': 32, // 分享邀请枯萎好友浇水任务
    'THREE_NOT_LOGIN_GARDEN_REWARD_WATER': 33, // 三日未登录果园水滴任务
    'FAVORATE': 34, // 收藏果园链接任务
    'WATER_RAIN': 35, // 水滴雨任务
    'VISUALIZATION_GROUP': 36, // 可视化页面拼单
    'WEEK_CARD': 39, // 周卡活动任务
};

// 任务ID和全局配置名称映射
export const MISSION_ID_2_CONFIG_NAME = {
    1: 'SHARE_GAIN_WATER',
    4: 'INVITE_FRIEND_DOWNLOAD',
    5: 'INVITE_FRIEND_CREATE_TREE',
    14: 'LIMIT_TIME_SHARE',
    19: 'INVITE_FRIEND_COST_WATER_POPWINDOW',
    20: 'SECOND_LIMIT_TIME_SHARE_DOUBLE',
    21: 'TIME_LIMIT_INVITE',
    27: 'FERTILIZER_INVITE_FRIEND',
    28: 'CLEARANCE_INVITE_FRIEND',
    30: 'FRIEND_ASSIST_REWARD_WATER',
    31: 'NEW_USER_APP_GAIN_WATER',
    32: 'INVITE_FRIEND_COST_WATER',
};
export const MISSION_2_SCENE = {
    3: {
        // 指定页面拼单成团
        scene_id: 58,
        app_name: 'normal_order',
        page_type: 'group',
        dest_mission: 'normal_order'
    },
    18: {
        // 每日2次浏览商品1分钟
        scene_id: 65,
        app_name: 'ddgy_view_1min',
        page_type: 'scan',
        dest_mission: 'extra_water'
    },
    '29-0': {
        // 每日2次浏览商品1分钟(第1次)
        scene_id: 99,
        app_name: 'ddgy_view_twice',
        page_type: 'scan',
        dest_mission: 'extra_water'
    },
    29: {
        // 每日2次浏览商品1分钟(非第1次)
        scene_id: 101,
        app_name: 'ddgy_view_second',
        page_type: 'scan',
        dest_mission: 'extra_water'
    },
    39: {
        // 水滴周卡任务
        scene_id: 122,
        app_name: 'ddgy_week_vip',
        page_type: 'group',
        dest_mission: 'water_week_card'
    },
}

export const MISSION_LIST_CONFIG = {
    1: {
        type: 1,
        imageName: 'missionShare_v2',
        mainDesc: '每日免费领水',
        subDesc: ['奖励${min_reward_amount}-${max_reward_amount}g', '水滴', '，每天${max_count}次'],
        btnTxt: '去完成'
    },
    9: {
        type: 9,
        imageName: 'scanGoods',
        mainDesc: '点击浏览商品',
        subDesc: ['奖励${reward_amount}g', '水滴', '，每天${max_count}次'],
        btnTxt: '去完成'
    },
    2: {
        type: 2,
        imageName: 'missionCollect',
        mainDesc: '收藏商品',
        subDesc: ['成功收藏1件商品', '奖励${reward_amount}g,每天${max_count}次'],
        btnTxt: '去完成'
    },
    3: {
        type: 3,
        imageName: 'missionPin_v3',
        mainDesc: '指定页面拼单成团',
        subDesc: ['奖励${reward_amount}g', '水滴', '，每天${max_count}次'],
        btnTxt: '去拼单'
    },
    4: {
        type: 4,
        imageName: 'missionInviteDownload_v3',
        mainDesc: '邀请好友下载APP',
        subDesc: ['奖励${reward_amount}g', '水滴', '，次数不限'],
        btnTxt: '去完成'
    },
    5: {
        type: 5,
        imageName: 'missionInviteJoin_v3',
        mainDesc: '邀请好友来种树',
        subDesc: ['奖励${reward_amount}g', '水滴', '，次数不限'],
        btnTxt: '去邀请'
    },
    14: {
        type: 14,
        imageName: 'noonNightMission_v2',
        mainDesc: '每日三餐开福袋',
        subDesc: ['7-9点，12-14点，18-21点'],
        subDesc2: ['开启福袋可得${min_reward_amount}-${max_reward_amount}g', '水滴'],
        btnTxt: '开福袋'
    },
    18: {
        type: 18,
        imageName: 'missionScanTime_v2',
        mainDesc: '浏览商品1分钟',
        subDesc: ['奖励${reward_amount}g', '水滴', '，每天${max_count}次'],
        btnTxt: '去完成'
    },
    25: {
        type: 25,
        imageName: 'missionDevote_v2',
        mainDesc: '${activity_name}',
        subDesc: ['奖励${reward_amount}g', '水滴', '，每天${max_count}次'],
        btnTxt: '去拼单'
    },
    29: {
        type: 29,
        imageName: 'missionScanTime_v2',
        mainDesc: '浏览商品1分钟',
        subDesc: ['奖励${reward_amount}g', '水滴', '，每天${max_count}次'],
        btnTxt: '去完成'
    },
    32: {
        type: 32,
        imageName: 'missionWakeup',
        mainDesc: '邀请好友回来浇水',
        subDesc: ['奖励${reward_amount}g', '水滴', '，次数不限'],
        btnTxt: '去邀请'
    },
    35: {
        type: 35,
        imageName: 'missionRainGame',
        mainDesc: '收集水滴雨',
        subDesc: ['最多可得${max_reward_amount}g', '水滴', '，每天${max_count}次'],
        btnTxt: '去完成'
    },
    39: {
        type: 39,
        imageName: 'weeklyMission',
        mainDesc: '水滴周卡福利',
        subDesc: ['连续7天，每天可领${reward_amount}g', '水滴'],
        btnTxt: '去完成'
    },
    'app': {
        type: 'app',
        imageName: 'missionDownload_v2',
        mainDesc: '下载APP',
        subDesc: ['微信登录可领${reward_amount}g', '水滴'],
        btnTxt: '去下载'
    }
};


export const MISSION_CONFIG = {
    'INVITE_FRIEND_CREATE_TREE': {
        'need_share': true,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'INVITE_FRIEND_DOWNLOAD': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'FREE_LOTTERY': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'FRIEND_ASSIST_REWARD_WATER': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'WATER_RAIN_SECOND_START': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'WATER_RAIN_FIRST_RESULT': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'COMPOSITION': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'SECOND_LIMIT_TIME_SHARE_DOUBLE': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'SHARE_GAIN_WATER': {
        'need_share': true,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': {
            'SHARE_RULE': ['SHARE_NEED', 'SHARE_NEED', 'SHARE_NEED', 'SHARE_NEED', 'SHARE_NEED']
        }
    },
    'LOTTERY_RESULT': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'FERTILIZER_INVITE_FRIEND': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'WATER_RAIN_SECOND_RESULT': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'SELF_DOWNLOAD': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'SHOW_FRIEND_DYNAMIC': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'NEW_USER_APP_GAIN_WATER': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'SHOW_FRIEND_LIST': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'BET_REWARD': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'FREE_BALLOT': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'ADD_FRIEND': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'CLEARANCE_REWARD': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'SEND_RED_ENVELOPE': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'ACHIEVEMENT_REWARD': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'SHOW_NO_TREE_FRIEND': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'UPGRADE': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'INVITE_FRIEND_COST_WATER': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'INVITE_FRIEND_COST_WATER_POPWINDOW': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'LIMIT_TIME_SHARE': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'CLEARANCE_INVITE_FRIEND': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'TIME_LIMIT_INVITE': {
        'need_share': false,
        'show_icon': false,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    },
    'BALLOT_RESULT': {
        'need_share': false,
        'show_icon': true,
        'show_text': false,
        'show_method': 'link',
        'other': ''
    }
};