import Taro, { Component } from '@tarojs/taro';
import { View, ScrollView, Text, Image } from '@tarojs/components';
import { observer } from '@tarojs/mobx';
import ui from '@wx_common/ui/index';
import urlUtil from '@wx_common/commonUrl';
import navigation from '@wx_common/navigation';
import Anti from '@wx_common/risk-control-anti';
import { missionList as shareList } from '@wx_common/share/shareInfo';
import missionListStore from './store';
import Timer from './timer/index';
import Confirm from './confirm/index';
import Warn from './warn/index';
import { formatTime } from '@utils/util';
import { gainWater, getServerTime } from '@apiRequest/index';
import { completeMission } from '@apiRequest/missionRequest';
import { MISSION_2_SCENE, MISSION_ID_2_CONFIG_NAME, MISSION_CONFIG } from './constants';
import { gainBlessStore } from '../popups/blessBag/gainBlessBag/store';
import './index.scss';

/** 任务点击处理逻辑函数映射 */
const missionClickHander = {
    '1': 'mission1Handler',
    '3': 'mission3Handler',
    '5': 'mission5Handler',
    '14': 'mission14Handler',
    '18': 'mission18Handler',
    '25': 'mission25Handler',
    '29': 'mission29Handler',
    '32': 'mission32Handler',
    '39': 'mission39Handler',
};

/** 任务状态处理逻辑函数映射 */
const missionStatusHander = {
    '1': 'mission1Status',
    '14': 'mission14Status',
    '18': 'mission18Status',
    '25': 'mission25Status',
    '29': 'mission29Status',
    '35': 'mission35Status',
    '39': 'mission39Status',
};

// 福袋定时分享任务处理逻辑
const missionTimes = [[7, 8], [12, 13], [18, 19, 20]]; 

@observer
class MissionList extends Component {
    constructor(props) {
        // TO DO:
        this.state = {
            isDialog: false,
            isWarn: false
        };
    }
    componentDidMount() {
        const options = {
            serverTime: missionListStore.serverTime * 1000 || Date.now()
        };
        this.riskControlCrawler = new Anti(options);
    
    }
    onHide = () => {
        missionListStore.onHide();
    }

    onShow = () => {
        missionListStore.onShow();
    }

    formatSubDesc = (desc, mission) => {
        const { type, max_count, reward_amount, min_reward_amount, max_reward_amount } = (mission || {});
        
        let formatStr = (desc || '').replace(/\$\{reward_amount\}/ig, reward_amount)
            .replace(/\$\{max_count\}/ig, max_count)
            .replace(/\$\{min_reward_amount\}/ig, min_reward_amount)
            .replace(/\$\{max_reward_amount\}/ig, max_reward_amount);
        if (Number(type) === 25) {
            const activityName = missionListStore.poorActivityName || '献爱心拼单助农';
            formatStr = formatStr.replace(/\$\{activity_name\}/ig, activityName);
        }
        return formatStr;
    }
    imageUrl = (imageName) => {
        return `http://pinduoduoimg.yangkeduo.com/cartoon_activity/fruiter/${imageName}.png`;
    }
    missionShareRule = (mission) => {
        const missionToShare = [1, 5]; // 需要判断的任务ID
        const {
            type: key,
            completed_count: completeCnt,
            drawed_count: drawCnt
        } = mission;

        let oShare = {
            isShare: false,
            shareType: ''
        };
        if (missionToShare.indexOf(Number(key)) < 0) {
            return oShare;
        }
        const kName = MISSION_ID_2_CONFIG_NAME[key] || '';
        const {
            need_share: isNeedShare,
            other
        } = (MISSION_CONFIG[kName] || {});
        

        const shareRules = (other || {})['SHARE_RULE'] || [];
        if (!isNeedShare) {
            return oShare;
        }
        const mCompleted = Number(completeCnt) || Number(drawCnt) || 0;
        const shareType = (shareRules[mCompleted] || '').trim().toUpperCase() || 'SHARE_NEED';
        return {
            isShare: shareType === 'SHARE_NEED',
            shareType: 'SHARE_NEED'
        };
    };
    missionStatus = (mission) => {
        const type = mission['type'];

        const { type: key } = (mission || {});
        const mapConfig = missionListStore.mapConfig || {};
        let { btnTxt } = (mapConfig[key] || {});
        btnTxt = btnTxt || '去完成';

        let oStatus = {
            isTitleCutdown: false,
            isBtnCutdown: false,
            btnStatus: 10,  // 任务默认状态: [10-20) 可领取水滴状态: [20-30) 已领取水滴: [30-xxx)
            btnTitle: [],
            btnText: [btnTxt]
        };

        if (this[missionStatusHander[type]]) {
            return this[missionStatusHander[type]](mission);
        }

        // 任务的默认处理逻辑
        const finishCnt = Number(mission['finished_count']) || 0;
        const drawCnt = Number(mission['drawed_count']) || 0;
        const maxCnt = Number(mission['max_count']) || 0;
        if (drawCnt < finishCnt) {
            // 可领取水滴
            oStatus = {
                ...oStatus,
                btnStatus: 20,
                btnTitle:[],
                btnText: ['领取']
            }
            return oStatus;
        }
        if (finishCnt >= maxCnt && maxCnt > 0) {
            oStatus = {
                ...oStatus,
                btnStatus: 30,
                btnTitle: ['明日再来'],
                btnText: []
            }
        }
        return oStatus;
    }
    mission1Status = (mission) => {
        // 每日分享领水任务处理逻辑
        const nextTime = Number(mission['next_available_time']) || 0;
        const minAmount = Number(mission['min_reward_amount']) || 0;
        const maxAmount = Number(mission['max_reward_amount']) || 0;
        const finishCnt = Number(mission['finished_count']) || 0;
        const drawCnt = Number(mission['drawed_count']) || 0;
        const maxCnt = Number(mission['max_count']) || 0;

        const { type: key } = (mission || {});
        const mapConfig = missionListStore.mapConfig || {};
        let { btnTxt } = (mapConfig[key] || {});
        btnTxt = btnTxt || '去完成';

        let oStatus = {
            isTitleCutdown: false,
            isBtnCutdown: false,
            btnStatus: 10,
            btnTitle: [],
            btnText: [btnTxt]
        };
        const secServerTime = missionListStore.serverTime;    // 要获取真实服务器时间
        if (drawCnt < finishCnt) {
            // 可领取水滴
            oStatus = {
                ...oStatus,
                btnStatus: 20,
                btnTitle:['水滴', `${minAmount}-${maxAmount}g`],
                btnText: ['领取']
            }
            return oStatus;
        }
        if (finishCnt < maxCnt) {
            // 还可继续完成任务
            if (nextTime - secServerTime >= 1) {
                oStatus = {
                    ...oStatus,
                    isBtnCutdown: true,
                    btnStatus: 30,
                    btnTitle: ['水滴', `${minAmount}-${maxAmount}g`],
                    btnText: ['后可领取']
                }
            }
        } 
        if (finishCnt >= maxCnt){
            // 任务已全部完成
            oStatus = {
                ...oStatus,
                btnStatus: 30,
                btnTitle: ['明日再来'],
                btnText: []
            }
        }
        return oStatus;
    }
    mission14Status = (mission) => {
        const secServerTime = missionListStore.serverTime; // 获取真实服务器时间
        const finishCnt = Number(mission['finished_count']) || 0;
        const drawCnt = Number(mission['drawed_count']) || 0;
        const maxCnt = Number(mission['max_count']) || 0;

        const { type: key, next_available_time: nextTime } = (mission || {});
        const mapConfig = missionListStore.mapConfig || {};
        let { btnTxt } = (mapConfig[key] || {});
        btnTxt = btnTxt || '去完成';

        let oStatus = {
            isTitleCutdown: false,
            isBtnCutdown: false,
            btnStatus: 10,
            btnTitle: [],
            btnText: [btnTxt]
        };
        if (drawCnt < finishCnt) {
            // 可领取水滴
            oStatus = {
                ...oStatus,
                btnStatus: 20,
                btnTitle:[],
                btnText: ['开福袋']
            }
            return oStatus;
        }
        if (finishCnt >= maxCnt) {
            oStatus = {
                ...oStatus,
                btnStatus: 30,
                btnTitle: ['明日再来'],
                btnText: []
            }
        }
        const timesArray = missionTimes[0].concat(missionTimes[1]).concat(missionTimes[2]) || [];
        const mTime = new Date(secServerTime * 1000);
        const hour1 = missionTimes[0][0];
        const hour2 = missionTimes[1][0];
        const hour3 = missionTimes[2][0];
        const hour = mTime.getHours();
        if (timesArray.indexOf(hour) < 0){
            // 不在福袋时间区间内
            const btnText = hour < hour1 ? `${hour1}:00开启` : hour < hour2
                ? `${hour2}:00开启` : hour < hour3 ? `${hour3}:00开启` : '明日再来';
            oStatus = {
                ...oStatus,
                btnStatus: 30,
                btnText: [btnText]
            };
            return oStatus;
        }
        if (timesArray.indexOf(hour) >= 0) {
            if (finishCnt <= 0) {
                // 福袋完成次数小于0次, 直接返回去完成
                return oStatus;
            }
            // 在福袋时间区间内
            if (missionTimes[0].indexOf(hour) >= 0){
                // 在早晨福袋时间区间内, 且完成次数大于0次
                oStatus = {
                    ...oStatus,
                    btnStatus: 30,
                    btnText: [`${hour2}:00开启`]
                };
                return oStatus;
            }
            if (missionTimes[1].indexOf(hour) >= 0) {
                // 在中午福袋时间区间内
                if (finishCnt >= 2 || nextTime - secServerTime > 1) {
                    // 1.福袋完成次数>=2 || 2.当前时间小于下次可完成时间, 则状态为下个开启时间
                    oStatus = {
                        ...oStatus,
                        btnStatus: 30,
                        btnText: [`${hour3}:00开启`]
                    };
                    return oStatus;
                }
            }
            if (missionTimes[2].indexOf(hour) >= 0) {
                // 在晚上福袋时间区间内, 且完成次数<3
                if (nextTime - secServerTime > 1) {
                    // 当前时间小于下次可完成时间, 则状态为明日再来
                    oStatus = {
                        ...oStatus,
                        btnStatus: 30,
                        btnText: [`明日再来`]
                    };
                    return oStatus;
                }
            }
        }
        return oStatus;
    }
    mission18Status = (mission) => {
        // 浏览商品1分钟处理逻辑（每日1次）
        const finishCnt = Number(mission['finished_count']) || 0;
        const drawCnt = Number(mission['drawed_count']) || 0;
        const maxCnt = Number(mission['max_count']) || 0;
        const rewardAmount = Number(mission['reward_amount']) || 0;

        const { type: key } = (mission || {});
        const mapConfig = missionListStore.mapConfig || {};
        let { btnTxt } = (mapConfig[key] || {});
        btnTxt = btnTxt || '去完成';

        let oStatus = {
            isTitleCutdown: false,
            isBtnCutdown: false,
            btnStatus: 10,
            btnTitle: [],
            btnText: [btnTxt]
        };
        if (drawCnt < finishCnt) {
            // 可领取水滴
            oStatus = {
                ...oStatus,
                btnStatus: 20,
                btnTitle:['水滴', `${rewardAmount}g`],
                btnText: ['领取']
            }
            return oStatus;
        }
        if (finishCnt >= maxCnt) {
            oStatus = {
                ...oStatus,
                btnStatus: 10,
                btnTitle: ['今日已完成'],
                btnText: ['再逛逛']
            }
        }
        return oStatus;
    }
    mission25Status = (mission) => {
        // 贫困果农页面拼单任务处理逻辑
        const { type: key } = (mission || {});
        const mapConfig = missionListStore.mapConfig || {};
        let { btnTxt } = (mapConfig[key] || {});
        btnTxt = btnTxt || '去完成';

        let oStatus = {
            isTitleCutdown: false,
            isBtnCutdown: false,
            btnStatus: 10,
            btnTitle: [],
            btnText: [btnTxt]
        };
        return oStatus;
    }
    mission29Status = (mission) => {
        // 浏览商品1分钟处理逻辑（每日2次）
        const secServerTime = missionListStore.serverTime;  // 获取真实服务器时间
        const nextTime = Number(mission['next_available_time']) || 0;
        const finishCnt = Number(mission['finished_count']) || 0;
        const drawCnt = Number(mission['drawed_count']) || 0;
        const maxCnt = Number(mission['max_count']) || 0;
        const rewardAmount = Number(mission['reward_amount']) || 0;

        const { type: key } = (mission || {});
        const mapConfig = missionListStore.mapConfig || {};
        let { btnTxt } = (mapConfig[key] || {});
        btnTxt = btnTxt || '去完成';

        let oStatus = {
            isTitleCutdown: false,
            isBtnCutdown: false,
            btnStatus: 10,
            btnTitle: [],
            btnText: [btnTxt]
        };
        if (drawCnt < finishCnt) {
            // 可领取水滴
            oStatus = {
                ...oStatus,
                btnStatus: 20,
                btnTitle:['水滴', `${rewardAmount}g`],
                btnText: ['领取']
            }
            return oStatus;
        }
        if (finishCnt < maxCnt) {
            const msServer = secServerTime * 1000;
            const msNextTime = nextTime * 1000;
            const isSameDay = (new Date(msServer)).getDate() === (new Date(msNextTime)).getDate();
            if (nextTime - secServerTime >= 1) {
                oStatus = {
                    ...oStatus,
                    isTitleCutdown: !!isSameDay,
                    btnTitleClass: ['highlight'],
                    btnTitle: !!isSameDay ? ['后进行'] : ['0点可进行'],
                    btnText: ['再逛逛']
                }
            }
        } else {
            oStatus = {
                ...oStatus,
                btnStatus: 10,
                btnTitle: ['今日已完成'],
                btnText: ['再逛逛']
            }
        }
        return oStatus;
    }
    mission35Status = (mission) => {
        // 水滴雨任务处理逻辑
        const finishCnt = Number(mission['finished_count']) || 0;
        const drawCnt = Number(mission['drawed_count']) || 0;
        const maxCount = Number(mission['max_count']) || 0;
        const rewardAmount = Number(mission['reward_amount']) || 0;

        const { type: key } = (mission || {});
        const isNotFirstOrGT3 = missionListStore.isNotFirstTreeOrGT3Level;
        const mapConfig = missionListStore.mapConfig || {};
        let { btnTxt } = (mapConfig[key] || {});
        btnTxt = btnTxt || '去完成';

        let oStatus = {
            isTitleCutdown: false,
            isBtnCutdown: false,
            btnStatus: 10,
            btnTitle: [],
            btnText: [btnTxt]
        };
        if (drawCnt < finishCnt) {
            // 可领取水滴
            oStatus = {
                ...oStatus,
                btnStatus: 20,
                btnTitle:['水滴', `${rewardAmount}g`],
                btnText: ['领取']
            }
            return oStatus;
        }
        if (finishCnt >= maxCount) {
            if (isNotFirstOrGT3) {
                oStatus['btnStatus'] = false;
                oStatus['btnTitle'] = ['明日再来'];
            } else {
                oStatus['btnTitle'] = ['今日已完成'];
                oStatus['btnText'] = ['再练练'];
            }
        }
        return oStatus;
    }
    mission39Status = (mission) => {
        // 周卡任务处理逻辑
        const finishCnt = Number(mission['finished_count']) || 0;
        const drawCnt = Number(mission['drawed_count']) || 0;
        const rewardAmount = Number(mission['reward_amount']) || 0;
        const extraInfo = mission['extra_info'] || {};
        const remCnt = Number(extraInfo['remain_days']) || 0;

        const { type: key } = (mission || {});
        const mapConfig = missionListStore.mapConfig || {};
        let { btnTxt } = (mapConfig[key] || {});
        btnTxt = btnTxt || '去完成';

        let oStatus = {
            isTitleCutdown: false,
            isBtnCutdown: false,
            btnStatus: 10,
            btnTitle: [],
            btnText: [btnTxt]
        };
        if (drawCnt < finishCnt) {
            // 可领取水滴
            oStatus = {
                ...oStatus,
                btnStatus: 20,
                btnTitle:['水滴', `${rewardAmount}g`],
                btnText: ['领取']
            }
            return oStatus;
        }
        if (finishCnt === drawCnt && (finishCnt > 0 || remCnt === 7)) {
            const msExpired = Date.now() + remCnt * 24 * 60 * 60 * 1000;
            const dtFormat = formatTime(new Date(msExpired), 'MM月dd日');

            oStatus = remCnt >= 3 ? {
                ...oStatus,
                btnStatus: 30,
                btnTitle: [`${dtFormat}到期`],
                btnText: [`剩余${remCnt}天`]
            } : {
                ...oStatus,
                btnTitle: remCnt > 0 ? [`${dtFormat}到期`] : [],
                btnText: ['去续费']
            };
        }
        return oStatus;
    }
    onTomission = (mission, ev) => {
        (ev || {}).stopPropagation && ev.stopPropagation();
        const { type } = (mission || {});
        if (this[missionClickHander[type]]) {
            this[missionClickHander[type]](mission);
        } else {
            this.missionHandler(mission);
        }
    }
    missionHandler = (mission) => {
        // 任务的兜底处理逻辑
        ui.showToast('当前任务功能未完善');
        
    }
    /** 有些任务处理逻辑比较复杂，每个任务都独立一个handler */
    mission1Handler = (mission) => {
        const { type } = (mission || {});
        const mStatus = this.missionStatus(mission) || {};
        const mShare = this.missionShareRule(mission) || {};
        const { btnStatus } = mStatus;
        const { isShare, shareType } = mShare;
        const mustShare = !!isShare && shareType === 'SHARE_NEED';
        const statusNum = parseInt(btnStatus / 10);
        if (!type || statusNum === 3) {
            return;
        }
        const antContent = this.riskControlCrawler.messageDepacketize();
        let params = {
            mission_type: type,
            gain_time: 1,
            screen_token: antContent
        };
        if (statusNum === 2) {
            // 如果可领水，直接领水
            const cbContinue = () => {
                gainWater(params).then((data) => {
                    const { gain_amount: amount } = (data || {});
                    ui.showToast(`成功领取${amount || 0}g水滴~`);
                    missionListStore.onRefreshStore(data);

                }).catch((ex) => {
                    ui.showToast('领取水滴失败');
                    console.warn('mission1Handler :: gain-water > ex: ', ex);
                });
            }
            if (missionListStore.amountTotal >= 490) {
                this.showWarn(cbContinue, () => {});
            } else {
                cbContinue();
            }
            return;
        }
        if (mustShare) {
            // 任务必须要分享才能完成
            shareList[type]['callback'] = () => {
                this.onHide();
                let params = { mission_type: type };
                completeMission(params).then((data) => {
                    missionListStore.onRefreshStore(data);
                }).catch((ex) => {
                    // TO DO: 
                });
            };
            return;
        }
        this.showDilag(() => {
            // 完成任务和领水功能
            const cbConfirm = () => {
                completeMission(params).then((data) => {
                    return gainWater(params);
                })
                .then((data) => {
                    const { gain_amount: amount } = (data || {});
                    ui.showToast(`成功领取${amount || 0}g水滴~`);
                    missionListStore.onRefreshStore(data);
                }).catch((ex) => {
                    ui.showToast('领取水滴失败');
                    console.warn('mission1Handler :: complete&gain > ex: ', ex);
                });
            };

            if (missionListStore.amountTotal >= 490) {
                this.showWarn(cbConfirm, () => {});
            } else {
                cbConfirm();
            }
        }, () => {
            // TO DO: 取消弹窗处理逻辑
        });

    }
    mission3Handler = (mission) => {
        const { type: key } = (mission || {});
        const pscene = MISSION_2_SCENE[key] || {};
        const params = {
            scene_id: pscene['scene_id'],
            app_name: pscene['app_name'],
            page_type: pscene['page_type'],
            dest_mission: pscene['dest_mission'],
            page: 1,
            size: 20,
        }
        navigation.forward(`cartoon_fruit_goods.html?${urlUtil.buildQuery(params)}`);
    }
    mission5Handler = (mission) => {
        // 邀请好友种树任务处理逻辑
        const { type } = (mission || {});
        const mShare = this.missionShareRule(mission) || {};
        const { isShare, shareType } = mShare;
        const mustShare = !!isShare && shareType === 'SHARE_NEED';
        if (!mustShare) {
            return;
        }
        // 任务必须要分享才能完成
        shareList[type]['callback'] = () => {
            // 邀请好友种树分享回调处理
            console.log('This is share call back...');
            this.onHide();
        };
    }
    mission14Handler = (mission) => {
        // 福袋任务处理逻辑
        const { type } = (mission || {});
        const mStatus = this.mission14Status(mission);
        const { btnStatus } = (mStatus || {});
        const statusNum = parseInt(btnStatus / 10);
        if (!type) {
            return;
        }
        const antContent = this.riskControlCrawler.messageDepacketize();
        let params = {
            mission_type: type,
            gain_time: 1,
            screen_token: antContent
        };
        if (statusNum === 1) {
            // TO DO: 完成福袋任务处理逻辑
            gainBlessStore.open();
            return;
        }
        if (statusNum === 2) {
            // 如果可领水，直接领水
            const cbContinue = () => {
                gainWater(params).then((data) => {
                    const { gain_amount: amount } = (data || {});
                    ui.showToast(`成功领取${amount || 0}g水滴~`);
                    missionListStore.onRefreshStore(data);

                }).catch((ex) => {
                    ui.showToast('领取水滴失败');
                    console.warn('mission14Handler :: gain-water > ex: ', ex);
                });
            }
            if (missionListStore.amountTotal >= 490) {
                this.showWarn(cbContinue, () => {});
            } else {
                cbContinue();
            }
            return;
        }
        // 福袋任务状态为3xx处理逻辑
        const secServerTime = missionListStore.serverTime;    // 要获取真实服务器时间
        const timesArray = missionTimes[0].concat(missionTimes[1]).concat(missionTimes[2]) || [];
        const mTime = new Date(secServerTime * 1000);
        const hour1 = missionTimes[0][0];
        const hour2 = missionTimes[1][0];
        const hour3 = missionTimes[2][0];
        let hour = mTime.getHours();
        if (timesArray.indexOf(hour) < 0){
            // 不在福袋时间区间内
            const toastTxt = hour < hour1 ? `${hour1}:00开启` : hour < hour2
                ? `${hour2}:00` : hour < hour3 ? `${hour3}:00` : '明日再来';
            ui.showToast(`下次开启福袋时间为${toastTxt}`);
            return;
        }
        if (timesArray.indexOf(hour) >= 0) {
            // 在福袋时间区间内
            let toastTxt = missionTimes[0].indexOf(hour) >= 0 ? `${hour2}:00`
                : missionTimes[1].indexOf(hour) >= 0 ? `${hour3}:00` : '';
            !!toastTxt && ui.showToast(`下次开启福袋时间为${toastTxt}`);
        }
    }
    mission18Handler = (mission) => {
        // 每日1次浏览商品1分钟任务处理逻辑
        const { type } = (mission || {});
        const mStatus = this.mission18Status(mission);
        const { btnStatus } = (mStatus || {});
        const statusNum = parseInt(btnStatus / 10);
        if (!type) {
            return;
        }
        const antContent = this.riskControlCrawler.messageDepacketize();
        let params = {
            mission_type: type,
            gain_time: 1,
            screen_token: antContent
        };
        if (statusNum === 2) {
            // 如果可领水，直接领水
            const cbContinue = () => {
                gainWater(params).then((data) => {
                    const { gain_amount: amount } = (data || {});
                    ui.showToast(`成功领取${amount || 0}g水滴~`);
                    missionListStore.onRefreshStore(data);

                }).catch((ex) => {
                    ui.showToast('领取水滴失败');
                    console.warn('mission29Handler :: gain-water > ex: ', ex);
                });
            }
            if (missionListStore.amountTotal >= 490) {
                this.showWarn(cbContinue, () => {});
            } else {
                cbContinue();
            }
            return;
        }
        const { type: key } = (mission || {});
        const pscene = MISSION_2_SCENE[key] || {};
        const query = {
            scene_id: pscene['scene_id'],
            app_name: pscene['app_name'],
            page_type: pscene['page_type'],
            dest_mission: pscene['dest_mission'],
            page: 1,
            size: 20,
        };
        navigation.forward(`cartoon_fruit_goods.html?${urlUtil.buildQuery(query)}`);
    }
    mission25Handler = (mission) => {
        // 拼单助农任务处理逻辑
        const params = {
            type: 5,
            id: 1355
        };
        navigation.forward(`promotion_op.html?${urlUtil.buildQuery(params)}`);
    }
    mission29Handler = (mission) => {
        // 每日2次浏览商品1分钟任务处理逻辑
        const { type } = (mission || {});
        const mStatus = this.mission29Status(mission);
        const { btnStatus } = (mStatus || {});
        const statusNum = parseInt(btnStatus / 10);
        if (!type) {
            return;
        }
        const antContent = this.riskControlCrawler.messageDepacketize();
        let params = {
            mission_type: type,
            gain_time: 1,
            screen_token: antContent
        };
        if (statusNum === 2) {
            // 如果可领水，直接领水
            const cbContinue = () => {
                gainWater(params).then((data) => {
                    const { gain_amount: amount } = (data || {});
                    ui.showToast(`成功领取${amount || 0}g水滴~`);
                    missionListStore.onRefreshStore(data);

                }).catch((ex) => {
                    ui.showToast('领取水滴失败');
                    console.warn('mission29Handler :: gain-water > ex: ', ex);
                });
            }
            if (missionListStore.amountTotal >= 490) {
                this.showWarn(cbContinue, () => {});
            } else {
                cbContinue();
            }
            return;
        }
        const { type: key, drawed_count: drawCnt } = (mission || {});
        const mKey = drawCnt <= 0 ? `${key}-0` : key; 
        const pscene = MISSION_2_SCENE[mKey] || {};
        const query = {
            scene_id: pscene['scene_id'],
            app_name: pscene['app_name'],
            page_type: pscene['page_type'],
            dest_mission: pscene['dest_mission'],
            page: 1,
            size: 20,
        };
        navigation.forward(`cartoon_fruit_goods.html?${urlUtil.buildQuery(query)}`);
    }
    mission32Handler = (mission) => {
        // 邀请枯萎好友回来浇水任务处理逻辑
        ui.showToast('枯萎好友列表弹窗需要实现');
    }
    mission39Handler = (mission) => {
        // 水滴周卡任务任务处理逻辑
        const { type: key, drawed_count: drawCnt } = (mission || {});
        const mKey = drawCnt <= 0 ? `${key}-0` : key; 
        const pscene = MISSION_2_SCENE[mKey] || {};
        const params = {
            scene_id: pscene['scene_id'],
            app_name: pscene['app_name'],
            page_type: pscene['page_type'],
            dest_mission: pscene['dest_mission'],
            page: 1,
            size: 20,
        };
        navigation.forward(`cartoon_fruit_goods.html?${urlUtil.buildQuery(params)}`);
    }
    showDilag = (cbConfirm, cbCancel) => {
        this.setState({
            isDialog: true
        }, () => {
            cbConfirm && (this.cbConfirm = cbConfirm.bind(this));
            cbCancel && (this.cbCancel = cbCancel.bind(this));
        });
    }
    onCloseDlg = () => {
        this.setState({
            isDialog: false
        }, () => {
            this.cbCancel && this.cbCancel();
        });
    }
    onConfirmDlg = () => {
        this.setState({
            isDialog: false
        }, () => {
            this.cbConfirm && this.cbConfirm();
        });
    }
    showWarn = (cbConfirm, cbCancel) => {
        this.setState({
            isWarn: true
        }, () => {
            cbConfirm && (this.cbWarnConfirm = cbConfirm.bind(this));
            cbCancel && (this.cbWarnCancel = cbCancel.bind(this));
        });
    }
    onCloseWarn = () => {
        this.setState({
            isWarn: false
        }, () => {
            this.cbWarnCancel && this.cbWarnCancel();
        });
    }
    onConfirmWarn = () => {
        this.setState({
            isWarn: false
        }, () => {
            this.cbWarnConfirm && this.cbWarnConfirm();
        });
    }
    onCollectData (e) {
        this.riskControlCrawler.swallow(e);
    }
    render() {
        const { mapConfig, isShow } = missionListStore;
        const missionsList = missionListStore.missionsToShow || [];
        const { isDialog, isWarn } = this.state;

        return (<View className={`missions-container ${!!isShow ? 'show' : ''}`}
                    onClick={this.onHide}
                    onTouchmove={this.onCollectData}
                    onLongpress={this.onCollectData}
                >
            <View className='mission-mask'></View>
            <View className='mission-main'>
                <View className='mission-title'>
                    领水滴任务<View className='mission-close' onClick={this.onHide}>×</View>
                </View>
                <ScrollView scrollY className='mission-list'>
                    {missionsList.map((mission, idx) => {
                        const { type: key, next_available_time: nextTime } = (mission || {});
                        let { mainDesc, subDesc, subDesc2, imageName } = (mapConfig[key] || {});
                        mainDesc = this.formatSubDesc(mainDesc, mission);
                        subDesc = (subDesc || []).map((str) => this.formatSubDesc(str, mission));
                        subDesc2 = subDesc2 || [];
                        subDesc2 = (subDesc2 || []).map((str) => this.formatSubDesc(str, mission));
                        const imgUrl = this.imageUrl(imageName);
                        const mStatus = this.missionStatus(mission);
                        let { isTitleCutdown, isBtnCutdown, btnStatus, btnTitle, btnText, btnTitleClass } = (mStatus || {});
                        btnStatus = parseInt(btnStatus / 10);
                        btnText = btnText || [];
                        btnTitle = btnTitle || [];
                        btnTitleClass = btnTitleClass || [];
                        const btnClass = [];
                        
                        btnStatus === 2 && btnClass.push('yellow');
                        btnStatus === 3 && btnClass.push('gray');
                        !btnText.length && btnClass.push('hidden');
                        (btnTitle.join() || '').length > 5 && btnTitleClass.push('small');
                        !btnTitle.length && btnTitleClass.push('hidden');


                        const mShare = this.missionShareRule(mission);
                        const { isShare, shareType } = (mShare || {});
                        const mustShare = !!isShare && shareType === 'SHARE_NEED';
                        const shareBtn = mustShare && btnStatus === 1;

                        return <View key={idx} className='mission-item'>
                            <View className='mission-left'>
                                <Image className='mission-img' mode='scaleToFill' src={imgUrl} />
                            </View>
                            <View className='mission-center'>
                                <View className='mission-center-main'>
                                    <View className='title'>{mainDesc}</View>
                                    <View className='sub-title'>
                                        {subDesc.map((desc) => {
                                            return desc === '水滴' ? <Text key={desc} className='water-img'></Text> : <Text key={desc}>{desc}</Text>;
                                        })}
                                    </View>
                                    {subDesc2.length && <View className='sub-title'>
                                        {subDesc2.map((desc) => {
                                            return desc === '水滴' ? <Text key={desc} className='water-img'></Text> : <Text key={desc}>{desc}</Text>;
                                        })}
                                    </View>}
                                </View>
                                <View className='mission-center-right'>
                                    {isTitleCutdown && <View className='mission-timer'>
                                        <Timer deadTime={nextTime}></Timer><Text>{btnTitle.join()}</Text>
                                    </View>}
                                    {!isTitleCutdown && <View className={`btn-title ${btnTitleClass.join(' ')}`}>
                                        {btnTitle.map((item) => {
                                            return item === '水滴' ? <Text key={item} className='water-img'></Text> : <Text key={item}>{item}</Text>; 
                                        })}
                                    </View> }
                                    {isBtnCutdown && <View className='mission-timer'>
                                        <Timer deadTime={nextTime}></Timer><Text>后可领取</Text>
                                    </View>}
                                    {!isBtnCutdown && <Button openType={shareBtn ? 'share' : ''} id={key} className={`button ${btnClass.join(' ')}`} onClick={this.onTomission.bind(this, mission)}>
                                        {btnText.join()}
                                    </Button>}
                                </View>
                            </View>
                        </View>;
                    })}
                    <View className='mission-notice'>完成任务后会获得水滴，超过当天24点未领取会消失哦</View>
                </ScrollView>
            </View>
            {isDialog && <Confirm onClose={this.onCloseDlg} onConfirm={this.onConfirmDlg}></Confirm>}
            {isWarn && <Warn onClose={this.onCloseWarn} onConfirm={this.onConfirmWarn}></Warn>}
        </View>);
    }
}

export default MissionList;
