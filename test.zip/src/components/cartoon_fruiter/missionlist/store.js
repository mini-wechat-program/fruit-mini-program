import { observable, action, computed, get } from 'mobx';
import { getMissionList, getWitheMission } from '@apiRequest/missionRequest';
import { MISSION_LIST_CONFIG, MISSION_KEYS_2_ID } from './constants';

class missionListStore {
    @observable isShow = false;
    @observable list = null;
    @observable mapConfig = MISSION_LIST_CONFIG;
    @observable isNewUser = true;
    @observable isloginApp = false;
    @observable playerInfo = null;
    @observable friendList = null;
    @observable amountTotal = 0;
    @observable serverTime = Date.now() / 1000;
    @observable poorActivityName = '拼单助农-浙江龙头鱼'; // 对应树信息中的 poor_orchard_activity_name
    
    constructor() {
        this.loadData();
    }

    @action
    loadData = () => {
        getMissionList().then((data) => {
            const {
                server_time: time,
                login_app: loginApp,
                water_amount: amount,
                mission_list: missionList
            } = (data || {});

            this.serverTime = time;
            this.isloginApp = loginApp;
            this.amountTotal = amount;
            this.list = missionList;
            return getWitheMission();
        })
        .then((data) => {
            const { success, type } = (data || {});
            if (!success || !type) {
                return;
            }
            let missions = {...(this.list || {})};
            missions = {...missions, [type]: observable(data) };
            this.list = missions;
        }).catch((ex) => {
            console.error(`mission list store :: 获取任务列表失败 > `, ex);
        });
    }

    @action
    loadWitheMission = () => {
        getWitheMission().then((data) => {
            const { success, type } = (data || {});
            if (!success || !type) {
                return;
            }
            let missions = {...(this.list || {})};
            missions = {...missions, [type]: observable(data) };
            this.list = missions;
        }).catch((ex) => {
            console.error(`mission list store :: 获取枯萎任务失败 > `, ex);
        });
    }
    @action
    onHide = () => {
        this.isShow = false;
    }
    @action
    onShow = () => {
        this.loadData();
        this.isShow = true;
    }
    @action
    onUpdLoginStatus = (status) => {
        this.isloginApp = status
    }
    @action
    onRefreshStore = (data) => {
        const {
            server_time: time,
            water_amount: amount,
            mission_list: missionList
        } = (data || {});
        if (!Object.keys(missionList).length) {
            return;
        }
        this.serverTime = time;
        this.amountTotal = amount;
        this.list = missionList;
    }

    @computed get isNotFirstTreeOrGT3Level() {
        const { product, create_product_number: number } = (this.playerInfo || {});
        const { level } = (product || {});
        return level > 3 || number > 1;
    }

    @computed get missionsToShow() {
        const list = this.list || {};
        let mKeys = [35, 1, 14, 18, 29, 39, 3, 32, 5, 4, 25];
        const mapConfig = this.mapConfig || {};
        let missionKeys = (Object.keys(list) || []).map((item) => Number(item));
        mKeys = mKeys.filter((item) => {
            const { imageName, type } = (mapConfig[item] || {});
            const hasImage = !!(imageName || '').trim();
            return missionKeys.indexOf(Number(item)) >= 0 && hasImage
                && (type === 'app' && this.isNewUser && !this.isloginApp || type !== 'app');
        }) || [];

        // 如果没有枯萎任务信息，则删除枯萎任务key
        const key = MISSION_KEYS_2_ID['SHARE_INVITE_WITHERED_FRIEND_REWARD_WATER'];
        const mToWakeup = this.missionToWakeup || {};
        if (!mToWakeup['type']) {
            mKeys = mKeys.filter((item) => item !== key) || [];
        };

        // 新用户下载App任务排序
        const iApp = mKeys.indexOf('app');
        const isNotFirstOrGT3 = this.isNotFirstTreeOrGT3Level;
        if (iApp >= 0) {
            mKeys.splice(iApp, 1);
            isNotFirstOrGT3 ? mKeys.splice(mKeys.length - 2, 0, 'app') : mKeys.splice(mKeys.length - 1, 0, 'app');
        }
        let missions = mKeys.map((item) => list[item]);
        const isFinished = (item) => {
            const { finished_count: finishCnt, max_count: maxCnt } = (item || {});
            return finishCnt >= maxCnt && maxCnt > 0;
        };
        const mFinished = missions.filter((item) => isFinished(item));
        const munFinished = missions.filter((item) => !isFinished(item));

        return munFinished.concat(mFinished);
    }

    @computed get missionToWakeup() {
        const missionId = MISSION_KEYS_2_ID['SHARE_INVITE_WITHERED_FRIEND_REWARD_WATER']; // 枯萎唤醒任务type
        const list = this.list || {};
        const mKeys = (Object.keys(list) || []).map((item) => Number(item));
        const mission = list[missionId] || {};
        const friends = mission['friend_lists'] || [];
        if (mKeys.indexOf(missionId) >= 0 && friends.length) {
            return mission;
        }
        return null;
    }
}

export default missionListStore = new missionListStore();
