import Taro, { Component } from '@tarojs/taro';
import { Text } from '@tarojs/components';

class TimeTick extends Component {
    constructor(props) {
        super(props);

        const deadTime = this.props.deadTime || parseInt(Date.now() / 1000);
        const nowTime = parseInt(Date.now() / 1000);
        this.timer = null;
        this.state = {
            remainTime: deadTime - nowTime,
        }
    }
    componentDidMount () {
        this.timer = setInterval(() => {
            const prevRemainTime = this.state.remainTime;
            const remainTime = prevRemainTime - 1;
            if (remainTime <= 0) {
                this.timer && clearInterval(this.timer);
                this.timer = null;
            }
            this.setState({
                remainTime: remainTime
            });
        }, 1* 1000)
    }
  
    componentWillUnmount () { 
        this.timer && clearInterval(this.timer);
        this.timer = null;
    }
    render() {
        const remainTime = this.state.remainTime || 0;

        let hours = parseInt(remainTime / 3600);
        let mins = parseInt((remainTime - (hours * 3600)) / 60);
        let seconds = parseInt(remainTime - hours * 3600) - (mins * 60);
        hours = hours < 10 ? `0${hours}` : hours;
        mins = mins < 10 ? `0${mins}` : mins;
        seconds = seconds < 10 ? `0${seconds}` : seconds;

        return remainTime > 1 && <Text>{`${hours}:${mins}:${seconds}`}</Text>;

    }
}

export default TimeTick;
