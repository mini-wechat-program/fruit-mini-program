import Taro, { Component, Button } from '@tarojs/taro';
import { Text } from '@tarojs/components';
import './index.scss';

class Warn extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount () {

    }
  
    componentWillUnmount () { 

    }
    render() {
        return <View className='warn-container'>
            <View className='warn-body'>
                <View className='warn-bg-img'></View>
                <View className='warn-content'>
                    <View className='title'>水壶已经满了</View>
                    <View className='sub-title'>水壶还能装下不到10g ，确定领取吗？</View>
                </View>
                <View className='warn-btns'>
                    <View className='button' onClick={this.onConfirm}>确定</View>
                    <View className='button' onClick={this.onClose}>去浇水</View>
                </View>
            </View>
        </View>
    }
    onClose = (ev) => {
        (ev || {}).stopPropagation && ev.stopPropagation();
        this.props.onClose && this.props.onClose();
    }
    onConfirm = (ev) => {
        (ev || {}).stopPropagation && ev.stopPropagation();
        this.props.onConfirm && this.props.onConfirm();
    }
}

export default Warn;
