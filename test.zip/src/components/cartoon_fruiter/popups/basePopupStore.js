import { observable, action } from "mobx";

const popupList = [];


/**
 * 控制弹窗的基础store，其他弹窗的store理应继承BasePopupStore，方便统一管理
 *
 * @export
 * @class BasePopupStore
 */
export class BasePopupStore {
    // 用于控制弹窗的开关
    @observable
    show = false

    /**
     * 打开弹窗
     * @memberof BasePopupStore
     */
    @action
    open() {
        popupList.push(this);
        popupList[0].show = true;
    }

    /**
     * 关闭弹窗
     * @memberof BasePopupStore
     */
    @action
    close() {
        this.show = false;
        const index = popupList.indexOf(this);
        if (index >= 0 && index < popupList.length) {
            popupList.splice(index, 1);
            setTimeout(() => {
                if (popupList.length > 0) {
                    popupList[0].show = true;
                }
            }, 300);
        }
    }
}

export default BasePopupStore;
