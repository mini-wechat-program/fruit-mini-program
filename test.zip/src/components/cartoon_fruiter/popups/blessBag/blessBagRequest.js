import { baseRequest } from "../../../../utils/requestUtil";
import { getAntiContent } from "../../../../utils/garden/global";

// 分享福袋翻倍领水
export const shareBagDouble = (missionType) => {
    return baseRequest('api/manor/bag/share/gain', {
        params:{
            mission_type: missionType,
            screen_token: getAntiContent()
        }
    })
};
