import Taro, { Component } from '@tarojs/taro';
import { observer } from '@tarojs/mobx';
import './style.scss';
import AwardPopup from '../../../../widgets/popup/award';
import { gainBlessStore } from './store';
import { imageUtil } from '../../../../../utils/imageUtil';
import { Block, Button } from '@tarojs/components';
import { addShareCallback } from '../../../../../wx_common/share/shareInfo';

const getText = (state, drip) => {
    switch (state) {
        case 1:
            return `分享成功，点击开启福袋 `;
        case 2:
            return `恭喜你获得${drip}g水滴`;
        case 3:
            return `翻倍成功，获得${drip}g水滴`;
    }
}

@observer
class GainBlessBag extends Component {
    componentDidMount() {
        // gainBlessStore.open();
        addShareCallback(2, () => {
            gainBlessStore.gainWater2()
        })
    }

    gainWater() {
        if (gainBlessStore.state === 1) {
            gainBlessStore.gainWater();
        }
    }

    shareDouble() {
        // if (gainBlessStore.state === 2) {
        //     gainBlessStore.gainWater2()
        // }
    }

    close() {
        gainBlessStore.close();
    }

    render() {
        const { show, state, dripNum } = gainBlessStore;
        const img =
            <Block >
                {
                    state > 1 ? <Image onClick={this.close} className='img' src={imageUtil('noonNightDrawWater')} /> :
                        <Image onClick={this.gainWater} className='img' src={imageUtil('noonNightBigBag')} />
                }
            </Block>

        const text = getText(state, dripNum);

        const btn =
            <Block>
                {
                    state === 2 && <Button openType='share' onClick={this.shareDouble} className='share' id={'2'}>分享翻倍</Button>
                }
            </Block>

        return (
            <View className='gain-bless'>
                {
                    show &&
                    <AwardPopup content={text}
                        renderExtra={
                            <View className='btns'>
                                {btn}
                            </View>
                        }>
                        {img}
                    </AwardPopup>
                }
            </View>

        );
    }
}

export default GainBlessBag;