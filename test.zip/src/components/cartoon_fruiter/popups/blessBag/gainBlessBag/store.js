import { BasePopupStore } from "../../basePopupStore";
import { action, observable, runInAction } from "mobx";
import { completeMission, gainWater, gainWaterWithAnti } from "../../../../../apiRequest/fruitRequest";
import { MissionType } from "../../../../../utils/garden/constants/missionType";
import { getNoonNightMissionStatus } from "../util";
import { globalStore } from "../../../../../store/userInfo";
import { shareBagDouble } from "../blessBagRequest";

//      分享成功 => 点击分享翻倍 =>  翻倍成功
// state  1            2            3
class GainBlessStore extends BasePopupStore {
    @observable
    state = 1;

    @observable
    dripNum = 0;

    @action
    open() {
        super.open();
        return completeMission(MissionType.LIMIT_TIME_SHARE)
            .then(data => {
                this.state = 1;
                globalStore.missionList.setMissionList(data)
            })
    }

    gainWater() {
        return gainWaterWithAnti(MissionType.LIMIT_TIME_SHARE).then(data => {
            runInAction(() => {
                this.state = 2;
                this.dripNum += data.gain_amount;
                globalStore.currentUser.waterAmount = data.water_amount;
            })
        }).catch(e => {
            this.close();
            throw e
        })
    }

    /**
     * 翻倍后领水
     */
    gainWater2() {
        return shareBagDouble(MissionType.LIMIT_TIME_TWO_SHARE).then(data => {
            runInAction(() => {
                this.state = 3;
                this.dripNum += data.gain_amount;
                globalStore.currentUser.waterAmount += data.gain_amount;
            })
        }).catch(e => {
            this.close();
            throw e;
        })
    }
}

export const gainBlessStore = new GainBlessStore();