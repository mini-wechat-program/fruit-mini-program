import Taro, { Component } from '@tarojs/taro'
import { View, Text } from '@tarojs/components';
import './style.scss';
import Popup from '../../../widgets/popup/popup';
import Overlay from '../../../widgets/popup/overlay';
import PopupBody from '../../../widgets/popup/body';
import PopupClose from '../../../widgets/popup/close';
import { imageUtil } from '../../../../utils/imageUtil';
import BaseButton from '../../../widgets/popup/button';
import { BasePopupStore } from '../basePopupStore';
import { observer, inject } from '@tarojs/mobx';
import OpenAnimation from '../../../widgets/popup/openAnimation';
import { baseRequest } from '../../../../utils/requestUtil';
import { getNoonNightMissionStatus, btnState } from './util';
import GainBlessBag from './gainBlessBag';
import AwardPopup from '../../../widgets/popup/award';

const store = new BasePopupStore();

// @inject(store => ({
//     mission: store.globalStore.missionList
// }))
@inject('globalStore')
@observer
class BlessBag extends Component {
    static defaultProps = {
        missionList: {}
    }

    componentDidMount() {
        store.open();
        // baseRequest('api/manor/tree/get').then(data=>console.log(data));
    }

    onClose() {
        store.close();
    }

    onClick(){

    }

    render() {
        const { show } = store;
        const { globalStore: { missionList: { list = {} } } } = this.props;
        // console.log(list[14], getNoonNightMissionStatus(list[14]))
        const { mainBtnText, btnClass } = btnState(getNoonNightMissionStatus(list[14]), true);
        // const {mainBtnText, btnClass} = {};
        // console.log(this.props.mission)
        // console.log('bless', mainBtnText, btnClass);
        return (
            <View id='fruiter'>
                {false &&
                    <Popup>
                        <Overlay></Overlay>
                        <PopupBody>
                            <PopupClose type='inTopRight' onClose={this.onClose}/>
                            <OpenAnimation />
                            <View className='bless-bag'>
                                <View>
                                    <Image className='main-img' src={imageUtil('noonNightSmallBag')} />
                                </View>
                                <View className='title'>每日三餐开福袋</View>
                                <View className='desc'>
                                    每日<Text className='red'>7:00-9:00</Text>,<Text className='red'>12:00-14:00</Text>和
                                </View>
                                <View className='desc'>
                                    <Text className='red'>18:00-21:00</Text>,开福袋得水滴
                                </View>
                                <View className='main-btn'>
                                    <BaseButton type={btnClass} onClick={this.onClick}>{mainBtnText}</BaseButton>
                                </View>
                                {/* <View className='main-btn'>
                                    <BaseButton type='normal' >开启福袋提醒</BaseButton>
                                </View> */}
                            </View>
                        </PopupBody>
                    </Popup>
                }
            </View>

        );
    }
}

export default BlessBag;