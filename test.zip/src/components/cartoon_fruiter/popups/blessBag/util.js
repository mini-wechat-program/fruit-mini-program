
const nooNightRangeOne = [7, 8];
const nooNightRangeTwo = [12, 13];
const nooNightRangeThree = [18, 19, 20];
export const getNoonNightMissionStatus = (mission, serverTime) => {
    if (!mission) return null;

    let date = new Date(serverTime * 1000);
    // if (serverTime) {
    //     date = new Date(serverTime * 1000);
    // } else {
    //     date = new Date(serverTime.dt * 1000 + Date.now());
    // }
    const hour = date.getHours();

    if (mission.finished_count > mission.drawed_count) {
        return 'couldDraw';
    }
    if (nooNightRangeOne.indexOf(hour) === -1 && nooNightRangeTwo.indexOf(hour) === -1 && nooNightRangeThree.indexOf(hour) === -1) { // 不在任务时间内
        if (hour < nooNightRangeOne[0]) {
            return 'forbidOne';
        } else if (hour < nooNightRangeTwo[0]) {
            return 'forbidTwo';
        } else if (hour < nooNightRangeThree[0]) {
            return 'forbidThree';
        } else {
            return 'comeAgainTomorrow';
        }
    }
    // 命中福袋早场
    if (nooNightRangeOne.indexOf(hour) !== -1) {
        if (mission.finished_count === 0) {
            return 'toFinish';
        }
        if (mission.finished_count === 1) {
            return 'forbidTwo';
        }
    }
    // 命中福袋午场
    if ((nooNightRangeTwo.indexOf(hour) !== -1 && mission.finished_count <= 2)) {
        if (mission.finished_count === 0) {
            return 'toFinish';
        }
        if (mission.finished_count === 1 && (Date.now() / 1000 + dServerTime.dt) > mission.next_available_time) {
            return 'toFinish';
        }
        return 'forbidThree';
        // if (mission.finished_count === 2) {
        //     return 'forbidThree';
        // }
    }
    // 命中福袋晚场
    if ((nooNightRangeThree.indexOf(hour) !== -1 && mission.finished_count <= 3)) {
        if (mission.finished_count === 0) {
            return 'toFinish';
        }
        if (mission.finished_count <= 2 && (Date.now() / 1000 + dServerTime.dt) > mission.next_available_time) {
            return 'toFinish';
        }
        return 'comeAgainTomorrow';
    }
    return 'comeAgainTomorrow';
};

export const btnState = (missionStatus, isOpenNotify, ifShare) => {
    let mainBtnText, btnClass = null;
    // 打开了提醒
    if (isOpenNotify) {
        if (missionStatus === 'toFinish') {
            mainBtnText = `${ifShare}开福袋`;
        } else if (missionStatus === 'forbidOne' || missionStatus === 'comeAgainTomorrow') {
            mainBtnText = '7:00-9:00再来领取';
            btnClass = 'disabled';
        } else if (missionStatus === 'forbidTwo') {
            mainBtnText = '12:00-14:00再来领取';
            btnClass = 'disabled';
        } else if (missionStatus === 'forbidThree') {
            mainBtnText = '18:00-21:00再来领取';
            btnClass = 'disabled';
        }
        // 关闭了提醒
    } else {
        // 在福袋时间
        if (missionStatus === 'toFinish') {
            mainBtnText = `${ifShare}开福袋`;
        } else {
            mainBtnText = '开启福袋提醒';
        }
    }
    return { mainBtnText, btnClass };
}

const getDrawState = (missionStatus, drawedWater, doubleGainWater) => {
    // const ifShare = !needShareMissionOf(MissionType.LIMIT_TIME_SHARE) ? '' : '分享';
    const imgName = missionStatus === 'couldDraw' ? imageUtil('noonNightBigBag') : imageUtil('noonNightDrawWater');
    const waterAmount = drawedWater ? drawedWater + 'g' : '';
    let text = '';
    if (missionStatus === 'couldDraw') {
        // if (!needShareMissionOf(MissionType.LIMIT_TIME_SHARE)) {
        //     text = '点击开启福袋';
        // } else {
        //     text = '分享成功, 点击开启福袋';
        // }
        text = '分享成功, 点击开启福袋';
    }
    if (missionStatus === 'drawed') {
        // switch (this.drawedWater) {
        //     case 5:
        //         text = `获得${waterAmount}水滴，再接再厉吧~`;
        //         break;
        //     case 10:
        //         text = `获得${waterAmount}水滴，感觉还行哦~`;
        //         break;
        //     case 20:
        //         text = `获得${waterAmount}水滴，哎哟不错噢!`;
        //         break;
        //     case 50:
        //         text = `获得${waterAmount}水滴，你就是天选之人!`;
        //         break;
        //     default:
        //         text = `获得${waterAmount}水滴，再接再厉吧~`;
        //         break;
        // }
        if (drawedWater === 50) {
            text = `获得${waterAmount}水滴，你就是天选之人!`;
        } else {
            text = `恭喜你获得${waterAmount}水滴`;
        }
    } else if (missionStatus === 'shared') {
        const water = drawedWater + doubleGainWater;
        // const water = this.state.doubleNumber;
        text = `翻倍成功，共计获得${water}g水滴`;
    }
    return {text, }
}