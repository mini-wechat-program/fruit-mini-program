import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components';
import SelectSeed from './selectSeed';
// import PopupTest from './popup-test';
import BlessBag from './blessBag';
import GainBlessBag from './blessBag/gainBlessBag';

class Popups extends Component {
    render() {
        return (
            <View>
                {/* <BlessBag /> */}
                <GainBlessBag />
                <SelectSeed />
                {/* <PopupTest /> */}
                
            </View>
        );
    }
}

export default Popups;