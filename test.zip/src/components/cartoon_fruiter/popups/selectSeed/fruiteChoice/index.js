import Taro, { Component } from '@tarojs/taro';
import { observer } from '@tarojs/mobx';
import { View, Text, Image } from '@tarojs/components';
import './style.scss';
import { imageUtil } from '../../../../../utils/imageUtil';


@observer
class FruiteChoice extends Component {
    render() {
        // const props = this.props.item || {};
        if(!this.props.item) return null;
        const { id, boxImg, name } = this.props.item || {};
        return (
            <View className='fruit-choice' onClick={this.props.onChoose.bind(this, id)}>
                <View className='img'>
                    {this.props.choice === id &&
                        <Image className='shine-bg' src={imageUtil('seedsSelectedShine_v2')} />
                    }
                    <Image src={imageUtil(boxImg)} />
                    {/* <Text className='weight'>约{props.weight}斤</Text> */}
                </View>
                <View className='radio-btn'>
                    {/* <View className='circle' style={borderStyle}> */}
                    <View className='circle'>
                        {this.props.choice === id &&
                            <Image src={imageUtil('seedsSelectedMark_v2')} />
                        }
                    </View>
                    <Text>{name}</Text>
                </View>
            </View>
        );
    }
}

export default FruiteChoice;