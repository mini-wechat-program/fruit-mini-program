import Taro, { Component } from '@tarojs/taro'
import { observer } from '@tarojs/mobx';
import { View, Text, Button, Image } from '@tarojs/components';
import selectSeedStore from './store';
import './style.scss';
import FruiteChoice from './fruiteChoice';
import Info from './info';
import { imageUtil } from '../../../../utils/imageUtil';

const ICON_PICC = imageUtil('piccSelect');

@observer
class SelectSeed extends Component {
    constructor(props) {
        super(props);
        // this.state = {
        //     // show: false,
        //     choice: {},
        //     gainList: [],
        //     fruitList: [],
        // };
    }

    componentDidMount() {
        // this.setState({ show: true });
        // selectSeedStore.open();
        // const shareUid = url.getParameter('refer_share_uid') || '';
        // getNewPlantInfo()
        //     .then(data => {
        //         const fruitList = processFruitList(data.fruit_info_list);
        //         this.setState({
        //             gainList: processGainList(data.friend_gain_list),
        //             fruitList,
        //             choice: fruitList.find(item => item.is_default) || fruitList[0]
        //         });
        //         console.log((fruitList.find(item => item.is_default) || {}).id, fruitList[0].id)
        //         // loggerUtil.impr(97607);
        //     })
        //     .catch(e => {
        //         this.setState({
        //             gainList: DEFAULT_DATA,
        //             fruitList: []
        //         });
        //         throw e;
        //     });
        // logger.trackingRecord({
        //     'op': 'impr',
        //     'page_el_sn': '97607',
        // });
    }

    choose = (id) => {
        // console.log(id);
        // let choice = {};
        // for (const key in selectSeedConfig) {
        //     if (selectSeedConfig[key].id === id) {
        //         choice = selectSeedConfig[key];
        //         break;
        //     }
        // }
        selectSeedStore.choice = selectSeedStore.fruitList.find(item => item.id === id)
        // console.log(selectSeedStore.choice)
        // this.setState({ choice: this.state.fruitList.find(item => item.id === id) });
    }

    // fruitChoice = (type) => {
    //     return <FruiteChoice
    //         key={type}
    //         {...selectSeedConfig[type]}
    //         choice={this.state.choice.id}
    //         onChoose={this.choose}
    //     />;
    // }

    go = () => {
        // logger.trackingRecord({
        //     'op': 'click',
        //     'page_el_sn': '97607',
        // });
        // event.emit(eventType.MAINSTAGE_CREATETREE_TAP, this.state.choice.type);
        // this.setState({
        //     show: false
        // });
        selectSeedStore.selectSeed();

    }

    render() {
        // console.log(this.state.fruitList)
        // console.log(selectSeedStore.choice.id)
        const choiceId = selectSeedStore.choice.id;
        return (
            selectSeedStore.show &&
            <View>
                <Image className='select-seed-bg' src={imageUtil('select-seed-bg')} />
                <View className='select-seed'>
                    <View className='select-seed-title'>
                        <Text>选择1份水果，</Text>
                        <Text className='select-seed-strong'>免费包邮送到家</Text>
                    </View>

                    <View className='select-seed-imgs'>
                        <View>
                            <View className='row two-item'>
                                {selectSeedStore.fruitList.slice(0, 2).map((item, i) =>
                                    <FruiteChoice key={i} item={item} onChoose={this.choose} choice={choiceId} />)
                                }
                            </View>
                            <View className='row two-item'>
                                {selectSeedStore.fruitList.slice(2, 4).map((item, i) =>
                                    <FruiteChoice key={i} item={item} onChoose={this.choose} choice={choiceId} />)
                                }
                            </View>
                        </View>
                    </View>

                    <View className='bottom-align'>
                        {/*
                            <View className='select-seed-main-btn'>
                                <Button onClick={this.go}>开始种植{this.state.choice.name}</Button>
                            </View>
                        */}
                        <View className='select-seed-main-btn'>
                            <Button onClick={this.go}>0元拿{selectSeedStore.choice.weight}斤{selectSeedStore.choice.name}</Button>
                        </View>
                        <View className='picc-txt-box'>
                            <Image className='line-txt picc' src={ICON_PICC} />
                            <Text className='line-txt picc-txt'>中国人民保险保障活动真实有效</Text>
                        </View>
                        <View className='select-seed-dynamic-info'>
                            {/* <h2>已有900000+人收获了水果</h2> */}
                            <View className='select-seed-dynamic-info-con'>
                                {/* {this.state.dynamicInfo.map(info => <Info {...info} />)} */}
                                {/* <DynamicInfo
                                    data={this.state.dynamicInfo}
                                    len={3}
                                    height={'0.53rem'}
                                    subComponent={data => <Info key={data.id} {...data} />}
                                /> */}
                                {selectSeedStore.gainList.map((item, i) => <Info key={i} item={item} />)}
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        );
    }
}

export default SelectSeed;




