import Taro, { Component } from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components';
import './style.scss';

class Info  extends Component{
    render(){
        const props = this.props.item || {};
        // console.log(props.nickname);
        return (
            <View className='info'>
                <Image src={props.avatar} />
                <View className='name'>
                    <Text className='select-seed-strong'>{props['nickname']}</Text>
                    {/* <Text className='select-seed-strong'>{props.nickname}</Text> */}
                </View>
                <View className='desc'>
                    <Text>已免费收获</Text>
                    <Text className='select-seed-strong'>{props['gain_number']}箱水果</Text>
                </View>
            </View>
        );
    }
}

export default Info;