import { baseRequest } from "../../../../utils/requestUtil";

// 获取种树页信息
export const getNewPlantInfo = (sharedUid) => {
    return baseRequest('api/manor-gateway/manor/query/new/user/plant/info', {
        params: { shared_uid: sharedUid }
    })
};

export const createSeed = (type, missionType, shareUid)=>{
    const params = {
        type: type,
        mission_type: missionType || '5', // 化肥邀请是27,其余是5
        share_uid: shareUid
    };
    return baseRequest('api/manor/create/tree', { params });
}
