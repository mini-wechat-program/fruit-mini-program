export default {
    '3': {
        id: 0,
        img: 'seedsOrange_v3',
        boxImg: 'selectSeedV3KiwiV2',
        name: '橘子',
        type: 3,
        weight: 2
    },
    '6': {
        id: 1,
        img: 'seedsLemon',
        boxImg: 'selectSeedV3Lemon',
        name: '柠檬',
        type: 6,
        weight: 2
    },
    '2': {
        id: 2,
        img: 'seedsPear_v4',
        boxImg: 'selectSeedV3PearV2',
        name: '梨子',
        type: 2,
        weight: 5
    },
    '1': {
        id: 3,
        img: 'seedsApple_v4',
        boxImg: 'selectSeedV3AppleV3',
        name: '苹果',
        type: 1,
        weight: 3
    },
    '7': {
        id: 4,
        img: 'seedsKiwi_v2',
        boxImg: 'selectSeedV3KiwiV3',
        name: '猕猴桃',
        type: 7,
        weight: 2
    },
    '8': {
        id: 5,
        img: 'seedsShiliu',
        boxImg: 'selectSeedV3KiwiV2',
        name: '石榴',
        type: 8,
        weight: 3
    },
    '9': {
        id: 6,
        img: 'seedsYouzi_v2',
        boxImg: 'selectSeedV3YouziV2',
        name: '柚子',
        type: 9,
        weight: 5
    },
    '10': {
        id: 7,
        img: 'seedsHetao_v2',
        boxImg: 'selectSeedV3HetaoV3',
        name: '核桃',
        type: 10,
        weight: 1
    },
    '11': {
        id: 8,
        img: 'seedsHongzao_v3',
        boxImg: 'selectSeedV3HongzaoV3',
        name: '红枣',
        type: 11,
        weight: 1
    },
    '12': {
        id: 9,
        img: 'seedsChengzi',
        boxImg: 'selectSeedV3OrangeV3',
        name: '橙子',
        type: 12,
        weight: 2
    },
    '4': {
        id: 10,
        img: 'seedsMongo_v5',
        boxImg: 'selectSeedV3KiwiV2',
        name: '芒果',
        type: 4,
        weight: 2
    },
};

export const NEW_FRUIT_CONFIG = {
    '1': {
        id: 0,
        img: 'seedsApple_v5',
        boxImg: 'selectSeedV3AppleV3',
        name: '苹果',
        type: 1,
        weight: 3
    },
    '2': {
        id: 1,
        img: 'seedsPear_v4',
        boxImg: 'selectSeedV3PearV2',
        name: '梨子',
        type: 2,
        weight: 5
    },
    '3': {
        id: 2,
        img: 'seedsOrange_v5',
        boxImg: 'selectSeedV3KiwiV2',
        name: '橘子',
        weight: 2
    },
    '4': {
        id: 3,
        img: 'seedsMongo_v5',
        boxImg: 'selectSeedV3KiwiV2',
        name: '芒果',
        weight: 2
    },
    '5': {
        id: 4,
        img: 'seedsOrange_v3',
        boxImg: 'selectSeedV3KiwiV2',
        name: '木瓜',
        weight: 2
    },
    '6': {
        id: 5,
        img: 'seedsLemon_v5',
        boxImg: 'selectSeedV3Lemon',
        name: '柠檬',
        type: 6,
        weight: 2
    },
    '7': {
        id: 6,
        img: 'seedsKiwi_v5',
        boxImg: 'selectSeedV3KiwiV3',
        name: '猕猴桃',
        type: 7,
        weight: 2
    },
    '8': {
        id: 7,
        img: 'seedsShiliu',
        boxImg: 'selectSeedV3KiwiV2',
        name: '石榴',
        type: 8,
        weight: 3
    },
    '9': {
        id: 8,
        img: 'seedsYouzi_v2',
        boxImg: 'selectSeedV3YouziV2',
        name: '柚子',
        type: 9,
        weight: 5
    },
    '10': {
        id: 9,
        img: 'seedsHetao_v5',
        boxImg: 'selectSeedV3HetaoV3',
        name: '核桃',
        type: 10,
        weight: 1
    },
    '11': {
        id: 10,
        img: 'seedsHongzao_v5',
        boxImg: 'selectSeedV3HongzaoV3',
        name: '红枣',
        type: 11,
        weight: 1
    },
    '12': {
        id: 11,
        img: 'seedsChengzi_v5',
        boxImg: 'selectSeedV3OrangeV3',
        name: '橙子',
        type: 12,
        weight: 2
    },
};
