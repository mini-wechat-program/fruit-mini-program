import { action, runInAction, observable, autorun } from 'mobx';
import { BasePopupStore } from "../basePopupStore";
import { getNewPlantInfo, createSeed } from './request';
import { NEW_FRUIT_CONFIG } from './selectSeedConfig';
import { emptyArray } from '../../../../utils/util';
import { myUserInfoStore } from '../../../../store/userInfo';

const DEFAULT_AVATAR = '//pinduoduoimg.yangkeduo.com/cartoon_activity/fruiter/dynamicAppleV2.png';
const DEFAULT_DATA = [
    { id: 0, avatar: DEFAULT_AVATAR, nickname: '猴哥猴哥', 'gain_number': 10 },
    { id: 1, avatar: DEFAULT_AVATAR, nickname: '雨天', 'gain_number': 8 },
    { id: 2, avatar: DEFAULT_AVATAR, nickname: '一飞冲天', 'gain_number': 1 },
];

const processGainList = gainList => {
    let newGainList = DEFAULT_DATA;
    if (!emptyArray(gainList)) {
        newGainList = gainList
            .sort((a, b) => b['gain_number'] - a['gain_number'])
            .map((item, i) => ({
                ...item,
                avatar: item.avatar,
                id: i,
            }));
    }
    return newGainList;
};

const processFruitList = fruitList =>
    (fruitList || [])
        .slice(0, 3)
        .map(item => ({
            ...item,
            ...NEW_FRUIT_CONFIG[item.fruit_type]
        }));

class SelectSeedStore extends BasePopupStore {

    @observable fruitList = [];
    @observable gainList = [];
    @observable choice = {};

    constructor() {
        super();
        autorun(() => {
            const data = myUserInfoStore.data;
            if (myUserInfoStore.loadingState === 'success' && (data.is_new_user || !data.product)) {
                this.open();
            }
        })
    }

    @action
    open() {
        super.open();
        getNewPlantInfo()
            .then(data => {
                runInAction(() => {
                    this.fruitList = processFruitList(data.fruit_info_list);
                    this.gainList = processGainList(data.friend_gain_list);
                    this.choice = this.fruitList.find(item => item.is_default) || this.fruitList[0]
                });
            })
            .catch(e => {
                runInAction(() => {
                    this.fruitList = [];
                    this.gainList = DEFAULT_DATA;
                });
                throw e;
            });
    }

    @action
    selectSeed(){
        createSeed(this.choice.type).then(data=>{
            myUserInfoStore.setUser(data);
            this.close();
        })
    }
}

const selectSeedStore = new SelectSeedStore();
export default selectSeedStore;
