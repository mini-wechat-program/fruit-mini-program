export const FRUITER_NAME = {
    1: '苹果',
    2: '梨',
    3: '橘子',
    4: '芒果',
    5: '木瓜',
    6: '柠檬',
    7: '猕猴桃',
    8: '石榴',
    9: '柚子',
    10: '核桃',
    11: '红枣',
    12: '橙子'
}

export const UPGRADE_BIG_TITLE = {
    2: '树长成树苗啦',
    3: '树长成大树啦',
    4: '树开花啦',
    5: '树结果啦',
    6: '成熟啦'
}

export const FRUITER_IMAGE = {
    '1': 'Apple',
    '2': 'Pear',
    '3': 'Orange',
    '4': 'Mango',
    '5': 'Papaya',
    '6': 'Lemon',
    '7': 'Kiwi',
    '8': 'Shiliu',
    '9': 'Youzi',
    '10': 'Hetao',
    '11': 'Hongzao',
    '12': 'Orange', // 橙子树的图片与橘子公用
}

export const FRUITER_PROCESS = {
    '3': 'Growing',
    '4': 'Blooming',
    '5': 'Fruiting',
    '6': 'Mature',
}