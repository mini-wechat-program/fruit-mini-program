import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import { observer } from '@tarojs/mobx'
import ui from '@wx_common/ui/index';
import Anti from '@wx_common/risk-control-anti';
import { imageUtil } from '@utils/imageUtil';
import Popup from '@components/widgets/popup/popup';
import Overlay from '@components/widgets/popup/overlay';
import PopupBody from '@components/widgets/popup/body';
import upgradeFruiterStore from './store'

import { reaction } from 'mobx'
import { globalStore } from '../../../../store/userInfo'

import { gainWater } from '../../../../apiRequest'

import './style.scss';

@observer
class UpgradeFruiter extends Component {
    constructor(props) {}

    componentDidMount = () => {
        const options = {
            serverTime: Date.now()
        };
        this.riskControlCrawler = new Anti(options);
        // 避免监听到globalStore的初始化
        setTimeout(() => {
            reaction(() => globalStore.product.level, level => {
                upgradeFruiterStore.init(globalStore.product.type, level)
            });
        }, 1000);
    }

    closePopup = () => {
        upgradeFruiterStore.popupClose();
    }

    // 升级领水
    toGainWater = () => {
        const antContent = this.riskControlCrawler.messageDepacketize();
        let params = {
            mission_type: 6,
            gain_time: 1,
            screen_token: antContent
        }
        gainWater(params).then((data) => {
            ui.showToast('已成功领取水滴,快去浇水吧~');
            this.closePopup();
        })
        .catch((ex) => {
            // 领取奖励接口调用业务错误吞下
            ui.showToast(ex);
        });
    }

    render () {
        const treeLevel = globalStore.product.level;
        const popupInfo = upgradeFruiterStore.popupInfo || {}
        return (
            upgradeFruiterStore.show && <View>
                <Popup>
                    <Overlay></Overlay>
                    <View className='upgrade-fruiter-wrapper'>
                        <PopupBody>
                            <Image className='upgrade-fruiter-close' onClick={this.closePopup} src={imageUtil('commonPopupCloseButtonV2')} />
                            <Image className='popup-item upgrade-fruiter-ribbon' src={imageUtil('upgrade_ribbon_v2')} />
                            <View className='popup-item upgrade-fruiter-big-title'>{popupInfo.bigTitle}</View>
                            <View className='upgrade-fruiter-small-title'>{popupInfo.smallTitle}</View>
                            <View className='upgrade-fruiter-img-wrapper'>
                                <Image className='upgrade-fruiter-img' src={imageUtil(popupInfo.fruiterImg)} />
                                <Image className='popup-item upgrade-fruiter-shine' src={imageUtil('commonPopupShineV2')} />
                                <Image className='popup-item upgrade-fruiter-root' src={imageUtil('commonPopupTreeRoot')} />
                            </View>
                            {treeLevel !== 6 ? <View className='popup-item upgrade-fruiter-button' onClick={this.toGainWater}>
                                点击领取+<Image className='upgrade-fruiter-button-water' src={imageUtil('achievementWater')} />20g
                            </View> : <View className='popup-item upgrade-fruiter-gain-button'>分享给好友，收获果实</View>}
                        </PopupBody>
                    </View>
                </Popup>
            </View>
        );
    }
}

export default UpgradeFruiter;