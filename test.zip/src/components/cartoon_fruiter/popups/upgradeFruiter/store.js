import { observable, action } from 'mobx';
import { BasePopupStore } from "../basePopupStore";
import { FRUITER_NAME, UPGRADE_BIG_TITLE, FRUITER_IMAGE, FRUITER_PROCESS } from './constants'

const specialType = [4, 5, 6, 7, 8, 9, 10, 11]; // 芒果和木瓜、柠檬等的树不一样

class firendListStore extends BasePopupStore {
    
    @observable popupInfo = {
        bigTitle: '',
        smallTitle: '',
        fruiterImg: ''
    }

    // 初始化弹窗所需信息
    @action
    init(type, level){

        this.popupInfo.bigTitle = FRUITER_NAME[type] + UPGRADE_BIG_TITLE[level];
        switch (level) {
            case 1:
            case 2:
                this.popupInfo.fruiterImg = 'bud_v2';
                break;
            case 3:
            case 4:
                this.popupInfo.smallTitle = '距离收获' + FRUITER_NAME[type] + '又近了一步哦';
                if (specialType.indexOf(type) > 0) {
                    this.popupInfo.fruiterImg = 'commonPopup' + FRUITER_PROCESS[level] + FRUITER_IMAGE[type] + 'V2';
                } else {
                    this.popupInfo.fruiterImg = 'commonPopup' + FRUITER_PROCESS[level] + 'V2';
                }
                break;
            case 5:
                this.popupInfo.smallTitle = '距离收获' + FRUITER_NAME[type] + '只剩最后一步咯'
                this.popupInfo.fruiterImg = 'commonPopup' + FRUITER_PROCESS[level] + FRUITER_IMAGE[type] + 'V2';
                break;
            case 6:
                this.popupInfo.fruiterImg = 'commonPopup' + FRUITER_PROCESS[level] + FRUITER_IMAGE[type] + 'V2';
                break;
        }
        super.open();
    }

    @action
    popupClose = () => {
        this.popupInfo = {
            bigTitle: '',
            smallTitle: '',
            fruiterImg: ''
        };
        super.close();
    }
}

export default firendListStore = new firendListStore()