import Taro, { Component } from '@tarojs/taro';
import { View, Image, Block } from '@tarojs/components';
import { observer, inject, computed } from '@tarojs/mobx';
import classnames from 'classnames';

import Anti from '@wx_common/risk-control-anti';
import { imageUtil } from '../../../../../utils/imageUtil';
import { throttle } from '../../../../../utils/decorators';
import ui from '@wx_common/ui/index';
import { costWater, minusWaterCD } from '../../../../../apiRequest/fruiter/water';

import CountDown from '../../../../widgets/countDown';
import './index.scss';

const BOTTLE = imageUtil('wateringBottle_v4');
const SUPER_BOTTLE = imageUtil('equip_300_301_bottle');
// 普通背景
const BOTTLE_BG = imageUtil('wateringBg_v4');
const SUPER_BOTTLE_BG = imageUtil('equip_300_301_bg');
// 空背景
const SUPER_BOTTLE_EMPTY_BG = imageUtil('equip_300_301_empty');
const BOTTLE_EMPTY_BG = imageUtil('wateringBgEmpty_v3');
// cd背景
const SUPER_BOTTLE_FORBID_BG = imageUtil('equip_300_301_forbid_v2');
const BOTTLE_FORBID_BG = imageUtil('wateringBottleforbid_v3');

const WATERING = imageUtil('watering-water');
const ABSORB_BG = imageUtil('absorb_countdown');

@inject('globalStore')
@observer
class WaterBottle extends Component {
    static externalClasses = ['clarity-class']
    state = {
        isWatering: false,
        serverWaterCD: 0,
        waterCD: 0,
        waterOuting: false
    }
    riskControlCrawler = null
    get img() {
        let bg;
        let bottle;
        if (this.props.globalStore.currentUser.equipmentListStore.hasSuperBottle) {
            bottle = SUPER_BOTTLE;
            if (this.state.isWatering) {
                bg = SUPER_BOTTLE_EMPTY_BG;
            } else if (this.state.waterCD > 0) {
                bg = SUPER_BOTTLE_FORBID_BG;
            } else {
                bg = SUPER_BOTTLE_BG;
            }
        } else {
            bottle = BOTTLE;
            if (this.state.isWatering) {
                bg = BOTTLE_EMPTY_BG;
            } else if (this.state.waterCD > 0) {
                bg = BOTTLE_FORBID_BG;
            } else {
                bg = BOTTLE_BG;
            }
        }
        return {
            bg,
            bottle
        };
    }
    get currentUser() {
        return this.props.globalStore.currentUser;
    }
    componentDidMount() {
        const options = {
            serverTime: Date.now()
        };
        this.riskControlCrawler = new Anti(options);

        const cd = this.props.globalStore.currentUser.data['next_valid_water_time'];
        this.setState({
            serverWaterCD: cd * 1000,
            waterCD: cd * 1000
        });
    }
    bottleClick() {
        if (this.state.waterCD <= 4000 && this.state.waterCD > 0) {
            this.minusCD(4000);
            return;
        }
        const waterCD = this.state.waterCD - 1000;

        this.setState({
            waterCD
        });
        if (waterCD > 0) {
            this.minusCD();
        } else {
            this.watering();
        }
    }
    @throttle(2500)
    minusCD(millSec) {
        minusWaterCD((millSec / 1000) || (this.state.serverWaterCD - this.state.waterCD) / 1000)
            .then((data) => {
                if (data.success) {
                    this.setState({
                        serverWaterCD: this.state.serverWaterCD - (millSec || (this.state.serverWaterCD - this.state.waterCD))
                    });
                }
            });
        // new Promise((resolve) => {
        //     resolve()
        // }).then(() => {
        //     this.setState({
        //         serverWaterCD: this.state.serverWaterCD - (millSec || (this.state.serverWaterCD - this.state.waterCD))
        //     });
        // });
        return;
    }
    @throttle(300)
    watering() {
        if (this.state.isWatering) {
            return;
        }
        const antContent = this.riskControlCrawler.messageDepacketize();
        costWater(antContent).then((data) => {
            this.setState({
                waterCD: data['next_valid_water_time'] * 1000,
                serverWaterCD: data['next_valid_water_time'] * 1000,
                isWatering: true
            });
            this.currentUser.setWaterAmount(data['now_water_amount']);
            this.currentUser.productStore.setProduct(data.product);
            setTimeout(() => {
                this.setState({
                    waterOuting: true
                });
            }, 2200);
            setTimeout(() => {
                this.setState({
                    isWatering: false,
                    waterOuting: false
                });
            }, 4000);
        }).catch((errmsg) => {
            ui.showToast(errmsg);
            this.setState({
                waterCD: 0
            });
        });
        // new Promise((resolve) => {
        //     resolve({"next_valid_water_time":20,"now_water_amount":338,"product":{"type":1,"status":1,"progress":80,"level_amount":20,"level_own_amount":0,"level":5,"episode_type":null,"progress_time":1544690080,"exchange_type":null,"exchange_sn":null,"product_number":null,"is_withered":false,"health_degree":75,"nutrient":5,"saved_water":5,"fertilize_degree":0},"mission_dto":null,"popup_vo":{"nutrient_window":0,"lottery_window":0},"first_water":false,"need_show_nutrient_icon":true,"random_reward_vo":null,"has_set_address":false,"next_available_time":0,"server_time":1544690080});
        // })
        //     .then((data) => {
        //         this.setState({
        //             waterCD: data['next_valid_water_time'] * 1000,
        //             serverWaterCD: data['next_valid_water_time'] * 1000,
        //             isWatering: true
        //         });
        //         this.currentUser.setWaterAmount(data['now_water_amount']);
        //         this.currentUser.productStore.setProduct(data.product);
        //         setTimeout(() => {
        //             this.setState({
        //                 waterOuting: true
        //             });
        //         }, 2200);
        //         setTimeout(() => {
        //             this.setState({
        //                 isWatering: false,
        //                 waterOuting: false
        //             });
        //         }, 4000);
        //     })
        //     .catch((errmsg) => {
        //         console.log(errmsg);
        //     });
    }
    countDownFinish() {
        this.setState({
            waterCD: 0
        });
        minusWaterCD(this.state.serverWaterCD / 1000)
            .then((data) => {
                if (data.success) {
                    this.setState({
                        serverWaterCD: 0
                    });
                }
            });
        // new Promise((resolve) => {
        //     resolve()
        // }).then(() => {
        //     this.setState({
        //         serverWaterCD: 0
        //     });
        // });
    }
    onCountDown(leftTime) {
        this.setState({
            waterCD: leftTime
        });
    }
    render() {
        const currentUser = this.props.globalStore.currentUser;
        const waterAmount = this.props.globalStore.currentUser.waterAmount;

        return (
            <View className='water-bottle-box'>
                <Image className='bottle-bg' src={this.img.bg} />
                <View className={classnames('count-down-box', { special: currentUser.equipmentListStore.hasSpeedUpBall })}>
                    {
                        this.state.waterCD > 0 && !this.state.isWatering
                            ? <Block>
                                <Image className="absorb-bg" src={ABSORB_BG} />
                                <CountDown
                                    showNumberAmount={2}
                                    timeLong={this.state.waterCD}
                                    onCountDownFinish={this.countDownFinish.bind(this)}
                                    onCountDown={this.onCountDown.bind(this)} />
                            </Block>
                            : null
                    }
                </View>

                <View className="bottle-container" onClick={this.bottleClick}>
                    <View className={classnames('bottle-outer', { active: this.state.isWatering })}>
                        <Image
                            className={classnames(
                                'bottle',
                                { 'clarity-class': !this.state.isWatering && this.state.waterCD > 0 },
                                { active: this.state.isWatering },
                            )} 
                            src={this.img.bottle} />
                    </View>
                    <Image
                        className={classnames(
                            'bottle-water',
                            { active: this.state.waterOuting },
                        )}
                        src={WATERING}
                    />
                </View>

                <View className='water-amount'>{waterAmount || 0}</View>
            </View>
        );
    }
}

export default WaterBottle;
