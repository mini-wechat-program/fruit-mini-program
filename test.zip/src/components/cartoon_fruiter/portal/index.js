import Taro, { Component } from '@tarojs/taro';
import classnames from 'classnames';

import { View, Image } from '@tarojs/components';
import { observer, inject } from '@tarojs/mobx';

import './index.scss';

import { isNightTime } from '../../../utils/timeUtil';
import { imageUtil } from '../../../utils/imageUtil';
import { getTreeByLevel } from '../../../utils/garden/playerUtil/index';
import { baseRequest } from '../../../utils/requestUtil';

import FriendList from '../friendList';
import MissionList from '../missionlist';
import IconList from '../iconList';
import WaterBottle from './components/waterBottle';
import UpgradeFruiter from '../popups/upgradeFruiter';
import { initGlobal } from '../../../utils/garden/global';

const BG = imageUtil('fruiterBgNoon');
const BG_NIGHT = imageUtil('fruiterBgNight');
const GOOD_TREE_LAND = imageUtil('health_good_land_v2');

@inject('globalStore')
@observer
class Fruiter extends Component {
  config = {
      navigationBarTitleText: '多多果园'
  }
  componentWillMount () { }

  componentWillReact () {
      console.log('componentWillReact');
  }

  componentDidMount () {
      baseRequest('api/manor/tree/get')
        .then((data) => {
            this.props.globalStore.currentUser.setUser(data);
            this.init();
            initGlobal(data.server_time * 1000)
      })
        .catch((errMsg) => {
          console.log(errMsg);
      });
  }

  componentWillUnmount () { }

  componentDidShow () { }

  componentDidHide () { }

  init() {
      this.setState({
          isNight: isNightTime(),
          tremble: false
      });
      this.clearTreeAnimateInterId = null;
  }

  onClickTree () {
      if (this.state.tremble) {
        if (this.clearTreeAnimateInterId) {
            clearInterval(this.clearTreeAnimateInterId);
        }
        this.setState({ tremble: false }, () => {
            this.setState({ tremble: true });
            this.clearTreeAnimateInterId = setTimeout(() => {
                this.setState({ tremble: false });
            }, 1000);
        });
      } else {
        this.setState({ tremble: true });
        this.clearTreeAnimateInterId = setTimeout(() => {
            this.setState({ tremble: false });
        }, 1000);
      }
  }

  render () {
      const globalStore = this.props.globalStore;
      const treeImgName = getTreeByLevel(globalStore.currentUser.productStore);
      const treeImgUrl = imageUtil(treeImgName);
      const initWaterCD = this.props.globalStore.currentUser.data['next_valid_water_time'];
      const isShowWaterBottle = typeof initWaterCD === 'number';

      return (
          <View className={classnames('fruit-container', { night: this.state.isNight })}>
              <Image className='bg' src={this.state.isNight ? BG_NIGHT : BG} />
              {/* 相当于ui-container */}
              <View className='main-container'>
                  <View className='tree-container'>
                      {/* 树 */}
                      <View className='tree'>
                          <View className='back-tree'></View>
                          <View className='tree-body'>
                              <Image className={classnames('tree-body-img', treeImgName, this.state.tremble ? 'tremble' : '')}
                                     onClick={this.onClickTree} src={treeImgUrl} />
                          </View>
                          <View className='front-tree'>
                              <View className='fruit'></View>
                              <View className='trick'></View>
                          </View>
                      </View>
                      {/* 树盆 */}
                      <View className='tree-land'>
                          <Image className='tree-land-img' src={GOOD_TREE_LAND} />
                      </View>
                  </View>
                  {/* 水壶 */}
                  {
                      isShowWaterBottle
                          ? <WaterBottle
                            clarity-class="clarity" />
                          : null
                  }
              </View>
              <FriendList></FriendList>
              <MissionList></MissionList>
              <IconList></IconList>
              <UpgradeFruiter />
          </View>
      );
  }
}

export default Fruiter;
