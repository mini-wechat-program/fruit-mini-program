/**
 * 当需要倒计时的时候实例化该组件
 * 传参参考defaultProps
 */

import Taro, { Component } from '@tarojs/taro';

import { View, Text, Block } from '@tarojs/components';

class CountDown extends Component {
    static defaultProps = {
        // 展示数字的数量，不包括十分之一秒
        showNumberAmount: 2,
        // 是否显示十分之一秒
        isShowOneThenthSecond: false,
        // 倒计时总长
        timeLong: 0,
        // 头尾文字
        preText: '',
        backText: ''
    }
    state = {
        startTimeStamp: 0,
        endTimeStamp: 0,
        nowTimeStamp: 0
    }
    timer = null
    componentDidMount() {
        const startTimeStamp = Date.now();
        this.setState({
            startTimeStamp,
            nowTimeStamp: startTimeStamp,
            endTimeStamp: startTimeStamp + this.props.timeLong
        });
        this.startCountDown();
    }
    componentWillReceiveProps(nextProps) {
        if (this.props.timeLong !== nextProps.timeLong) {
            this.setState({
                endTimeStamp: Date.now() + nextProps.timeLong
            }, () => {
                // console.log('111', this.state.endTimeStamp)
            });
        }
    }
    startCountDown() {
        this.timer = setInterval(() => {
            const nowTimeStamp = Date.now();
            if (nowTimeStamp >= this.state.endTimeStamp) {
                // console.log(this.props.onCountDownFinish)
                clearInterval(this.timer);
                // 倒计时结束调用
                this.props.onCountDownFinish && this.props.onCountDownFinish();
                return;
            }
            this.setState({
                nowTimeStamp
            }, () => {
                this.props.onCountDown && this.props.onCountDown(this.state.endTimeStamp - this.state.nowTimeStamp);
                // console.log('222', this.state.endTimeStamp)
            });
        }, 100);
    }

    render() {
        const delTime = this.state.endTimeStamp - this.state.nowTimeStamp;

        const oneTenthSec = Math.floor(delTime % 100);
        const sec = Math.floor(delTime % (60 * 1000) / 1000);
        const min = Math.floor(delTime % (3600 * 1000) / (60 * 1000));
        const hour = parseInt(delTime % (3600000 * 24) / (3600 * 1000));
        const date = parseInt(delTime / (3600000 * 24));

        return (
            <View className="expire-time">
                <Text className="normal">{this.props.preText}</Text>
                {
                    this.showNumberAmount > 3
                        ? <Block>
                            <Text className="num date">{date}</Text>
                            <Text className="op">:</Text>
                        </Block>
                        : null
                }
                {
                    this.showNumberAmount > 2
                        ? <Block>
                            <Text className="num hour">{hour}</Text>
                            <Text className="op">:</Text>
                        </Block>
                        : null
                }
                {
                    this.showNumberAmount > 1
                        ? <Block>
                            <Text className="num min">{min}</Text>
                            <Text className="op">:</Text>
                        </Block>
                        : null
                }

                <Text className="num sec">{sec}</Text>

                {
                    this.props.isShowOneThenthSecond
                        ? <Block>
                            <Text className="op">.</Text>,
                            <Text className="num millsec">{oneTenthSec}</Text>
                        </Block>
                        : null
                }
                <Text className="normal">{this.props.backText}</Text>
            </View>
        );
    }
}

export default CountDown;
