import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components';
import Popup from '../popup';
import Overlay from '../overlay';
import './style.scss';
import { imageUtil } from '../../../../utils/imageUtil';

class AwardPopup extends Component {
    render() {
        const { content } = this.props;
        return (
            <Popup>
                <Overlay></Overlay>
                <View className='award'>
                    <View className='item'>
                        <Image className='lignt' src={imageUtil('treasureBoxLight')} />
                    </View>
                    <View className='item'>
                        <Image className='dot' src={imageUtil('treasureBoxDot_v2')} />
                    </View>
                    <View className='item'>
                        {this.props.children}
                    </View>
                </View>
                <View className='text'>{content}</View>
                <View>{this.props.renderExtra}</View>
            </Popup>
        );
    }
}

export default AwardPopup;