import Taro, { Component } from '@tarojs/taro'
import { View, Button } from '@tarojs/components';
import './style.scss'
import { classname } from '../../../../utils/util';
/**
 * type: disabled active normal
 */
class BaseButton extends Component {
    static externalClasses = ['external-class']

    render() {
        const {type} = this.props;
        return (
            <Button className={classname('button external-class', type)} onClick={this.props.onClick}>
                {this.props.children}
            </Button>
        );
    }
}

export default BaseButton;