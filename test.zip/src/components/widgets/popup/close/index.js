import Taro, { Component } from '@tarojs/taro'
import { View, Image } from '@tarojs/components';
import { imageUtil } from '../../../../utils/imageUtil';
import './style.scss';

/**
 * type: inTopRight inTopRightOut
 */
class PopupClose extends Component {
    static externalClasses = ['external-class']

    render() {
        const topRightClose = (
            <View className='top-right external-class' onClick={this.props.onClose}>
                <Image className='img' src={imageUtil('commonPopupCloseButton')} />
            </View>
        );
        const topRightOutClose = (
            <View className='top-right-out external-class' onClick={this.props.onClose}>
                <Image className='img' src={imageUtil('commonPopupCloseButtonV2')} />
            </View>
        );
        return (
            <View>
                {this.props.type === 'inTopRight' ? topRightClose : topRightOutClose}
            </View>
        );
    }
}

export default PopupClose;