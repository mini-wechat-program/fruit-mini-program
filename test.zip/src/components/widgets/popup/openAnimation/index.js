import Taro, { Component } from '@tarojs/taro'
import { View, Image } from '@tarojs/components';
import './style.scss';
import { classname } from '../../../../utils/util';
import { imageUtil } from '../../../../utils/imageUtil';

class OpenAnimation extends Component {
    static externalClasses = ['external-class']

    render() {
        return (
            <View className={classname('title', 'external-class')}>
                <Image className='circle-anim' src={imageUtil('awardPopupCircle')}></Image>
                <Image className='circle-anim' src={imageUtil('awardPopupStar')}></Image>
            </View>
        );
    }
}

export default OpenAnimation;