import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components';
import './style.scss';
import { classname } from '../../../../utils/util';

class Overlay extends Component {
    static externalClasses = ['external-class']

    render() {
        return (
            <View className={classname('overlay', 'external-class')}></View>
        );
    }
}

export default Overlay;