import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components';
import './style.scss';
import { classname } from '../../../../utils/util';

class Popup extends Component {
    static externalClasses = ['external-class']

    render() {
        return (
            <View className={classname('popup', 'external-class')}>
                {this.props.children}
            </View>
        );
    }
}

export default Popup;