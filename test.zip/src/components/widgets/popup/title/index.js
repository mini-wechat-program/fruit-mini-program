import Taro, { Component } from '@tarojs/taro'
import { View, Image } from '@tarojs/components';
import './style.scss';
import { classname } from '../../../../utils/util';
import { imageUtil } from '../../../../utils/imageUtil';

class PopupTitle extends Component {
    static externalClasses = ['external-class']

    render() {
        return (
            <View className={classname('title', 'external-class')}>
                <Image className='img' src={imageUtil(this.props.img || 'health-startup-popup-title')} />
                <View className='content'>
                    {this.props.children}
                </View>
            </View>
        );
    }
}

export default PopupTitle;