import Taro, { Component } from '@tarojs/taro'
// 引入 WebView 组件
import { WebView } from '@tarojs/components'

class App extends Component {
    componentWillMount () {
        this.path = decodeURIComponent(this.$router.params.src); // 输出 { id: 2, type: 'test' }
    }

    render () {
        return (
            <WebView src={this.path}  />
        )
    }
}