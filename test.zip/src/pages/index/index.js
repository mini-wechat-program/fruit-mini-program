import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import { observer, inject } from '@tarojs/mobx';
import User from '@wx_common/user/index';
import ui from '@wx_common/ui/index';
import navigation from '@wx_common/navigation';
import './index.scss';
import { baseRequest } from '../../utils/requestUtil';
import Fruiter from '../../components/cartoon_fruiter/portal';
import Popups from '../../components/cartoon_fruiter/popups';
import logger from  '@wx_common/logger';
import Anti from '@wx_common/risk-control-anti';
import { getShareInfo } from '@wx_common/share/index';
import { shareStatus, defaultShareInfo } from '@wx_common/share/shareInfo';

@observer
class Index extends Component {
  config = {
      navigationBarTitleText: '首页'
  }

  constructor (props) {
      super(props)
      this.state = {
          showMainView: false
      };
    }

  componentWillMount () { }

  componentWillReact () {
    console.log('componentWillReact');
  }

  componentDidCatchError(error){
      logger.trackingRecord({
          op: 'real_error',
          page: error.message + ' errorBoundary error catch ' + JSON.stringify([error.stack])
      });
  }

  componentDidMount () {
    // todo: 此处serverTime应该使用接口获取的服务器时间
    const options = {
        serverTime: Date.now()
    };
    this.riskControlCrawler = new Anti(options);

    setTimeout(() => {
        console.log('anti_content', this.riskControlCrawler.messageDepacketize());
    }, 10000);

    User.requireLogin().then(_ => {
        ui.showConfirm2({
            onConfirm: _ => {
                ui.showToast('点击了确认');
            },
            onCancel: _ => {
                ui.showToast('点击了取消');
            },
            title: '当前选择的地址不支持发货',
            text: '请选择兑换成优惠券或者重新选择地址',
            confirmButtonLabel: '兑换成优惠券',
            cancelButtonLabel: '重新选择地址'
        });

        this.setState({
            showMainView: true
        });
    }).catch(err => {
        ui.showToast('### 登录失败了');
    });
    // 页面初始化生命周期componentDidMount中初始化实例
    // baseRequest('api/server/_stm', {
    //   method: 'GET'
    // }).then((data) => {
    //   const options = {
    //     serverTime: data['server_time'],
    //     scene: 1,
    //     shareTicket: 1
    //   };
    //   const riskControlCrawler = new Anti(options);
    // });
  }

  onCollectData (e) {
      this.riskControlCrawler.swallow(e);
  }

  componentWillUnmount () { }


  componentDidHide () { }

  onShareAppMessage(e) {
    shareStatus.isFromShare = true;
    shareStatus.sucessCallback = null;
    if (e && e.target && e.from === 'button') {
        const missionType = e.target.id;
        const shareInfo = getShareInfo(missionType);
        if (shareInfo) {
            shareStatus.sucessCallback = shareInfo.callback;
            return shareInfo;
        }
    }

    return getShareInfo(defaultShareInfo);
  }

  componentDidShow() {
    if (shareStatus.isFromShare === true) {
      shareStatus.isFromShare = false;
      shareStatus.sucessCallback && shareStatus.sucessCallback();
    }
  }

  render () {
      const { showMainView } = this.state;
      return (
          <view className="portal-container">
            {
                showMainView && (<View
                    className='index'
                    onClick={this.onCollectData}
                    onTouchmove={this.onCollectData}
                    onLongpress={this.onCollectData}>
                    <Fruiter />
                    <Popups />
                </View>)
            }
            <import src='../../wx_common/templates/toast/toast.wxml' />
            <import src='../../wx_common/templates/confirm2Dialog/index.wxml' />
            <template is='fruitToast' data='{{...$toastInfo}}'/>
            <template is='confirm2Dialog' data='{{...$confirm2Data, $c2Confirm, $c2Cancel}}'/>
          </view>
      );
  }
}

export default Index;
