/**
 * @file 道具列表
 * @author huayi
 */
import { observable, action, computed } from 'mobx';
import { getImgByVer } from '../utils/imageUtil';

// 道具type常量
export const DOG = 600;
export const GLOVE = 400;
export const SUPER_BOTTLE = 300;
export const SPEED_UP_BALL = 500;

class EquipmentList {
    @observable list = {};
    @observable dog = null
    @observable glove = null
    @observable superBottle = null
    @observable speedUpBall = null

    // 是否有狗
    @computed get hasDog () {
        return !!this.dog;
    }
    @computed get hasSuperBottle() {
        return !!this.superBottle;
    }
    @computed get hasSpeedUpBall() {
        return !!this.speedUpBall;
    }

    @action setEquipmentList(list) {
        this.list = list || {};

        this.dog = list[DOG];
        this.glove = list[GLOVE];
        this.superBottle = list[SUPER_BOTTLE];
        this.speedUpBall = list[SPEED_UP_BALL];
    }
    // 获取道具图片
    getEquipPic(type, defaultImg, subType) {
        if (this.list[type] && this.list[type].level) {
            const level = this.list[type].level;
            let subTypeStr;
            if (subType) { // 用于同一装备或道具对应多张图片，如水壶、多朵云
                subTypeStr = '_' + subType;
            } else {
                subTypeStr = '';
            }
            const imgName = `equip_${type}_${level}${subTypeStr}`;
            const versionName = getImgByVer(`equip_${type}_${level}${subTypeStr}`);
            return {
                imgName,
                versionName
            };
        } else if (defaultImg) {
            return {
                imgName: defaultImg,
                versionName: getImgByVer(defaultImg),
            };
        }
    };
}

// const equipmentListStore = new EquipmentList();

// export { equipmentListStore };
export default EquipmentList;
