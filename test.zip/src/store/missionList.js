/**
 * @file 任务列表
 * @author huayi
 */
import { observable, action, computed } from 'mobx';

const WAKEUP_MISSION_TYPE = 32;
const GAME_RAIN_TYPE = 35;
class MissionListStore {
    @observable list = {}
    @observable serverTime = 0

    @computed get hasWakeupMission () {
        const keys = Object.keys(this.list);

        return keys.includes(String(WAKEUP_MISSION_TYPE)) && (this.list[WAKEUP_MISSION_TYPE]['friend_lists'] || []).length > 0;
    }
    @computed get isGameRainAllFinished () {
        const keys = Object.keys(this.list);

        return keys.includes(String(GAME_RAIN_TYPE)) && this.list[GAME_RAIN_TYPE]['drawed_count'] === this.list[GAME_RAIN_TYPE]['max_count'];
    }
    // setMissionList传入参数变为上层的data，为了可以保存服务器时间，比较next_available_time和servertime
    @action setMissionList(data) {
        const list = data['mission_list'] || {};

        // const listKeys = Object.keys(list);
        // const listHasWakeupMission = listKeys.includes(String(WAKEUP_MISSION_TYPE));
        // 列表里已经有任务32，则无视传入的任务32
        if (this.hasWakeupMission) {
            this.list = Object.assign(
                list,
                {
                    [WAKEUP_MISSION_TYPE]: this.list[WAKEUP_MISSION_TYPE]
                },
            );
        } else {
            this.list = list;
        }
        this.serverTime = data['server_time'] || data.serverTime;
    }
    @action addMission(mission) {
        this.list[mission.type] = observable(mission);
    }
    getAwardAmountOf (missionType) {
        return this.list[missionType]['reward_amount'] || 0;
    }
}

// const missionListStore = new globalStore.equipmentList;

// export { missionListStore };
export default MissionListStore;
