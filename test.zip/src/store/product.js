import { observable, action, computed } from 'mobx';

class Product {
    // 果树状态
    @observable type = 1
    // 果树等级
    @observable level = 0
    // 健康度
    @observable health = 1
    // 好友枯萎状态
    @observable withered = false
    // 当前等级升级所需水量
    @observable levelAmount = 20
    // 当前水量
    @observable levelOwnAmount = 0
    // 化肥量
    @observable fertilizeDegree = 0;

    @action setProduct(product) {
        if (!product) return;
        this.type = product.type;
        this.level = product.level;
        this.withered = product.is_withered;
        this.levelAmount = product.level_amount;
        this.levelOwnAmount = product.level_own_amount;
        this.fertilizeDegree = product.fertilize_degree;

        if (product.health_degree) this.health = product.health_degree;
    }

    @action setHealth(health) {
        this.health = health;
    }
}

export default Product;
