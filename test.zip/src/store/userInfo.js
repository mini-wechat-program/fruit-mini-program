import { observable, action, computed, reaction } from 'mobx';
import EquipmentList from './equipmentList';
import Product from './product';
import MissionListStore from './missionList';

class UserInfo {
    @observable data = {}

    @observable uid = 0;

    @observable isMyGarden = true;

    // 树下广告位的图片和链接
    @observable guideIcon = {};

    @observable createProductNumber = 0;

    @observable activities = [];

    @observable equipmentListStore = {};

    // 显示养分ICON
    @observable showHealthIcon = false;

    @observable endCaptureScreen = false;

    // 是否风控用户
    @observable isRisk = false;

    @observable waterAmount = 0;
    // 灰度控制
    @observable grayControl = {};
    @observable shareGrayControl = {};

    @observable buffListStore = {};
    @observable portalPopup;

    @observable loadingState = 'pending'

    @computed get isFirstTree() {
        return this.createProductNumber <= 1;
    }

    missionGainPopupReactionDispose = null;

    constructor(isMyGarden) {
        this.isMyGarden = isMyGarden;
        this.productStore = new Product();
        this.equipmentListStore = new EquipmentList();
        this.missionListStore = new MissionListStore();
        // this.buffListStore = new BuffList();
        // this.portalPopup = new PortalPopupStore();
        // this.missionGainPopup = new PortalPopupStore('type');
    }

    @action setUser(userInfo) {
        if (!userInfo) return;
        this.data = userInfo;
        this.loadingState = 'success';

        this.uid = userInfo.uid;
        // this.isMyGarden = String(User.userID) === String(userInfo.uid);
        this.guideIcon = (userInfo['home_page_icon_vo_map'] || {})[1];
        this.createProductNumber = userInfo.create_product_number;
        this.productStore.setProduct(userInfo.product);
        this.activities = userInfo.user_clearance_activity_list || [];
        this.showHealthIcon = userInfo.need_show_nutrient_icon;
        this.isRisk = userInfo.risk;
        this.waterAmount = userInfo.water_amount;

        // 用户重复性活动信息，目前是7天浇水
        this.repeatActivity = userInfo.user_clearance_repeat_activity_list || [];

        // 道具列表
        this.equipmentListStore.setEquipmentList(userInfo.equipment_list || {});
        // 任务列表
        this.missionListStore.setMissionList(userInfo || {});
        // 增益列表
        // this.buffListStore.setBuffList(userInfo.buff_list || []);

        // this.portalPopup.setPopups(userInfo.portal_popup || [], false);
        // this.missionGainPopup.setPopups(userInfo.reward_popup || []);
        // inviteHelpStore.judgeIsOpen();
        // 领取弹窗结束，开始普通弹窗的弹出
        // this.missionGainPopupReactionDispose && this.missionGainPopupReactionDispose();
        // this.missionGainPopupReactionDispose = reaction(
        //     () => {
        //         const popups = this.missionGainPopup.popups;
        //         const isFinish = !popups.some((item) => {
        //             return item.show;
        //         });
        //         return isFinish;
        //     },
        //     (isFinish, reaction) => {
        //         if (isFinish) {
        //             this.portalPopup.showPopup(0, true);
        //             reaction.dispose();
        //         }
        //     }
        // );
    }

    @action
    setGrayControl(data = {}) {
        if (data.gray_control_map) {
            this.grayControl = data.gray_control_map;
        }
    }
    @action
    setShareGrayControl(data = {}) {
        if (data.gray_control_map) {
            this.shareGrayControl = data.gray_control_map;
        }
    }
    @action
    setWaterAmount(amount = 0) {
        this.waterAmount = amount;
    }
    getGray(type) {
        if (this.grayControl && this.grayControl[type]) {
            return true;
        } else {
            return false;
        }
    }
}

class GlobalStore {
    @observable otherUserInfoStore;
    @observable myUserInfoStore;
    @observable isMyGarden = true;
    @observable shareControl = {};

    constructor() {
        this.otherUserInfoStore = new UserInfo(false);
        this.myUserInfoStore = new UserInfo(true);
    }

    @computed get currentUser() {
        return this.isMyGarden ? this.myUserInfoStore : this.otherUserInfoStore;
    }

    @computed get product() {
        return this.currentUser.productStore;
    }
    @computed get equipmentList() {
        return this.currentUser.equipmentListStore;
    }
    @computed get missionList() {
        return this.currentUser.missionListStore;
    }
    @computed get portalPopup() {
        return this.currentUser.portalPopup;
    }

    @action
    setIsMyGarden(is) {
        this.isMyGarden = is;
    }

    @action
    setShareControl(shareControl) {
        if (shareControl) {
            this.shareControl = shareControl.configs || {};
        }
    }

    getShareType(type) {
        return this.shareControl[type] || {};
    }
}

export const globalStore = new GlobalStore();

export const otherUserInfoStore = globalStore.otherUserInfoStore;
export const myUserInfoStore = globalStore.myUserInfoStore;
