
/**
 * 截流，防止函数调用过于频繁
 * @param {Function} fn 需要截流的函数
 * @param {Function} failedFn 被锁时的返回
 * @param {numbet} duraion 延时
 */
export const throttle = function (duraion) {
    return function(target, name, descriptor) {
        const func = descriptor.value;

        let before = Date.now() - duraion;
        descriptor.value = function(...params) {
            const current = Date.now();
            if (current - before >= duraion) {
                before = current;
                return func.call(this, ...params);
            }
        };

        return descriptor;
    };
};