export const MissionType = {
    FRESHER_AWARD: 16, // 新人首单拼团页拼单送水滴
    FRESHER_AWARD_WITH_GOODS: 17, // 新人专区页拼单送水滴
    ACTIVITY_PAGE_GROUP_AWARD: 36,

    SHARE: 1, // "分享"),//1000g上限
    COLLECTION: 2, // "收藏"),//1000g上限
    COLLAGE: 3, // "成功拼团"),
    INVITE_DOWNLOAD: 4, // "拉新"),//1000g上限
    INVITE: 5, // "邀请"), ////1000g上限
    UPGRADE: 6, // "升级"),//1000g上限
    VISIT_FRIEND: 7, // "拜访好友"),
    NEW_USER_AGAIN_LOGIN: 8, // "新用户再次登录"),//1000g上限
    BROWSE_GOODS: 9, // "浏览商品"),//1000g上限
    WATER: 10, // "随机触发送水滴"),
    PLATFORM_COUPON: 11, // "随机触发送平台无门槛券"),
    MERCHANT_COUPON: 12, // "随机触发送店铺商品券"),
    TIME_LIMIT_WATER: 13, // "限时拼单送水滴"),//1000g上限
    LIMIT_TIME_SHARE: 14, // "福袋定时分享"),//1000g上限
    EXTRA_WATER: 15, // "额外水滴"),//1000g上限
    // NEW_USER_ADVERT_ORDER: 16, // "新人首单拼团页拼单送水滴"),//废弃
    // NEW_USER_ZONE_ORDER: 17, // "新人专区页拼单送水滴"),//1000g上限
    BROWSE_GOODS_ONE_MINUTE: 18, // "浏览商品一分钟"),//1000g上限
    COST_WATER_FOR_WITHERED_FRIEND: 19, // "给枯萎好友浇水"),//1000g上限
    LIMIT_TIME_TWO_SHARE: 20, // "二次定时福袋分享"),
    RANDOM_INVITE_WATER: 21, // "随机触发邀请送水滴"),//1000g上限
    NEXT_DAY_LOGIN_REWARD_FOR_WITHERED_PRODUCT: 22, // "给枯萎果树浇水生成第二天登录奖励任务"),//1000g上限
    SUBSCRIBE_OFFICIAL_ACCOUNTS: 23, // "关注微信公众号送水滴"),//1000g上限
    SET_FLOAT_WINDOW: 24, // "设置浮窗送水滴"),//1000g上限
    POOR_ORCHARD_WATER: 25, // "贫困果农页面拼单送水滴"),//1000g上限
    SEVEN_DAY_NO_COST_WATER: 26, // "用户七天没有浇水送水滴"),//1000g上限
    FERTILIZER_INVITE: 27, // "化肥邀请任务"),//邀请
    CLEARANCE_INVITE: 28, // "闯关邀请任务"),
    BROWSE_GOODS_ONE_MINUTE_TWICE_PER_DAY: 29, // "浏览商品一分钟每天两次间隔三小时"),//1000g上限
    FRIEND_ASSIST_REWARD_WATER: 30, // "好友助力送水滴"),//1000g上限
    NEW_PERSON_GO_APP_REWARD_WATER: 31, // "新人去app领取水滴任务"),//1000g上限
    SHARE_INVITE_WITHERED_FRIEND_REWARD_WATER: 32, // "分享邀请枯萎好友浇水任务"),
    THREE_NOT_LOGIN_GARDEN_REWARD_WATER: 33, // "三日未登录果园水滴任务"),//1000g上限
    FAVORATE: 34, // "收藏果园链接任务"),//1000g上限
    WATER_RAIN: 35, // "水滴雨任务"),//1000g上限
    FERTILIZER_GIFT: 37 // 化肥大礼包任务
};