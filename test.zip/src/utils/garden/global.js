import Anti from '@wx_common/risk-control-anti';

// 本地时间与服务器时间的差值
let dt = 0;

// 风控
let anti = null;

export const initGlobal = (serverTime) => {
    dt = serverTime - Date.now();

    anti = new Anti({ serverTime });
}

/**
 * 获取服务器时间
 */
export const getServerTime = () => dt + Date.now();

/**
 * 获取风控字段
 */
export const getAntiContent = () => anti.messageDepacketize();