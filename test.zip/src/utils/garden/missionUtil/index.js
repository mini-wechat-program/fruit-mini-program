// 检测任务是或否存在
export const ifMissionOpen = (missionList, type, time) => {
    if (!missionList || !missionList[type]) {
        return false;
    }
    if (missionList[type].is_open && missionList[type].finished_count < missionList[type].max_count && time < missionList[type].next_available_time) {
        return true;
    }
    return false;
};

// 检测任务是否完成
export const ifCouldGain = (missionList, type, time) => {
    if (!missionList || !missionList[type]) {
        return false;
    }
    if (missionList[type].drawed_count < missionList[type].finished_count) {
        return true;
    }
    return false;
};

export const ifShowIcon = (missionList, type, time) => {
    const missionOpen = ifMissionOpen(missionList, type, time);
    const missionComplate = ifCouldGain(missionList, type, time);
    if (missionOpen && !missionComplate) {
        return 1;
    }
    if (missionComplate) {
        return 2;
    }
    return 0;
}
