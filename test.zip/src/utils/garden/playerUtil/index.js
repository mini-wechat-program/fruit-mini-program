// import { treeContainerMap } from '../../configs/garden/index';
// import { getImgByVer } from '../../common/imageUtil';
// const isBrowser = typeof window !== 'undefined';
// import platform from '@pdd/platform';
// import User from '@pdd/user';
// import { spriteAttr } from '../../configs/garden/index';
// import inWhiteList from '../../configs/inWhiteList';
// import event, { eventReset } from '../../common/event';
// import eventType from '../../../configs/garden/eventReg';
// import { imageUtil } from '../../common/imageUtil';
// import { randomShareImg } from '../../common/utilMap';
// import { treeNameMap, popUpSwitchIns, LUCKY_WATER_AMOUNT, BIG_LUCKY_WATER_AMOUNT, addressSetting, dServerTime, nooNightRangeOne, nooNightRangeTwo, newPlayerProcess } from '../../configs/garden/globalVar';
// // import { inviteHelpStore, HelpStatus } from '../../store/uiStore/inviteHelpStore';
// // import { rainGameStore } from '../../store/uiStore/rainGameStore';
// import globalPlayerInfo from './playerInfo';
// import { globalStore } from '../../store/userInfo';

export const specialType = [4, 5, 6, 7, 8, 9, 10, 11]; // 芒果和木瓜、柠檬等的树不一样

export const GlobalFresherAward = {
    GlobalFresherAwardType: {}
};
export const treeContainerMap = {
    type: {
        '1': 'apple',
        '2': 'pear',
        '3': 'orange',
        '4': 'mango',
        '5': 'papaya',
        '6': 'lemon',
        '7': 'kiwi',
        '8': 'shiliu',
        '9': 'youzi',
        '10': 'hetao',
        '11': 'hongzao',
        '12': 'orange', // 橙子树的图片与橘子公用
    },
    treeShape: {
        // '0': 'originTree_v4', // 开始种植的牌子
        '1': 'youngTree_v3',
        '2': 'bud_v2',
        '3': 'chengshu_v2',
        '4': 'huashu_v3',
        '5': 'guoshu_v3',
        '6': 'bigTree_v3',
    },
    attach: {
        // '4': 'treeFlower',
        '5': 'Fruit',
        '6': 'Mature',
    },
    healthImg: {
        '0': null,
        '1': 'healthbud',
        '2': 'healthBigTree',
        '3': 'healthFlower',
        '4': 'HealthFruit',
        '5': 'HealthMature',
        '6': 'HealthMature',
    },
    insect: {
        '1': 'littleInsect',
        '2': 'midInsect',
        '3': 'chengshuInsect',
        '4': 'huashuInsect',
        '5': 'guoshuInsect',
        '6': 'maxInsect',
    },
    grass: {
        '1': 'littleGrass',
        '2': 'littleGrass',
        '3': 'chengshuGrass',
        '4': 'huashuGrass',
        '5': 'guoshuGrass',
        '6': 'bigGrass',
    },
    healthText: {
        '1': '就长成幼苗啦',
        '2': '就长大成树啦',
        '3': '就能开花啦',
        '4': '就长出果子啦',
        '5': '包邮送到家',
        '6': '包邮送到家',
    },
};

// 任务列表与模板ID的映射关系
const shareTemplateMap = {
    '1': '6030001', // 水滴分享
    '14-1': '6020001', // 福袋分享 - 早
    '14-2': '6020001', // 福袋分享 - 中
    '14-3': '6020001', // 福袋分享 - 晚
    '14-4': '101404', // 福袋分享 - 50g
    '101': '110101', // 国庆分享
    '4': '100401', // 拉新分享
    '5': '6040001', // 邀请分享
    '20-1': '102001', // 福袋分享翻倍 - 早
    '20-2': '102002', // 福袋分享翻倍 - 晚
};

export const getTreeByLevel = function (product) {
    if (product && specialType.indexOf(product.type) !== -1 && product.level > 2) {
        const treeMap = {
            '4': {
                '3': 'chengshuMango_v2',
                '4': 'huashuMango_v2',
                '5': 'guoshuMango_v2',
                '6': 'bigTreeMango_v2',
            },
            '5': {
                '3': 'chengshuPapaya',
                '4': 'huashuPapaya',
                '5': 'guoshuPapaya',
                '6': 'bigTreePapaya',
            },
            '6': {
                '3': 'chengshuLemon',
                '4': 'huashuLemon',
                '5': 'guoshuLemon',
                '6': 'bigTreeLemon',
            },
            '7': {
                '3': 'chengshuKiwi',
                '4': 'huashuKiwi',
                '5': 'guoshuKiwi',
                '6': 'bigTreeKiwi',
            },
            '8': {
                '3': 'chengshuShiliu',
                '4': 'huashuShiliu',
                '5': 'guoshuShiliu',
                '6': 'bigTreeShiliu',
            },
            '9': {
                '3': 'chengshuYouzi',
                '4': 'huashuYouzi',
                '5': 'guoshuYouzi',
                '6': 'bigTreeYouzi',
            },
            '10': {
                '3': 'chengshuHetao',
                '4': 'huashuHetao',
                '5': 'guoshuHetao',
                '6': 'bigTreeHetao_v2',
            },
            '11': {
                '3': 'chengshuHongzao',
                '4': 'huashuHongzao',
                '5': 'guoshuHongzao',
                '6': 'bigTreeHongzao',
            }
        };
        return treeMap[product.type] ? treeMap[product.type][product.level] : treeContainerMap.treeShape[0];
    }
    return product ? treeContainerMap.treeShape[product.level] : treeContainerMap.treeShape[0];
};
