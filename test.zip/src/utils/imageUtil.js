const debug = false;

export const imageUtil = (imageName, ext) => {
    ext = ext || 'png';
    if (debug) {
        return `assets/img/${imageName}.${ext}`;
    } else {
        return 'http://pinduoduoimg.yangkeduo.com/cartoon_activity/fruiter/' + imageName + '.' + ext;
    }
};

export const preloadImg = (imgs = []) => {
    imgs.forEach(img => {
        const imgTag = new Image();
        imgTag.src = imageUtil(img.name, img.ext);
    });
};

// 一些图片的版本
export const imageVerMap = {
    'fruitShop': '_v2',
    'cloudLeft': '_v2',
    'cloudRight': '_v2',
    'wateringBg': '_v4',
    'wateringBgEmpty': '_v3',
    'wateringBottleForbid': '_v2',
    'wateringBottle': '_v4',
    'attire_100_101': '_v2',
    'attire_300_301': '_v3',
    'equip_400_401': '_v2',
    'attire_300_302': '_v3',
};

export const getImgByVer = (imageName) => {
    if (imageVerMap.hasOwnProperty(imageName)) {
        return imageName + imageVerMap[imageName];
    } else {
        return imageName;
    }
};