import baseRequestResult from "../wx_common/baseRequest/baseRequest";

const errorCodeMap = {
    4000000: '网络错误，请稍后再试',
    10018: '用户状态异常'
};

/**
 * 
 * @param {*} url 
 * @param {Object} opts {method params}
 */
export const baseRequest = function (url, opts = {}) {
    return new Promise((res, rej) => {
        baseRequestResult.apiRequest(
            opts.method || 'POST',
            url,
            opts.params || {},
            (data) => {
                res(data);
            },
            (errorCode) => {
                const errorMsg = errorCode && errorCodeMap[errorCode] ? errorCodeMap[errorCode] : '' + errorCode;
                rej(errorMsg);
            }, null, null, true);
    });
};
