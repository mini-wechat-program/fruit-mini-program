/**
 * 返回时分秒的时间 01:23:34
 * @param time 毫秒
 */
export const countDown = (time = 0) => {
    const t = Math.floor(time / 1000);
    const h = Math.floor(t / 3600) + '';
    const m = Math.floor(t % 3600 / 60) + '';
    const s = Math.floor(t % 3600 % 60) + '';
    return `${h.padStart(2, '0')}:${m.padStart(2, '0')}:${s.padStart(2, '0')}`;
};

export function isNightTime() {
    const date = new Date();
    const hours = date.getHours();
    return hours >= 18 || hours <= 5;
}
