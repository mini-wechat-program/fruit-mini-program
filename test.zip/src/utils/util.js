export const emptyString = str => {
    return !str || (typeof str !== 'string') || (str.trim() === '');
};

export const emptyArray = arr => {
    return !arr || !(arr instanceof Array) || arr.length === 0;
};

export const classname = (...classes) =>{
    return classes.filter(Boolean).join(' ');
}

export const formatTime = (dateTime, pattern = 'yyyy-MM-dd') => {
    dateTime = dateTime || new Date();
    pattern = pattern || 'yyyy-MM-dd';

    const o = {
        'M+': dateTime.getMonth() + 1, //月份
        'd+': dateTime.getDate(), //日
        'h+': dateTime.getHours(), //小时
        'm+': dateTime.getMinutes(), //分
        's+': dateTime.getSeconds(), //秒
        'S': dateTime.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(pattern)) {
        pattern = pattern.replace(RegExp.$1, (dateTime.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (const k in o) {
        if (new RegExp('(' + k + ')').test(pattern)){
            pattern = pattern.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)));
        }
    }
  return pattern;
}
