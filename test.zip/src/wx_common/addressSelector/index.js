import navigation from '@wx_common/navigation';

// 使用demo
// function onSelect(address) {
//     console.log(address);
// }
// addressSelector.setAddress(onSelect);
const addressSelector = {

    setAddress(callback) {
        var app = Taro.getApp() 
        navigation.navigateTo('/package_c/addresses/addresses?chooseFromAcivity=1');

        app.common && app.common.message && app.common.message.off('GOLDEN_EGGS_CHOOSE_ADDRESS');
        app.common && app.common.message && app.common.message.on('GOLDEN_EGGS_CHOOSE_ADDRESS', callback, true);

    }
}

export default addressSelector;