import Taro from '@tarojs/taro';
import UserStorage from '../storage/user_storage.js';
import urlUtil from '../commonUrl/index.js';
import logger from '@wx_common/logger';
import Cmt from '@wx_common/cmt';
import AppConfig from '@wx_common/configs/app_config';
import {
    Message,
    KEYS
} from '../message';

const baseRequestResult = {
    apiRequest(method, url, params, onSuccess,
        onFail, noAuthentication, useNewAPI, skipDefaultErrorHandling, retryDisabled, staticDisabled) {
        try {
            method = method.toUpperCase();
        } catch (e) {
            throw new Error('apiRequest method should be a string');
        }
        if(typeof onFail!=='function'){
            onFail=()=>{};
        }
        let isOther = false;
        if (url.indexOf('http') === 0) {
            isOther = true;
        }
        const arr = url.split('?');
        let fullUrl = '';
        if (isOther) {
            fullUrl = url;
        } else {
            const apiDomain = AppConfig.apiDomain;
            fullUrl = apiDomain + [
                arr[0],
                arr[1]
            ].join('?');
        }
        // 如果是POST请求，就不做重试
        if (method === 'POST') {
            retryDisabled = true;
        }
        const getErrorCode = function (data) {
            if (data == null) {
                return 0;
            }
            const errorCode = data.error_code;
            if (errorCode == null) {
                return null;
            } else if (typeof errorCode === 'number') {
                return errorCode;
            }
            return parseInt(errorCode, 10);
        };
        const apiSuccess = (data, trackingOptions) => {
            // Common.showAlert('apiSuccess');
            const errorCode = getErrorCode(data);
            // 请求打点
            if (trackingOptions) {
                if (errorCode) {
                    trackingOptions.statusCode = errorCode;
                }

                // 当statusCode为undefined时意味着我们的代码出错了，我们不再打error_code -1234
                if (trackingOptions.statusCode !== undefined) {
                  Cmt.tracking(trackingOptions);
                }
            }

            if (errorCode == null) {
                onSuccess(data);
            } else {
                // 如果54001就抛出风控验证事件
                if (errorCode === 54001) {
                    // TODO 风控事件
                }
                // 如果54002就抛出新风控平台验证事件
                if (errorCode === 54002) {
                    // TODO 风控事件
                }
                if ((skipDefaultErrorHandling == null || !skipDefaultErrorHandling) &&
                    this.failHandler) {
                    this.failHandler(errorCode, data);
                }
                onFail(errorCode, data);
            }
        };

        const apiError = (error, trackingOptions) => {
            // 512 冷却请求一段时间
            if (error && error.statusCode === 512 && error.data && error.data.time && error.data.uri) {
                // TODO 冷却事件待处理
            }

            let data = null;
            let errorCode = 0;

            // 现在判断代码出错了而不是请求错误的依据，是一个exception对象， 并且有message
            const isException = error && error.message;

            if (error != null) {
                data = error.data;
                errorCode = getErrorCode(data);
            }

            // 请求打点
            if (trackingOptions && errorCode) {
                trackingOptions.statusCode = errorCode;
                Cmt.tracking(trackingOptions);
            }

            const errorMsg = isException ? error.message : JSON.stringify(error);
            const pages = getCurrentPages();
            const errorInfo = {
                op: 'real_error',
                sub_op: 'api_error',
                url: method + ':' + fullUrl,
                params: JSON.stringify(params || {}),
                page_url: pages.pop().route,
                error_message: errorMsg,
                status_code: error && error.statusCode,
                error_code: errorCode
            };

            let hasLogError = false;
            // 如果errorCode解析失败或者是走static的失败，都重试
            if (errorCode === 0) {
                /*eslint-disable*/
                // TODO kibna错误上报
                hasLogError = true;
                logger.trackingRecord(errorInfo);
                /* eslint-enable */
                if (!retryDisabled && !isException) {
                    apiRetry(method, url, params, onSuccess, onFail, noAuthentication, useNewAPI, skipDefaultErrorHandling, error.statusCode);
                    return;
                }
            }
            // 如果40001就抛出强制登录事件
            if (parseInt(errorCode, 10) === 40001) {
                // 清除本地信息
                UserStorage.clearUserLocalInfo();

                // 发出通知，通知User.js登录
                Message.emit(KEYS.REQUEST_TOKEN_INVALID);

                const self = this;
                // 登录完成后，触发
                Message.on(KEYS.USER_LOGIN_FINISHED, function() {
                    // 重试
                    self.apiRetry(method, url, params, onSuccess, onFail, noAuthentication, useNewAPI, skipDefaultErrorHandling, error.statusCode);
                });
                return;
            } else if (!hasLogError) {
                // TODO 上报
                logger.trackingRecord(errorInfo);
            }

            if ((skipDefaultErrorHandling == null || !skipDefaultErrorHandling) &&
                this.failHandler) {
                this.failHandler(errorCode, data);
            }
            onFail(errorCode, data);
        };

        const accessToken = UserStorage.getAccessToken();
        const headers = {
            'Content-Type': 'application/json;charset=UTF-8',
            'Cache-Control': 'no-cache',
            'AccessToken': accessToken
        };
        const reqTime = Date.now();
        const fetchParams = {
            url: fullUrl,
            method: method,
            data: params ? JSON.stringify(params) : null,
            header: headers
        };
        Taro.request(fetchParams).then(
            function (response) {
                if (response.statusCode < 500) {
                    return {
                        statusCode: response.statusCode,
                        data: response.data
                    };
                }
                const error = new Error(response.statusText);
                /*eslint-disable*/
                error.data = {
                    error_code: 0
                };
                /*eslint -enable*/
                error.statusCode = response.statusCode;
                if (error.statusCode === 512) {
                    error.data = response.data;
                    throw error
                }
                throw error;
            }
        ).then(function (response) {
            if (response.statusCode >= 200 && response.statusCode < 300) {
                return response.data;
            }
            let error = new Error(response.data.error_msg || 'error');
            error.data = response.data;
            error.statusCode = response.statusCode;
            throw error;
        }).then(function (data) {
            apiSuccess(data, {
                requestTime: reqTime,
                resTimeConsume: Date.now() - reqTime,
                reqData: params, // 请求包
                resData: data,
                apiUrl: fullUrl,
                statusCode: 200,
                cmtURL:AppConfig.cmtURL
            });
        }).catch(function (error) {
            apiError(error, {
                requestTime: reqTime,
                resTimeConsume: Date.now() - reqTime,
                reqData: params, // 请求包
                resData: error.data,
                apiUrl: fullUrl,
                statusCode: error.statusCode,
                cmtURL:AppConfig.cmtURL
            });
        });
    },
    apiRetry(method, url, params, onSuccess, onFail,
             noAuthentication, useNewAPI, skipDefaultErrorHandling, statusCode) {
        statusCode = parseInt(statusCode, 10) || 0;
        if(typeof onFail!=='function'){
            onFail=()=>{};
        }
        if (statusCode >= 500) {
            onFail();
            return;
        }
        const self = this;
        const index = url.indexOf('?');
        let search = '';
        if (index >= 0) {
            search = url.substring(index + 1);
            url = url.substring(0, index);
        }
        const queries = urlUtil.parseQuery(search);
        let retryCount = queries.retry || 0;
        if (retryCount < 3) {
            retryCount++;
            let waitTime = retryCount * 2000;
            if (statusCode >= 500) {
                waitTime *= 10;
            }
            setTimeout(function () {
                url = url + '?' + urlUtil.buildQuery(queries, {
                    retry: retryCount
                });
                self.apiRequest(method, url, params, onSuccess, onFail, noAuthentication, useNewAPI, skipDefaultErrorHandling);
            }, waitTime);
        } else {
            onFail();
        }
    },
    failHandler(errorCode, data) {
        return Promise.reject(
            {
                errorCode: errorCode,
                data: data
            }
        );
        //授权失败
        // if (errorCode == '40001') {
        //   return Promise.reject(
        //     {
        //       errorCode: errorCode,
        //       data: data
        //     }
        //   );
        // } else if (errorCode == '40002') { //服务器繁忙
        //   var seconds = null;

        //   if (data != null) {
        //     seconds = data['error_sec'];
        //   }

        //   if (seconds == null) {
        //     seconds = 60;
        //   } else {
        //     seconds = parseInt(seconds, 10);
        //     ui.delayLoad(seconds);
        //   }
        // } else {
        //   ui.showToast(error.getMsgFromCode(errorCode));
        // }
    }
}
export default baseRequestResult;
