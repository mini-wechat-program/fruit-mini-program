/**
 * Created by jiangliuer on 2018/12/14
 */
import Taro from '@tarojs/taro';
import AppConfig from '@wx_common/configs/app_config';
import util from '@wx_common/util'
import {crc32} from './crc32';
import SystemInfo from '@wx_common/systemInfo/system_info';
/**
 * 打点上报的版本号
 * @type {Number}
 */
const TrackingVersion = 1;

/**
 * 网络连接类型
 * @type {Object}
 */
const NetworkTypes = {
    unknown: 0,
    wifi: 1,
    '2g': 2,
    '3g': 3,
    '4g': 4
};

const systemInfo = SystemInfo.getSystemInfoSync();

const cmt={
    getNetWorkType() {
        // 网络类型
        const networkType = 'unknown';
        const promise = new Promise((resolve, reject) => {
            Taro.getNetworkType({
                success: res => resolve(res.networkType),
                fail:()=>{
                    resolve(networkType);
                }
            })
        });

        return promise;
    },
    /**
     * 打点
     */
    tracking(opts = {}) {
        const {
            requestTime, // 请求时间
            resTimeConsume, // 响应耗时
            reqData, // 请求包
            resData, // 响应包
            apiUrl, // 请求api
            statusCode,
            cmtURL // 打点URL
        } = opts;

        let reqDataLen = 0;
        let resDataLen = 0;
        if (reqData) {
            reqDataLen = JSON.stringify(reqData).length;
        }
        if (resData) {
            resDataLen = JSON.stringify(resData).length;
        }

        // 6位数随机整数
        const randomIntVal = util.getRandomInteger(6);

        let send = networkType => {
            let data = {
                v: TrackingVersion, // 打点上报版本号，当前为1
                t: requestTime, // 请求时间，UTC
                r: randomIntVal, // 随机数，int，6位
                c: crc32(requestTime + '-' + randomIntVal), // 校验码
                d: { // 数据
                    t: Date.now(), // 命令字请求时间，UTC
                    tu: apiUrl, // URL
                    n: NetworkTypes[networkType] || 0, // 网络类型，0=UNKNOWN，1=WIFI，2=2G，3=3G，4=4G
                    c: statusCode, // 返回码，建议区分http的返回码，比如>1000为业务错误码，<1000为网络错误码，<0为自定义错误码
                    rt: resTimeConsume, // 响应时间(ms)
                    q: reqDataLen, // 请求包大小(byte)
                    p: resDataLen, // 响应包大小(byte)
                    e: { // 扩展字段
                        uid: util.getSelfUID(), // 用户ID
                        page_id: '10269', // 页面ID
                        model: systemInfo.model // 机型(不太好判断，暂时丢个UA)
                    }
                }
            };

            const fetchParams = {
                url:cmtURL,
                data: JSON.stringify(data),
                header: {
                    'Content-Type': 'application/json;charset=UTF-8'
                },
                method: 'POST',
            };
            Taro.request(fetchParams);
        }

        this.getNetWorkType().then(send);
    }
}
export default cmt;
