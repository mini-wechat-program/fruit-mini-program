export default {
    parseQuery: function (search) {
        if (search == null || search.length <= 0) {
            return {};
        }

        if (search[0] == '?') {
            search = search.substring(1);
        }

        const queries = {};
        const tokens = search.split('&');

        for (let i = 0; i < tokens.length; ++i) {
            const pair = tokens[i].split('=');

            if (pair[0] != null && pair[0].length > 0) {
                const value = pair[1] || '';

                queries[decodeURIComponent(pair[0])] = decodeURIComponent(value);
            }
        }
        return queries;
    },
    buildQuery: function () {
        const pairs = {};

        for (let i = 0; i < arguments.length; ++i) {
            const params = arguments[i];

            for (var key in params) {
                const value = params[key];

                if (key != null && value != null) {
                    pairs[encodeURIComponent(key)] = encodeURIComponent(value);
                }
            }
        }

        let ret = '';

        for (var key in pairs) {
            if (ret.length > 0) {
                ret += '&';
            }

            ret += key + '=' + pairs[key];
        }

        return ret;
    }
};
