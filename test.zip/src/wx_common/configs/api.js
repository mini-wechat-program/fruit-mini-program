/**
 * @Author: QingYou
 * @Date:   2017-03-20T14:18:58+08:00
 * @Filename: api.js
 * @Last modified by:   QingYou
 * @Last modified time: 2017-05-31
 */

const api = {
    indexGoodsList: 'v5/goods',
    orderGoodsDetail: 'v4/goods/{0}',
    createOrder: 'order',
    prePay: 'order/prepay',
    mallInfo: 'mall/{0}/info',
    /* 商家是否需要查看证书*/
    mallCertificated: 'mall/{0}/is_certificated',
    // 查看商家证书的验证码
    mallVerifyCode: 'verification_code_picture',
    // 判断验证码是否错误
    mallVerifyCodeJudge: 'mall/{0}/certificates',
    getAuthorized: 'api/turing/mall/{0}/authorize', // 查看是否有授权证书
    mallCategory: 'api/turing/mall/query_mall_category?mall_id={0}',
    mallCatGoods: 'api/turing/mall/query_cat_goods?mall_id={0}&category_id={1}&type={2}&page_no={3}&page_size={4}&sort_type={5}',
    addresses: 'addresses',
    address: 'address',
    deleteAddress: 'address/delete',
    login: 'login',
    userAB: 'user/is_ab',
    regions: 'regions',
    groupOrder: 'group_order/{0}?need_white=true',
    v2GoodsDetail: 'v5/goods/',
    localGroup: 'goods/{0}/local_group',
    catgoods: 'v4/operation/{0}/groups',
    /* 修改从首页分类进去api，不带v4 */
    noV4Catgoods: 'operation/{0}/groups',
    /* 修改从搜索分类进去的就要走新的api，然后是有广告的 */
    v3CatgoodsList: 'v3/operation/{0}/groups',
    indexPageTopBanner: 'api/fiora/bannerindex/query/platform?platform=5&version=2',
    homeOperations: 'api/fiora/v2/home_operations',
    goodsLocalGroups: 'goods/local_groups',
    luckyDrawResult: 'lucky_draw_result/',
    mallCoupons: 'query_merchant_candidate_coupons',
    platformCoupons: 'query_candidate_coupons',
    takeMerchantCoupon: 'take_merchant_coupon',
    avaCoupons: 'coupon/v2/query_validity_coupons?page={0}&size={1}&fc_version=1&sort_rule=coupon_end_time', // 请求按过期时间排序的前十个未过期未使用的优惠券
    spikeSelloutList: 'spike_list?page={0}&size={1}&nostock=true', // 秒杀售罄列表
    haitaoSpikeSelloutList: 'spike_haitao?page={0}&size={1}&nostock=true', // 海淘秒杀售罄列表
    spikeGoods: 'spike/{0}/goods', // 秒杀api修改
    regionsJson: 'regions_json',
    takeCaptainCoupon: 'coupon/take_one_yuan_coupon',
    cancelOrder: 'order/{0}/cancel',
    subjectCollection: 'subject_collection/{0}',
    promotionCollection: 'promotion/collection/{0}',
    promotionMix: 'promotion/{0}/mix',
    // subjectCollectionGoodsApi: 'subject/{0}/sorted_goods?sort_type={1}&page={2}&size={3}',
    subjectGoodsApi: 'api/fiora/subject/goods?subject_id={0}&page={1}&size={2}&province_id={3}',
    subjectGoodsPush: 'api/fiora/subject/push_goods',
    subjectGoodsLucky: 'api/fiora/subject/lucky_goods',
    subjectRollMessage: 'subject/{0}?roll_message=0',
    weixinAddress: 'address/weixin',
    likeGoods: 'v2/favorite/goods?favorite_update_time={0}&page={1}&size={2}',
    doLikeGoods: 'v2/favorite/like/', // 收藏商品
    unLikeGoods: 'v2/favorite/unlike/', // 取消收藏
    likeRecommend: 'recommendation/favorite?offset={0}&count={1}',
    orderRecommendGoods: 'api/tesla/query?offset={0}&count={1}',
    likeMalls: 'favorite/mall/list?page={0}&size={1}',
    likeMallsGoods: 'api/fiora/mall/{0}',
    unLikeMall: 'favorite/mall/unlike/', // 取消收藏店铺
    doLikeMall: 'favorite/mall/like/', // 收藏店铺
    likeGoodsIdsList: 'favorite/goods/id/list', // 收藏的商品id列表接口
    likeMallsIdsList: 'favorite/mall/id/list', // 收藏的店铺id列表接口
    userIdCard: 'v2/user/card',
    submitIdCard: 'user/card',
    userIdCardWithAuth: 'api/apollo/v3/user/card/update', // 强实名认证接口
    haitaoBanner: 'haitao_banner', // 海淘banner相关信息
    haitaoGoodsList: 'v2/haitaov2?page={0}&size={1}', // 海淘商品列表
    luckyDraw: 'lucky_draw/', // 抽奖信息
    setFormId: 'vino/form_id/set', // 设置formId
    setRefuseFormId: 'api/flow/vino/refuse_form_id/set', // 拒绝formId上报
    ordersv2: 'ordersv2/{0}?page={1}&size={2}', // 订单列表的接口
    newOrdersv2: 'api/aristotle/order_list', // 订单列表的接口
    myGroup: 'order/group_orders?page={0}&size={1}', // 获取我的拼单
    homeSubject: 'home_show', // 首页相关
    chat_list: 'api/rainbow/latest_conversations?page={0}&size={1}', // 拉取客服会话消息列表
    afterSales: 'after_sales/list?range={0}&offset={1}&size={2}', // 获取退款售后
    // moneyPath: 'after_sales/refund_trace/{0}?after_sales_id={1}', //获取钱款去向
    moneyPath: 'api/weaver/refund/track?order_sn={0}', // 获取钱款去向（新接口不需要售后id）
    afterSalesForm: 'order/{0}', // 获取申请退款表单数据
    afterSalesDetail: 'after_sales/detail/{0}', // 查询一个订单的详情
    afterSalesTrigger: 'after_sales/trigger/{0}', // 检查该用户是否频繁创建售后
    afterSalesFormSelect: 'after_sales/all/reason?order_sn={0}', // 获取申请退款的下拉选项
    afterSalesCreate: 'after_sales/create', // 创建一个售后单
    express_complaint: 'express/logistics_complaint_type_detail/get', // 投诉物流选项
    express_complaint_form: 'api/express/express/logistics_complaint/user/create', // 提交投诉物流表单
    getUploadFileSign: 'file/signature', // 获取图片上传签名
    uploadFileUrl: 'https://file.yangkeduo.com/general_file', // 图片上传接口
    getOpenGid: 'api/apollo/query_open_gid',
    cancelAfterSales: 'after_sales/cancel/{0}', // 撤销售后单
    reapplyAfterSales: 'after_sales/reapply/{0}', // 用户重申售后单
    modifyAfterSales: 'after_sales/modify/{0}', // 用户修改售后单
    economicalBrandTabInfo: 'famous_brand', // 名品折扣专题页的tab信息
    economicalBrandGoodsInfo: 'famous_brand/{0}/v2/list', // 名品折扣专题页的商品信息
    brandSubjectBrandDetail: 'famous_brand/{0}/brand', // 名品折扣专题页的品牌详情
    brandSubjectGoodsDetail: 'famous_brand/{0}', // 名品折扣专题页的品牌详情
    myFootPrint: 'footprint/goods/listall', // 历史浏览数据获取接口
    afterSaleAppend: 'after_sales/append_content/{0}', // 补充售后信息
    silentLogin: 'login', // 静默登录
    fillReturnForm: 'after_sales/confirm_delivery/{0}', // 填写退货表单接口
    applyPlatformIntervention: 'after_sales/apply_platform_join/{0}', // 用户申请平台介入
    luaApiGateway: 'express/express_cost/get_cost?cost_template_id={0}&province_id={1}&goods_item={2}&order_amount={3}&sku_id={4}&goods_id={5}&goods_weight={6}', // 獲取配送費
    getFreeWinnerList: 'free/activity/winner/list', // 获取免单名单列表
    getBlackList: 'user/is_ab?group_order_id={0}', // 判断当前用户是五类人
    getConfig: 'access/Configure/GetConfig', // 获取配置
    getConfigStartup: 'backend/conf/startup', // 获取灰度配置
    getConfigStartupWithKey: 'backend/conf/startup/key', // 根据key获取灰度配置
    getRecommendGoodsData: 'recommendation', // 获取推荐的商品
    getChargeHistory: 'virtual_goods/get_charge_history', // 获取话费充值电话记录
    getChargeRouter: 'virtual_goods/get_mobile_charge_router', // 获取话费充值推荐列表
    getNeighbourGroup: 'virtual_goods/get_neighbour_group', // 获取话费充值附近的拼单
    uploadTemplate: 'backend/template/upload', // 上传formId
    goodsNoticeCancel: 'backend/template/goods/notice/cancel', // 秒杀取消提醒接口

    // 从广告点击专题页请求的逻辑
    getAdSubject: 'api/flow/hobbiton/weixin/page?goods_id={0}',

    getCouponRecommendation: 'recommendation/coupon?offset={0}&count={1}&coupon_id={2}', // 优惠卷推荐商品

    indexQuickEntranceList: 'backend/subject_list', // 首页快速入口数据

    getTemplateRimendGoodsId: 'backend/template/find', // 获取需要模板提醒的商品id
    GetCostomImage: 'access/Image/GetCustomImage', // 获取拼单页面自定义分享图片
    chatOrders: 'orders/online_chat/all?page={0}&size={1}&mall_id={2}&offset={3}', // 获取聊天店铺订单
    chatOnlineOrders: 'orders/online_chat/{0}?mall_id={1}&page={2}&size={3}&offset={4}', // 获取聊天快捷入口对应操作的订单

    getGenTianTabData: 'api/gentian/{0}/resource_tabs?use_page=true', // 新的获取专题集的tab数据接口
    getGenTianGoodsData: 'api/gentian/{0}/resource_goods?tab_id={1}&page={2}&size={3}', // 新的获取专题集的tab数据接口

    promoTabInfo: 'api/carnival/sub_promotion_summary/{0}', // 获取双十一大促分会场父专题下子专题的信息
    promoVenueGoods: 'api/carnival/promotion_goods/{0}', // 获取双十一大促单个分会场的商品
    carnivalPromotion: 'api/carnival/special_promotion_list', // 大促特色会场
    mainCarnivalPromotion: 'api/carnival/main_promotion_list', // 大促主会场
    relayPromotion: 'api/carnival/relay_promotion_list', // 大促专题接力棒
    roewe: 'api/roewe/query', // 大促猜你喜欢
    tesla: 'api/tesla/query', // 推荐商品个性化
    carnivalImages: 'backend/carnival_images', // 大促banner图片
    getSpikeActivity: 'spike_activity?page={0}&size={1}', // 大促限时秒杀接口
    getPreheatGoods: 'carnival/get_preheat_goods', // 获取预热商品
    reservePreheatGoods: 'carnival/reserve_preheat_goods', // 预热商品设置提醒
    promotionUserInfo: 'backend/double11/userinfo', // 大促查看分享状态
    promotionShare: 'backend/double11/share', // 大促分享得券接口
    getIShoppingTabData: 'ishopping/tablist', // 新的爱逛街获取tab的api
    getIShoppingGoddsData: 'ishopping/goods?tab_id={0}&page={1}&size={2}', // 新的爱逛街获取商品的数据
    /* createEnvGroup: 'api/amazon/nile/group/create', //红包拼单建拼单
    getLatestEnvGroup: 'api/amazon/nile/group/get/current', //查最近开的红包拼单
    joinGroup: 'api/amazon/nile/group/join', //红包拼单拼单
    getGroupInfo: 'api/amazon/nile/group/get', //查询拼单信息*/
    getOMSConfig: 'backend/config/{0}', // 获取oms配置信息
    saveGroupInfo: 'backend/usergroup', // 保存团关系链
    queryOpenId: 'api/apollo/query_open_id', // 'access/Apiproxy/QueryOpenId',
    orderPayCheck: 'api/aristotle/pay_check', // 支付完成订单查询

    createEnvGroup: 'backend/amazon/nile/group/create', // 红包拼单建拼单
    getLatestEnvGroup: 'backend/amazon/nile/group/get/current/v2', // 查最近开的红包拼单
    joinGroup: 'backend/amazon/nile/group/join/v2', // 红包拼单
    getGroupInfo: 'backend/amazon/nile/group/get/v2', // 查询拼单信息
    getMallGroup: 'api/leibniz/mall/groups', // 大家都在拼
    checkMerchantCoupon: 'api/lisbon/query_usable_merchant_batches', // 查看店铺优惠券能否使用
    updateOrderAddress: 'api/vancouver/update_address', // 修改订单地址
    getGotCouponUsers: 'backend/amazon/nile/group/bubbles', // 拆红包，获取拆红包成功用户列表
    getCouponState: 'api/philo/red_dot', // 获取优惠券红点信息
    getFriendPayOrderInfo: 'order/friend_pay/query/{0}', // 获取好友代付订单详情
    hasOrders: 'api/flow/doom/ext/order/user/me', // 无实际订单新用户判断
    fetchUserInfo: 'user/profile/me', // 获取用户个人信息
    updateUserInfo: 'api/apollo/weapp/update/profile', // 更新服务器端用户信息
    encodeAlias: 'backend/conf/alias/format', // 五星好评参数编码
    decodeAlias: 'backend/conf/alias/parse', // 五星好评参数解码
    goodsDetailGenerateCard: 'access/Image/GetGoodsDetailImage', // 商详页分享卡片接口
    bargainDetailGenerateCard: 'backend/goods/bargain/share/friend',
    setDefaultAddress: 'api/apollo/address_default', // 设置默认收货地址
    modifyAddress: 'api/apollo/address_info', // 修改已有收货地址
    getLogisticeBanner: 'backend/conf/page', // 获取页面的OMS系统banner
    createEnvGroupNew: 'api/amazon/red/packet/group/create', // 红包拼单建拼单
    getCurrentEnvGroup: 'api/amazon/red/packet/group/get/current/v2', // 查最近开的红包拼单
    joinGroupNew: 'api/amazon/red/packet/group/join/v2', // 红包拼单拼单
    getGroupInfoNew: 'api/amazon/red/packet/group/get', // 查询拼单信息
    getOpenedFriendsList: 'api/amazon/red/packet/group/list', // 获取帮拆过红包的朋友列表(含当前红包及历史红包)
    // getDayRecommendShop: 'v2/subject/{0}/goods?page={1}&size={2}', //获取9块9特卖每日推荐商品
    getBigSaleInfo: 'backend/conf/event/2018_spring_festival', // 获取大促相关信息(主要包括banner图，浮窗图)
    getRandomLuckyUser: 'backend/goods/user/random/v2', // 获取一分抽奖页轮播展示用户晒单信息
    getLotteryComment: 'backend/goods/comments?page={0}&size={1}', // 获取抽奖晒单页的评论信息
    getRewardFromGoods: 'api/planck/playcard/v2/reward/get_reward_from_goods?reward_id={0}', // 商品详情页用户兑换奖励

    getOpenEnvelopeShareImg1: 'backend/amazon/nile/group/image/style1', // 获取拆红包2.0分享图片灰度1的图片
    getOpenEnvelopeShareImg2: 'backend/amazon/nile/group/image/style2', // 获取拆红包2.0分享图片灰度1的图片
    getSubscribeInfo: 'api/apollo/v3/user/is_subscribed', // 获取是否用户是否关注公众号信息
    // getUserOrderInfo: 'api/flow/doom/ext/order/user/me', //获取用户是否拥有订单
    activityAdGoods: 'api/tyrion/query?page={0}&size={1}&app_name={2}&list_id={3}', // 活动底部广告商品接口
    complaint_query: 'api/express/express/logistics_complaint/user/query', // 查询物流投诉
    createNewyearHeka: 'backend/card/add', // 创建新年贺卡
    queryNewyearHeka: 'backend/conf/card/info', // 查询新年贺卡
    queryMobile: 'api/apollo/query_open_mobile', // 查询用户的手机号
    queryMobileValue: 'backend/phone/assess', // 查询用户手机号价值
    queryMobileDetailInfo: 'backend/phone/find', // 查询用户手机号详细信息+好友价值
    checkSensitiveWord: 'backend/conf/sensitive', // 检查是否是敏感词
    idiomQueryGoods: 'api/tyrion/query', // 疯狂猜成语个性化广告商品
    getLandPageGoodsInfo: 'api/piece/members_goods', // 服务通知获取商品信息
    queryOrders: 'ordersv2/search?page={0}&size={1}&key_word={2}', // 搜索订单接口
    getFetchCoupon: 'api/daenerys/fetch_coupon', // 获取福利券信息
    getFetchCouponNew: 'api/jinbao/order/fetch_coupon', // 获取福利券信息新
    takeFetchCoupon: 'api/daenerys/take_coupon', // 领取福利券
    getGoodsInfo: 'api/targaryen/query_goods_detail', // 获取商品信息
    openEveGetCoupon: 'backend/amazon/nile/group/coupon/take', // 拆红包获取无门槛券
    getUserBonus: 'backend/v2/group_sign/v2/bonus', // 获取用户奖金信息接口
    getGroupActiveCount: 'backend/v2/group_sign/v4/banner/count', // 获取（伪）打卡人数
    getEnvelopAmount: 'backend/v2/group_sign/v2/money/receive', // 领取红包接口
    activeEnvelope: 'backend/v2/group_sign/v2/seat/unlock', // 激活红包位
    activeEnvelopeV4: 'backend/v2/group_sign/v4/group/active', // 激活红包位V4
    getEnvelopTypeList: 'backend/v2/group_sign/coupon/list/type', // 获取优惠券种类列表接口
    getEnvelopCouponList: 'backend/v2/group_sign/coupon/list/user', // 获取用户优惠券列表接口
    groupSignExchangeCoupon: 'backend/v2/group_sign/v2/money/coupon', // 奖金兑换优惠券接口
    sendCardMessage: 'api/rainbow/chat/send_card_message', // 申请补偿
    compensationGoods: 'api/fiora/compensation_goods', // 查询店铺的补差价商品
    checkPaidInMall: 'order/is_paid_in_mall', // 查询是否在店铺消费过
    littlePayDetail: '/api/asm/little_play_money/detail', // 查询小额打款详情
    wxForceUpdate: 'backend/conf/xcx/update', // 小程序版本强制更新
    getProvinceId: 'api/fiora/province', // 获取用户省份ID
    getGroupShareCodePic: 'backend/goods/comments/order/share/code', // 拼单页面分享三次生成分享二维码
    getGroupShareImg: 'backend/goods/comments/order/share/picture', // 拼单页面生成分享图片
    getGoodsShareImg: 'backend/goods/plain/share/picture', // 商详页面生成分享图片
    getGoodsShareImgv2: 'backend/goods/plain/share/pictureV2', // 商详分享二期
    getGoodsShareImgv3: 'backend/goods/plain/share/pictureV3', // 商详分享二期
    getGoodsPromotionTagShareImg: 'backend/goods/plain/promotion/card', // 大促商详分享卡片
    getTurinMall: 'api/turing/mall/query_recommend_goods', // 其他店铺相关商品

    redpackHelping: 'backend/v2/redpackHelping/get', // 获取、创建红包任务信息
    getRedpackHelping: 'backend/v2/redpackHelping/info/friend', // 获取好友红包任务信息
    getExtraRedPack: 'backend/v2/redpackHelping/extra', // 助力红包，获取额外红包
    redpackFriendHelp: 'backend/v2/redpackHelping/help', // 好友助力
    redpackBubbles: 'backend/v2/redpackHelping/bubbles', // 气泡
    redpackTake: 'backend/v2/redpackHelping/take', // 气泡
    getGroupSignInBuble: 'backend//v2/group_sign/v2/bubble/show', // 获取群打卡气泡信息接口
    getGroupSignInRecord: 'backend/v2/group_sign/v2/money/list', // 获取群打卡用户奖金明细接口
    deleteGroup: 'backend/v2/group_sign/v2/group/delete', // 群打卡删除过期群接口
    unlockEnvelop: 'backend/groupsign/v2/unlock', // 群打卡解锁红包位接口
    modifyGroupName: 'backend/v2/group_sign/v2/group_name/update', // 群打卡修改群名称接口
    getOrdersTrackStatus: 'api/express/track/status', // 批量查询订单最新物流状态
    remainDailyDuobaoCount: 'backend/treasure/remainder/count', // 剩余的夺宝次数
    goldenEggsActivityInfo: 'api/macchiato/activity_apply/last_time/remind/2', // 查询开拼单信息
    goldenEggsCouponRecordList: 'api/macchiato/coupon_record/list/2', // 查询近期发券信息
    goldenEggsJoin: 'api/macchiato/activity_operate/join', // 拼单
    goldenEggsCreate: 'api/macchiato/activity_apply/create', // 开拼单
    goldenEggsCouponList: 'api/macchiato/coupon_record/list/2', // 最近获得奖品用户，气泡
    goldenEggsSuperpositionCoupon: 'api/macchiato/user/superposition_coupon', // 剩余叠加券
    goldenEggsInfoById: 'api/macchiato/activity_operate/info/2', // 拼单信息
    goldenEggsAddChance: 'api/macchiato/user/add_chance', // 增加次数
    goldenEggsAddAddress: 'api/macchiato/user/set_address', // 提交收货地址
    getAbScene: 'api/flow/ab/scene', // 判断是否为1类人
    getAlexaGoods: 'api/alexa/v1/goods', // 个性化小单排
    getGroupMemberList: 'api/piece/group_avatars_map', // 根据订单id查询团成员信息
    cashRedpacketInfo: 'backend/v2/CashRedpacket/rp/info', // 获取红包信息
    cashRedpacketHelp: 'backend/v2/CashRedpacket/rp/help', // 帮开红包
    cashRedpacketBubbles: 'backend/v2/CashRedpacket/bubbles', // 获取气泡
    cashRedpacketTakeInfo: 'backend/v2/CashRedpacket/take/info', // 获取可提现金额
    cashRedpacketTake: 'backend/v2/CashRedpacket/take/dotake', // 提现
    cashRedpacketTakeV2: 'backend/v2/CashRedpacket/take/dotakev2', // 提现V2
    cashRedpacketHelpList: 'backend/v2/CashRedpacket/rp/helplist', // 获取帮开记录
    cashRedpacketTakeList: 'backend/v2/CashRedpacket/take/list', // 获取提现记录
    cashRedpacketSurpriseCheck: 'backend/v2/CashRedpacket/surprise/check', // 额外惊喜
    getNewuserZone: 'api/activity/spain/newuser/zone', // 钱包入口新人区
    cashRedpacketExtraCheck: 'backend/v2/CashRedpacket/extra/v5check', // 额外红包
    cashRedpacketCoupon: 'backend/v2/CashRedpacket/cp', // 优惠券
    cashRedpacketHelpSelf: 'backend/v2/CashRedpacket/rp/self', // 帮自己开红包
    cashRedpacketDoubelRedCheck: 'backend/v2/CashRedpacket/expandRp/query', // 查看膨胀红包任务
    cashRedpacketGiveUpDoubleRed: 'backend/v2/CashRedpacket/expandRp/giveup', // 放弃膨胀红包
    cashRedpacketMarkDoubleRedSuccess: 'backend/v2/CashRedpacket/expandRp/mark', // 标记点击完成膨胀红包任务
    mobileChargeCreateOrder: 'api/virginia/mobile_charge_create_order', // 用户话费充值接口
    flowChargeCreateOrder: 'api/virginia/data_flow_create_order', // 用户流量充值接口
    getSmallCoupon: 'backend/v2/wallet/small/coupon/query', // 查询钱包入口小额优惠券
    personalCheckHint: 'backend/v2/guide/user/collect/hint/check', // 检测是否需要引导用户接口
    personalShowCoupon: 'backend/v2/guide/user/collect/coupon/show', // 获取优惠券弹弹窗信息接口
    personalGetCoupon: 'backend/v2/guide/user/collect/coupon/grant', // 领取优惠券奖励接口
    personalGetFullback: 'api/zurich/fullback/query_show_fullback',
    getUin: 'api/apollo/get_uin', // 获取uin
    getOtherUserInfo: 'api/apollo/other_user', // 获取其他人信息
    getSamllCouponInfo: 'backend/v2/coupon/info', // 查询钱包入口小额优惠券核销状态
    setSmallCoupon: 'backend/v2/wallet/small/coupon/obtain', // 领取钱包入口小额优惠券
    myComments: 'api/engels/review/my', // 我的评论
    myCommentsWait: 'api/engels/review/my/unrated', // 待评论
    getAccessToken: 'api/galilei/refresh/token', // 置换token
    getGoodsDetailShareCard: 'backend/share/goods/detail/img/get', // 商详长按生成图片接口
    mineGetInfo: 'backend/v2/mine/get_info', // 多多金矿获取矿场信息
    mineGetFriendsList: 'backend/v2/mine/get_more_friends_info', // 多多金矿获取好友列表
    mineShowRealCarInfo: 'backend/v2/mine/get_car_info', // 展示真实订单数据
    mineGetGoodsList: 'backend/v2/mine/get_goods_list', // 多多金矿获取商品列表
    // mineInit: 'backend/v2/mine/init', //多多金矿初始化矿场
    mineInitV3: 'backend/v2/mine/v3/init',
    mineActive: 'backend/v2/mine/active', // 多多金矿激活矿场
    mineJoin: 'backend/v2/mine/join', // 多多金矿好友加入
    mineChangeGoods: 'backend/v2/mine/change_goods', // 多多金矿更换商品
    mineCollectCoin: 'backend/v2/mine/collect_coin', // 多多金矿收集收益
    mineActiveSelf: 'backend/v2/mine/share_to_start_mine',
    minePlaceOrder: 'backend/v2/mine/create_order',
    // minePlaceOrderV4: 'backend/v2/mine/create_order/unite', //4期下单改
    mineGetShareImg: 'backend/v2/mine/share/card',
    mineGetTaskList: 'backend/v2/mine/task_list',
    mineFinishTask: 'backend/v2/mine/task/finish_task',
    mineGetTaskReward: 'backend/v2/mine/task/gain_reward',
    mineGetColorfulEggs: 'backend/v2/mine/colorful_eggs',
    mineGoldenRainCoinsCheck: 'backend/v2/mine/check_rain_reward', // 领取金币雨奖励
    mineGetGoldenRainCoins: 'backend/v2/mine/golden_rain', // 领取金币雨奖励
    mineDirectSign: 'backend/v2/mine/direct_sign', // 广深用户直接签到
    mineQuerySmallCoupon: 'backend/v2/mine/query_small_coupon', // 小额券
    mineReceiveCoupon: 'backend/v2/mine/recieve_small_coupon',
    mineRedPointFromMine: 'backend/v2/mine/friend/pre',
    mineGetMineFriends: 'backend/v2/mine/friend/list', // 矿场好友列表
    mineGetFriendsMineInfo: 'backend/v2/mine/friends_mine_info', // 好友家的矿信息
    mineStealFriendsCoins: 'backend/v2/mine/steal_coins', // 好友加金币
    mineGetBuddyActivity: 'backend/v2/mine/mine_activities', // 矿好友链
    mineIfHavePrize: 'backend/v2/mine/have_prize', // 首页有奖提示
    mineResultShareCard: 'backend/v2/common_draw',
    mineGetInvitations: 'backend/v2/mine/invitations', // 邀请好友开新矿
    mineGetExtraCoupon: 'backend/v2/mine/extra-coupon', // 6期领取优惠券
    mineExtraOrderTask: 'backend/v2/mine/extra-order-task', // 6期浏览订单任务
    mineExtraOrderStatus: 'backend/v2/mine/extra-order-status', // 6期首页订单任务状态
    getCampaignPictureList: 'api/fiora/campaign_picture_list', // 分类页热区
    getLuckyInfo: 'api/activity/evenstar/lucky/info',
    getLuckyComments: 'api/activity/evenstar/group/comments/v2',
    groupSignInActiveGroupRedpacketOld: 'backend/groupsign/v2/active', // 激活群红包位，群打卡被封前旧接口
    groupSignInFightingMoney: 'backend/groupsign/v_temp/get_fighting_money', // 领取分享鼓励红包，群打卡新增接口
    friendSignHelpActivate: 'backend/v2/friend_sign/v2/help/activate', // 好友帮点激活接口,群打卡3期
    friendSignOpenFriendPacket: 'backend/v2/friend_sign/v2/open_friend_packet', // 开好友红包领奖金接口,群打卡3期
    friendSignFriendPacketList: 'backend/v2/friend_sign/v2/friend_packet/list', // 获取好友红包列表接口,群打卡3期
    friendSignFightingMoney: 'backend/v2/friend_sign/v2/get_fighting_money', // 领取鼓励红包接口,群打卡3期
    friendSignMoneyReceive: 'backend/v2/friend_sign/v2/money/receive', // 开群红包领取奖金接口（新版接入风控反扒）群打卡3期
    friendSignBonus: 'backend/v2/friend_sign/v2/bonus', // 获取用户奖励信息（集成新的帮点激活接口功能）
    friendSignMoneyReceiveV2: 'backend/v2/friend_sign/v2.1/money/receive', // 开群红包领取奖金接口（新版接入风控反扒）+ packId容错
    userGroup: 'backend/v2/user/group/get/v1', // 首页 1 类人
    getComposeProfile: 'compose/index/profile', // 用户信息接口合并
    getEncouragePacketInfo: 'backend/v2/friend_sign/v2/get_fighting_info', // 好友打卡，鼓励红包信息接口
    getMallFullack: 'api/zurich/fullback/query_today_mall_fullback', // 获取店铺满返
    queryUserPromotionBar: 'api/lisbon/query_user_promotion_bar', // 获取大牌券优惠券详情
    takeCouponFromPromotionBar: 'api/promotion/take_coupon_from_promotion_bar', // 领取大牌券
    getMallState: 'api/philo/v2/red_dot', // 获取店铺红点信息
    getSubjectGoods: 'api/activity/evenstar/goodslist?subject_id={0}&page={1}&size={2}&province_id={3}', // 专题 2742 新接口
    getBrandList: 'api/gentian/brand_list?resource_type={0}&brand_type={1}&page={2}&size={3}', // 品牌列表查询接口
    getExpediteDeliveryInfo: 'order/{0}/urge', // 点击催发货按钮之后，获取相应订单信息
    duoduoTripEntrancePkEntrance: 'backend/v2/travel/pk/index/v1', // 多多旅行PK首页
    duoduoTripEntrancePk: 'backend/v2/travel/pk/play/v1', // 多多旅行PK
    duoduoTripEntrancePkShare: 'backend/v2/travel/pk/share/v1', // 多多旅行PK分享领里程
    duoduoTripEntrance: 'backend/v2/travel/index/v3', // 多多旅行首页
    duoduoTripPostcardShare: 'backend/v2/travel/order/postcard/v1', // 多多旅行首页
    duoduoGetMiles: 'backend/v2/travel/index/obtain/v1', // 多多旅行领取里程
    duoduoGoForward: 'backend/v2/travel/mileage/cost/v3', // 多多旅行前进
    duoduoCreateOrder: 'backend/v2/travel/order/create/v1', // 多多旅行创建订单
    duoduoTripLottery: 'backend/v2/travel/stick/v2', // 多多旅行抽签接口
    duoduoTripSelectCity: 'backend/v2/travel/select/city/v2', // 多多旅行选择城市
    duoduoTripMsgList: 'backend/v2/travel/message/list/v1', // 多多旅行留言列表
    duoduoTripMsgAdd: 'backend/v2/travel/message/add/v1', // 多多旅行留言
    duoduoTripTaskList: 'backend/v2/travel/mileage/list/v1', // 多多旅行任务列表
    duoduoTripTaskPrize: 'backend/v2/travel/mileage/obtain/v1', // 多多旅行领取里程
    duoduoTripTaskShare: 'backend/v2/travel/share/obtain/v2', // 多多旅行分享里程任务
    duoduoTripTaskGoodsScan: 'backend/v2/travel/goods/scan/v1', // 多多旅行浏览商品，生成待领取里程
    duoduoTripSteal: 'backend/v2/travel/friend/mileage/steal/v2', // 多多旅行,偷取好友里程接口
    duoduoTripBubble: 'backend/v2/travel/bubble/v1', // 多多旅行,轮播气泡接口
    duoduoTripNewShareImage: 'backend/v2/travel/share/card', // 多多旅行,定制明信片分享卡片接口
    duoduoTripFriend: 'backend/v2/travel/friend/index/v2', // 多多旅行,好友家请求
    duoduoTripFriendList: 'backend/v2/travel/friend/list/v2', // 多多旅行,好友列表
    duoduoTripSocialExt: 'backend/v2/travel/friend/dynamic/v2', // 多多旅行,好友动态
    duoduoTripSkinList: 'backend/v2/travel/cartoon/list/v1', // 多多旅行皮肤列表
    duoduoTripSkinStatus: 'backend/v2/travel/cartoon/modify/v1', // 多多旅行改变形象状态接口
    duoduoTripDrawPostcard: 'backend/v2/travel/share/card_v2', // 多多旅行,绘制自定义明信片
    duoduoTripHelpIndex: 'backend/v2/travel/help/index/v1', // 多多旅行,好友助力首页接口
    duoduoTripHelp: 'backend/v2/travel/help/friend/help/v1', // 多多旅行,好友助力接口
    duoduoTripHelpTaskGet: 'backend/v2/travel/help/friend/obtain/v1', // 多多旅行,好友助力领取奖励接口

    getCategoryOpts: 'api/tyrion/opts', // 活动商品页tabs分类
    activityAdGoodsShoppingRewards: 'api/tyrion/query?page={0}&size={1}&app_name={2}&list_id={3}&opt_id={4}', // 活动广告商品接口
    getComposeIndexMain: 'compose/index/main', // 首页主接口接口合并
    getComposeIndexGoods: 'compose/index/goods', // 首页商品接口合并
    brandIndo: 'api/turing/mall/brand/info', // 品牌页信息
    getQQCoinChargeHistory: 'api/virginia/qq_coin/query/query_history_record_number', // 获取Q币充值记录
    clearQQCoinChargeHistory: 'api/virginia/qq_coin/edit/clear_history_charge_record', // 清除Q币充值记录
    getQQCoinChargeRouter: 'api/virginia/qq_coin/query/choose_qq_coin_goods_list_group_by_denomination', // 获取Q币充值推荐列表
    getQQNickName: 'api/virginia/qq_coin/query/qq_nick_name', // 获取QQ昵称
    createQQCoinOrder: 'api/virginia/qq_coin/edit/create_order', // 创建Q币充值订单
    getRelativeGoods: 'api/barrow/query?offset={0}&count={1}&goods_id={2}&app_name={3}', // 发现页商品列表请求
    getOriginGoodsInfo: 'api/fiora/goods/info?goods_id={0}', // 发现页顶部商品的信息
    getComposeIndexMultiMain: 'compose/index/multi/main', // 三个首页主接口合并
    getComposeIndexMultiGoods: 'compose/index/multi/goods', // 三个首页商品接口合并
    getComposeIndexCatalogGoods: 'compose/index/catalog', // 首页分类商品接口合并
    getVideoList: 'api/virginia/video_carrier_list', // 音乐视频运营商列表查询
    getVideoChargeRouter: 'api/virginia/video_face_value_list', // 音乐视频商品充值面额列表
    createVideoOrder: 'api/virginia/video/create_order', // 音乐视频商品充值接口
    getFriendSignInAllRedpacket: 'backend/v2/friend_sign/v5/all_red_packet', // 好友打卡5期，获取所有红包信息
    getFriendSignInOpenPacketInfo: 'backend/v2/friend_sign/v5/open_packet', // 好友打卡5期，爆破红包领取现金
    getFriendSignInCustomerService: 'backend/v2/friend_sign/v5/sign', // 好友打卡5期，客服签到接口
    getFriendSignInHelpActivate: 'backend/v2/friend_sign/v5/help/activate', // 好友打卡5期，好友帮点激活接口V5
    getFriendSignInSharePacket: 'backend/v2/friend_sign/v5/share_packet', // 好友打卡5期，分享红包接口
    getFriendSignInTaskList: 'backend/v2/friend_sign/v5/task_list', // 好友打卡5期，任务栏
    getGroupSignInRecordV5: 'backend/v2/friend_sign/v5/money/list', // 好友打卡5期，获取群打卡用户奖金明细接口
    getFriendSignInFriendList: 'backend/v2/friend_sign/v5/friend/list', // 好友打卡5期，获取好友列表
    getPhoneOperator: 'api/market/puck/phone/query', // 首页导流 app 电话运营商
    createDiversionOrder: 'api/market/puck/order/create', // 首页导流 app 创建订单
    getDiversionPopData: 'api/market/puck/applet/pop', // 首页导流 app 弹窗查询
    getPinCard: 'backend/v2/wallet/group/card/fetch', // 首页拼单卡弹窗
    getBargainTaskInfoV11: 'backend/v2/bargain/task/v11', // 砍价11期，获取任务列表信息
    getBargainBrowserGoods11: 'backend/v2/bargain/task/browser_goods/do_award/v11', // 砍价11期，生成浏览商品任务奖励(11期)
    getBargainTaskAward: 'backend/v2/bargain/task/get_award/v11' // 砍价11期，获取任务奖励(11期)
};

export default api;
