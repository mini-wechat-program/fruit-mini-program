/**
 * app相关配置
 * @Author: QingYou
 * @Date:   2017-03-19T14:5q7:35+08:00
 * @Filename: app_config.js
 * @Last modified by:   QingYou
 * @Last modified time: 2017-04-21
 */

const environment = 'yangkeduo';
// const environment = 'hutaojie';
const version = 'v2.5.9.1';
const salt = 'epcYXQ9JNx34C0hS3GYbR+tJquSSRiecmJDoZD8pwTQ=';
// pre
const isPreRelease = true;
// pre

const appConfig = {
    yangkeduo: {
        appId: 33,
        payAppId: 54,
        httpsLoggingURL: 'https://th.yangkeduo.com/t.gif',
        httpsLogRoutes: {
            chat_error: 'https://te.yangkeduo.com/e.gif', // 聊天的错误日志有独立的op=chat_error，但是还是走e，由服务端分发
            error: 'https://te.yangkeduo.com/e.gif',
            perf: 'https://tp.yangkeduo.com/p.gif',
            ad: 'https://th.yangkeduo.com/t.gif',
            real_error: 'https://tne.yangkeduo.com/tne.gif'
        },
        cmtURL: 'https://cmtw.yangkeduo.com/api/ajax',
        version: version,
        idHash: 'GY0RAjg4CQLGQosd',
        appName: 'yangkeduo',
        isPreRelease: isPreRelease,
        salt: salt,
        apiDomain:'https://api.pinduoduo.com/'
    },

    hutaojie: {
        appId: 1002,
        payAppId: 1003,
        httpsLoggingURL: 'https://th.yangkeduo.com/t.gif',
        cmtURL: 'https://cmtw.yangkeduo.com/api/ajax',
        httpsLogRoutes: {},
        version: version,
        idHash: '1bjd81bjsdkalsdnmau1', // openid的随机串
        appName: 'hutaojie',
        salt: salt,
        apiDomain:'https://apiv2.hutaojie.com/'
    }
};

module.exports = appConfig[environment];
