export default {
    isTest: window, // web模式启用配置的用户信息
    userInfo: {
        'EGRP': {
            'expTime': 1530015405735,
            'value': 3
        },
        'provinceId': {
            'expTime': 1530101205826,
            'value': 6
        },
        '0e4f9612e0fbe579': '2s3jvyq',
        'accessToken': 'IX2PFDT2PFSEMOYB5IHU63ONKTV2PY3RD7JPPF7LQMPL4OSPWYUQ1039281',
        'gzToken': '5333fe467167074d34085a772187ea2e',
        'createTime': 1530014806411,
        'nickName': '香蕉',
        'avatarUrl': 'https://xcxcdn.yangkeduo.com/cash_redpacket/wx.jpg',
        'gender': 1,
        'country': '中国',
        'province': '广东',
        'city': '广州',
        'testUid': '111111'
    },
    loginExtraInfo: {
        'useCache': false,
        'isSuccess': true,
        'loginType': 0,
        'isClickWxAuthBtn': false,
        'isClickWxDenyBtn': false,
        'isClickPddOKBtn': false,
        'isClickPddCancelBtn': false
    },
    logginURL: 'http://apiproxy.hutaojie.com/pointstorage/save'
};
