
/**
 * page相关的常量
 */

// 默认以key作为pageName
const PageInfo = {

    /**
     * 首页
     */
    index: {
        pv: {}
    },

    /**
     * 秒杀
     */
    spike: {
        pv: {},
        pageName: 'seckill',
        title: '限时秒杀'
    },

    /**
     * 普通专题
     */
    subject: {
        pv: {
            keys: ['subject_id']
        }
    },

    /**
     * [几乎没有量]免费试用
     */
    free_trial_page: {
        pv: {},
        pageName: 'free_try',
        title: '免费试用团'
    },

    /**
     * [几乎没有量]抽奖列表
     */
    lottery: {
        pv: {},
        title: '抽奖'
    },

    /**
     * 类目
     */
    catgoods: {
        pv: {
            keys: ['opt_id', 'opt_type']
        },
        pageName: 'opt'
    },

    /**
     * 海淘
     */
    haitao: {
        pv: {}
    },

    /**
     * 分类
     */
    classification: {
        pv: {},
        pageName: 'search',
        native: {
            android: {
                name: 'search',
                version: '3.0.0'
            },
            ios: {
                name: 'pdd_search',
                version: '3.0.0'
            }
        }
    },

    /**
     * 搜索结果
     */
    search_result: {
        pv: {
            keys: ['search_key']
        }
    },

    /**
     * 个人中心
     */
    personal: {
        pv: {}
    },

    /**
     * 个人主页
     */
    profile: {
        pv: {},
        pageName: 'friend_profile',
        requireLogin: true,
        title: '个人主页'
    },

    /**
     * 我的好友
     */
    my_friends: {
        pv: {},
        requireLogin: true,
        title: '我的好友'
    },

    /**
     * 好友申请列表
     */
    friends_requests: {
        pv: {},
        requireLogin: true,
        title: '好友申请',
        pageName: 'requesting_friends'
    },

    /**
     * 好友推荐列表
     */
    friends_recommends: {
        pv: {},
        requireLogin: true,
        title: '好友推荐',
        pageName: 'recommended_friends'
    },

    /**
     * 订单列表
     */
    orders: {
        pv: {
            keys: ['type']
        },
        pageName: 'my_order',
        requireLogin: true,
        title: '我的订单',
        native: {
            android: {
                name: 'pdd_orders',
                version: '2.6.0'
            },
            ios: {
                name: 'pdd_orders',
                version: '2.14.0'
            }
        }
    },

    /**
     * 拼单列表
     */
    groups: {
        pv: {
            keys: [{
                key: 'status',
                default: 3
            }]
        },
        pageName: 'my_group',
        requireLogin: true,
        title: '我的团'
    },

    /**
     * 我的抽奖
     */
    mylottery: {
        pv: {},
        pageName: 'my_lottery',
        requireLogin: true,
        title: '我的抽奖'
    },

    /**
     * 聊天列表
     */
    chat_list: {
        pv: {},
        requireLogin: true,
        title: '我的消息'
    },

    /**
     * 我的优惠券列表
     */
    coupons: {
        pv: {},
        pageName: 'my_coupons',
        requireLogin: true,
        title: '我的优惠券'
    },

    /**
     * 退换货列表
     */
    complaint_list: {
        pv: {},
        pageName: 'complaint',
        requireLogin: true
    },

    /**
     * 订单详情
     */
    order: {
        pv: {
            keys: ['order_sn']
        },
        pageName: 'order_detail',
        requireLogin: true
    },

    /**
     * 拼单详情
     */
    group: {
        pv: {
            indiv: false,
            keys: ['group_order_id']
        },
        pageName: 'group_detail',
        requireLogin: true,
        tkShareClick: true
    },

    /**
     * 商品详情
     */
    goods: {
        pv: {
            keys: ['goods_id']
        },
        pageName: 'goods_detail',
        tkShareClick: true,
        native: {
            android: {
                name: 'pdd_goods_detail',
                version: '3.13.0'
            },
            ios: {
                name: 'pdd_goods_detail',
                version: '3.15.0'
            }
        }
    },

    /**
     * 下单页
     */
    order_checkout: {
        pv: {
            keys: [
                'goods_id',
                'sku_id',
                'group_id',
                {
                    key: 'goods_number',
                    default: 1
                }
            ]
        },
        requireLogin: true
    },

    /**
     * 店铺页
     */
    mall_page: {
        pv: {
            keys: ['mall_id']
        },
        pageName: 'mall',
        native: {
            android: {
                name: 'pdd_mall',
                version: '2.1.0'
            },
            ios: {
                name: 'pdd_mall',
                version: '1.3.0'
            }
        }
    },

    /**
     * 商家证照展示页
     */
    mall_certificates: {
        pv: {
            keys: ['mall_id']
        },
        pageName: 'mall_certificates',
        requireLogin: true,
        title: '经营证照'
    },

    /**
     * 拼单免商品列表
     */
    tzfree_list: {
        pv: {},
        pageName: 'free_group_list'
    },

    /**
     * 过期优惠券
     */
    expiring_coupons: {
        pv: {
            keys: ['expire_batch_ids']
        },
        pageName: 'expired_coupon',
        requireLogin: true
    },

    /**
     * 向指定用户推送代金券
     */
    coupon_push_someusers: {
        requireLogin: true
    },

    /**
     * 每周推文优惠券
     */
    coupon_event_v2: {
        pv: {},
        pageName: 'red_packet',
        requireLogin: true
    },

    /**
     * 聊天
     */
    chat_detail: {
        pv: {
            keys: ['mall_id']
        },
        pageName: 'talk',
        requireLogin: true
    },

    /**
     * 好友聊天
     */
    chat_detail_friends: {
        pv: {
            keys: ['other_uid']
        },
        pageName: 'chat_detail_friends',
        requireLogin: true
    },

    /**
     * 追加评价
     */
    additional_comments: {
        pv: {},
        requireLogin: true,
        native: {
            android: {
                name: 'pdd_additional_comment',
                version: '3.20.0'
            },
            ios: {
                name: 'pdd_additional_comment',
                version: '3.20.0'
            }
        }
    },

    /**
     * 地址列表
     */
    addresses: {
        pv: {},
        requireLogin: true,
        title: '收货地址'
    },

    /**
     * 支付宝支付回调
     */
    alipay_callback: {
        pv: {}
    },

    /**
     * 微信h5支付回调
     */
    wechat_h5_pay_callback: {
        pv: {},
        requireLogin: true
    },

    /**
     * [结束]周年庆
     */
    anniversary: {},

    /**
     * 关于我们
     */
    app_about: {
        pv: {}
    },

    /**
     * [没有JS文件]APP唤起
     */
    app: {},

    /**
     * 第三方认证
     */
    authorize: {
        pv: {},
        requireLogin: true
    },

    /**
     * [结束]黑五
     */
    black_friday: {},

    /**
     * 评价
     */
    comments: {
        pv: {},
        requireLogin: true,
        native: {
            android: {
                name: 'pdd_comment',
                version: '3.20.0'
            },
            ios: {
                name: 'pdd_comment',
                version: '3.20.0'
            }
        }
    },

    /**
     * 评价引导
     */
    complaint_guide: {
        pv: {}
    },

    /**
     * 旧的退换货
     */
    complaint_old: {
        pv: {},
        requireLogin: true
    },

    /**
     * 免费试用优惠券推荐
     */
    coupon_recommend: {
        pv: {},
        requireLogin: true
    },

    /**
     * 确认收货领红包
     */
    coupon_share: {
        pv: {
            keys: ['share_code', 'ownerID']
        },
        pageName: 'coupon',
        requireLogin: true
    },

    /**
     * 交易完成
     */
    deal_made: {
        pv: {},
        requireLogin: true
    },

    /**
     * [结束]双11主会场
     */
    double11: {},

    /**
     * [没有JS文件]下载页面
     */
    download: {},

    /**
     * 常见问题
     */
    faq: {
        pv: {}
    },

    /**
     * 评价列表
     */
    goods_comments: {
        pv: {
            keys: ['goods_id']
        }
    },

    /**
     * 物流
     */
    goods_express: {
        pv: {
            keys: ['order_sn', 'goods_id', 'tracking_number', 'shipping_id']
        },
        requireLogin: true
    },

    /**
     * 商品跳转
     */
    goods_skip: {
        pv: {
            keys: ['goods_id']
        }
    },

    /**
     * 登录
     */
    login: {
        pv: {}
    },

    /**
     * 中奖详情
     */
    lottery_list: {
        pv: {
            keys: ['lucky_id']
        }
    },

    /**
     * 设置
     */
    setting: {
        pv: {}
    },

    /**
     * 中转
     */
    skip: {
        pv: {}
    },

    /**
     * 常见问题
     */
    suggestion: {
        pv: {},
        title: '常见问题'
    },

    /**
     * 服务协议
     */
    terms: {
        pv: {}
    },

    /**
     * 个人中心 意见反馈
     */
    personal_feedback: {
        pv: {},
        title: '意见反馈'
    },

    /**
     * 意见反馈提交
     */
    feedback_commit: {
        pv: {
            keys: [{
                key: 'type',
                default: 1
            }]
        },
        title: '意见反馈',
        requireLogin: true
    },

    /**
     * [没有JS文件]QQ登录回调页面
     */
    qqoauth_callback: {},

    /**
     * [没有JS文件]微博登录回调页面
     */
    wboauth_callback: {},

    /**
     * 发起(修改)售后
     */
    complaint: {
        pv: {
            keys: ['order_sn']
        },
        pageName: 'complaint_make',
        requireLogin: true
    },

    /**
     * 售后详情
     */
    complaint_detail: {
        pv: {
            keys: ['after_sales_id', 'order_sn']
        },
        requireLogin: true
    },

    /**
     * 海淘秒杀
     */
    haitao_spike: {
        pv: {},
        pageName: 'haitao_seckill'
    },

    /**
     * 首页弹窗
     */
    app_coupon_popup: {
    },

    /**
     * 专题集
     */
    subjects: {
        pv: {
            keys: ['subjects_id']
        }
    },

    /**
     * 专题集
     */
    fruit: {
        pv: {},
        title: '拼好货'
    },

    /**
     * 极速拼单
     */
    flash_groups: {
    },

    /**
     * [结束]年货节优惠券广场
     */
    new_year_coupon_square: {
        title: '年货节领券专区'
    },

    /**
     * [结束]年货节
     */
    new_year: {},

    /**
     * 物流投诉
     */
    express_complaint: {
        pv: {},
        title: '物流投诉',
        requireLogin: true
    },

    one_yuan_purchase: {
        pv: {},
        title: '一元团'
    },

    /**
     * 女神节主会场
     */
    womens_day: {
        pv: {},
        title: '拼多多女神节'
    },

    /**
     * 换季主会场
     */
    spring_summer: {
        pv: {},
        title: '拼多多换季清仓'
    },

    /**
     * 换季上新主会场
     */
    april_promo: {
        pv: {},
        title: '拼多多换季上新'
    },

    /**
     * 焕新装主会场
     */
    april_new_home: {
        pv: {},
        title: '拼多多焕新家'
    },

    /**
     * 拼单成功推送个性化推荐
     */
    tuan_success_recommend: {
        pv: {
             keys: ['goods_id']
        },
        title: '猜你喜欢'
    },

    /**
     * 优惠券适用商品
     */
    coupon_newbee: {
        pv: {
            keys: ['coupon_id']
        },
        title: '优惠券适用商品'
    },

    /**
     * App下载引导页
     */
    coupon_download: {
        pv: {}
    },

    detail: {
        pv: {},
        title: '商品详情'
    }
};

export {
    PageInfo
};

