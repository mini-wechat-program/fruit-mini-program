/**
 * @file constants/share/index.js 分享相关常量
 * @author aotuman
 */

const ShareChannel = {
    Unknown: 'unknown',
    AppMessage: 'message',
    Timeline: 'timeline',
    QQ: 'qq',
    QQZone: 'qzone',
    QQWeibo: 'qq_weibo',
    SinaWeibo: 'weibo'
};

const ShareResult = {
    Success: 'success',
    Fail: 'fail',
    Cancel: 'cancel',
    Complete: 'complete'
};

const ShareFakeUrl = {
    domain: 'http://hz.pin18pin.com/',
    start: 'https://open.weixin.qq.com/connect/oauth2/authorize?response_type=code&scope=snsapi_base&appid={0}&redirect_uri={1}'
};

export default {
    ShareChannel: ShareChannel,
    ShareResult: ShareResult,
    ShareFakeUrl: ShareFakeUrl
};
