/**
 * @Author: QingYou
 * @Filename: storage_keys.js
 * @Last modified by:   QingYou
 * @Last modified time: 2017-04-16T14:24:17+08:00
 */

import keyMirror from '../libs/key_mirror';

const StorageKeys = keyMirror({
    /**
   * user相关的Storage key
   */
    USER_INFO: null,

    // 搜索记录
    SEARCH_HISTORY: null,

    // 拼单玩法提示
    GROUP_PLAY_NOTICE: null,

    // 是否可以使用webp压缩图片
    WEBP_ENABLE: null,

    // 分类信息
    CLASSIFACATION_INFO: null,

    // 分类信息缓存键（for redux）
    CLASSIFACATION_INFO_v2: null,

    /**
    * UID存储key
    * key: md5(UIDStorage). value: parseInt(userId).toString(36)
    * @type {String}
    */
    UID: '0e4f9612e0fbe579',

    // 行政区数据
    REGIONS: null,

    // 收藏商品ID
    LIKE_GOODS_IDS: null,

    // 收藏更新时间
    FAVORITE_UPDATE_TIME: null,

    // 收藏的店铺ID
    LIKE_MALL_IDS: null,

    // 店铺收藏的更新时间
    FAVORITE_MALL_UPDATE_TIME: null,

    // 获取游客的UV
    VISITOR_INFO: null,

    // 用户浏览页面时间
    USER_OPEN_PAGE_TIME: null,

    // 首页顶栏
    HOME_OPERATIONS: null,

    // 团页推荐顶栏
    GROUP_HOME_OPERATIONS: null,

    // 首页banner
    TOP_BANNER: null,

    // 商品详情，领取优惠券失败
    GOODS_MALL_COUPON_GOT_ALREADY: null,

    // 专题集tab 11
    SUBJECTS_TAB_DETAIL_11: null,

    // 专题集tab 12
    SUBJECTS_TAB_DETAIL_12: null,

    // 专题集tab 11
    SUBJECTS_TAB_DETAIL_14: null,

    // 专题集tab 15
    SUBJECTS_TAB_DETAIL_15: null,

    // 专题集tab 16
    SUBJECTS_TAB_DETAIL_16: null,

    // 专题集tab 17
    SUBJECTS_TAB_DETAIL_17: null,

    // 专题集tab 18
    SUBJECTS_TAB_DETAIL_18: null,

    // 专题集tab 20
    SUBJECTS_TAB_DETAIL_20: null,

    // 专题集tab 21
    SUBJECTS_TAB_DETAIL_21: null,

    // 专题集tab 22
    SUBJECTS_TAB_DETAIL_22: null,

    // 专题集tab 23
    SUBJECTS_TAB_DETAIL_23: null,

    // 专题集tab 125
    SUBJECTS_TAB_DETAIL_125: null,

    // 专题集tab 11
    SUBJECTS_TAB_NEW_DETAIL_11: null,

    // 专题集tab 12
    SUBJECTS_TAB_NEW_DETAIL_12: null,

    // 专题集tab 11
    SUBJECTS_TAB_NEW_DETAIL_14: null,

    // 专题集tab 15
    SUBJECTS_TAB_NEW_DETAIL_15: null,

    // 专题集tab 16
    SUBJECTS_TAB_NEW_DETAIL_16: null,

    // 专题集tab 17
    SUBJECTS_TAB_NEW_DETAIL_17: null,

    // 专题集tab 18
    SUBJECTS_TAB_NEW_DETAIL_18: null,

    // 专题集tab 20
    SUBJECTS_TAB_NEW_DETAIL_20: null,

    // 专题集tab 21
    SUBJECTS_TAB_NEW_DETAIL_21: null,

    // 专题集tab 22
    SUBJECTS_TAB_NEW_DETAIL_22: null,

    // 专题集tab 23
    SUBJECTS_TAB_NEW_DETAIL_23: null,

    // 专题集tab 125
    SUBJECTS_TAB_NEW_DETAIL_125: null,

    // 三天内首次收藏的时间
    GOODS_LIKE_DATE: null,

    // 三天内首次从收藏进商详的时间
    GOODS_FROM_LIKE_DATE: null,

    // 用户首次访问个人中心，出现tips在个人中心
    HAS_SHOW_ADD_MINIAPP_GUIDE: null,

    // 个人中心下拉小程序优惠券
    HAS_SHOW_ADD_MINIAPP_COUPON: null,

    // 请求socket连接失败的时间
    REQUEST_SOCKET_FAIL_DATE: null,

    // 是否显示新用户引导
    IS_SHOWED_NEWER_GUIDE: null,

    // 群签到活动判断用户是否弹过红包弹窗
    HAS_POPUP_RED_ENVELOP: null,

    // 滑动点击判断
    SYSTEM_PLATFORM_FOR_SCROLL: null,

    // 订单是否曾经催发货的标记
    EXPEDITED_ORDERS: null,

    // IOS_SYSTEM_FOR_SCROLL: null,

    // SYSTEM_FOR_SCROLL: null,

    // AND_SYSTEM_FOR_SCROLL: null

    // 置换token
    REFRESH_TOKEN: null,
    // 抢明星红包，发红包明星信息
    SEND_REDPACKET_STAR_INFO: null,
    // 店铺收藏点击日期
    MALL_CLICK_TIME: null,
    // 下单页 上次支付 app_id
    LAST_PAY_APP_ID: null,
    COUPON_CENTER_TABS_LIST: null
});

export default StorageKeys;
