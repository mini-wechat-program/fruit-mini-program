/*
 * @Description: wx常量
 * @Author: luke
 * @Date: 2018-12-12 22:11:12
 */

export const prefixPath = '/pages/garden/garden?src=';
export const domain = 'https://mobile.yangkeduo.com';
export const webUrl = '/pages/web/web';
export const fruitMiniPath = '/package_activity/garden/garden/pages/index/index';

export const urlList = [
    'cartoon_fruiter_team',
    'cartoon_fruit_lottery',
    'cartoon_fruit_lucky_water_goods',
    'cartoon_fruit_goods',
    'cartoon_fruit_strategy',
    'cartoon_fruit_gain_record',
    'cartoon_fruit_lucky_water', 
    'cartoon_fruit_draw_lots',
    'cartoon_fruit_sales_volume_bet',
];
