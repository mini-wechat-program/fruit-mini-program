/**
 * Created by jiangliuer on 2018/12/13
 */
import AppConfig from '@wx_common/configs/app_config';
import dataUtil from '@wx_common/util/data_util';
import urlUtil from '@wx_common/commonUrl';
import userStorage from '@wx_common/storage/user_storage';
import SystemInfo from '@wx_common/systemInfo/system_info';
import util from '@wx_common/util/index'
import Taro from '@tarojs/taro';
// 存储发送队列
const queue = [];
// 存储中间件
const middlewareArr = [];
// 系统信息
const systemInfo = SystemInfo.getSystemInfoSync();
const defaultOpts = {
    // 屏幕的宽度
    screen_width: systemInfo.screenWidth,
    // 屏幕的高度
    screen_height: systemInfo.screenHeight,
    // 屏幕的device pixel ratio
    dpr: systemInfo.pixelRatio,
    // 应用的版本
    app_version: AppConfig.version,
    // 用户平台:
    platform: 'wxapp'
};
const logger = {
    trackingRecord(params, callback) {
        if (AppConfig.httpsLoggingURL == null || AppConfig.httpsLoggingURL.length <= 0) {
            return;
        }
        this.send(params, callback);
    },
    getLogID(){
        const logId = [
            Date.now(),
            dataUtil.getRandomString(16)
        ].join('');
        return logId;
    },
    buildFinalPostData(params){
        params = params || {};
        return {
            q: urlUtil.buildQuery(params)
        };
    },
    send(opts, callback){
        // 自动补全页面名称
        opts.log_id = opts.log_id || this.getLogID();
        opts.user_id = opts.user_id || userStorage.getUserId();
        opts.app_id = opts.app_id || AppConfig.appId || '';
        opts.time = opts.time || opts.log_id.substring(0, 13);
        opts.page_name = "xcx_cartoon_fruiter";
        //TODO work with pageManager
        opts.page_sn = '10269';
        //opts = util.extend(PageManager.getKeyParams(), opts);
        if (opts.op === 'pv') {
            // 强制把页面pv的event改成page_show, 弹窗的pv需要吧op都改成event
            opts.event = 'page_show';
        }
        // add page url
        opts.page_url = getCurrentPages().pop().route;
        if (middlewareArr && middlewareArr.length > 0) {
            opts = middlewareArr.reduce((preOpts, currentMiddleware, index, arr) => {
                return currentMiddleware(preOpts, index, arr);
            }, opts);
        }

        // 添加到队列
        queue.push(opts);
        // 开始消费
        this.consume(callback);
    },
    consume(callback) {
        if (queue.length === 0) {
            if (callback) {
                callback();
            }
            return;
        }
        while (queue.length > 0) {
            const params = queue.pop();
            this.exec(params);
        }

        if (callback) {
            callback();
        }
    },
    exec(params) {
        const LOG_ROUTES = AppConfig.httpsLogRoutes;
        const LOG_URL = AppConfig.httpsLoggingURL;
        params = util.extend(defaultOpts, params || {});
        let logRouteKey = params.op;
        const postData = this.buildFinalPostData(params);
        let {q} = postData;
        const url = LOG_ROUTES[logRouteKey] || LOG_URL;
        // 目前的文档类型
        const content_type = 'text/plain;charset=UTF-8';
        /* 针对op=real_error做特殊处理 测试新的接口及参数标准*/
        if (params.op == 'real_error') {
            // content_type="application/json;charset=UTF-8";
            // 针对参数做一些处理主要是发送值q的处理
            if (params.status_code) {
                params.payload ? params.payload.status_code = params.status_code : params.payload = {status_code: params.status_code};
                delete params.status_code;
            }
            if (params.error_message) {
                params.error_msg = params.error_message;
                delete params.error_message;
            }
            if (params.params) {
                params.payload ? params.payload.params = params.params : params.payload = {params: params.params};
                delete params.params;
            }
            if (params.sub_op) {
                params.payload ? params.payload.sub_op = params.sub_op : params.payload = {sub_op: params.sub_op};
                delete params.sub_op;
            }
            if (params.debug_url) {
                params.payload ? params.payload.debug_url = params.debug_url : params.payload = {debug_url: params.debug_url};
                delete params.debug_url;
            }
            params.log_version = '1.0.0';
            q = JSON.stringify(params);
        }
        try {
           //发送
            Taro.request({
                url:url,
                method:'POST',
                data:q,
                header:{
                    'Content-Type':content_type
                }
            })
        } catch (e) {
            // alert('xmlhttp error!');
        }
    }
}
wx.onError((message,stack)=>{
    logger.send({
        'page': message + JSON.stringify([stack]),
        'op': 'real_error',
        'page_url': getCurrentPages().pop().route
    })
});
export default logger;
