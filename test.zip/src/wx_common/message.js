//@flow
/**
 * @Author: QingYou
 * @Date:   2017-05-16
 * @Filename: message.js
 * @Last modified by:   QingYou
 * @Last modified time: 2017-05-16
 */
import Pubsub from './pubsub';

let Message = new Pubsub();

let KEYS = {
    //请求的token失效
    REQUEST_TOKEN_INVALID: 'REQUEST_TOKEN_INVALID'
};

export {
    Message,
    KEYS
};