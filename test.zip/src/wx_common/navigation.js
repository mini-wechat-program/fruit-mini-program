/*
 * @Description: navigation
 * @Author: luke
 * @Date: 2018-12-12 21:44:50
 */
import Taro, { Component } from '@tarojs/taro';
import { prefixPath, urlList, domain, webUrl } from './constants/urls';
import commonUrl from './commonUrl/index';

const navigation = {

    getRoute(url) {
        if (url.indexOf('http') < 0) {
            url = domain + '/' + url;
        }
        return prefixPath + encodeURIComponent(url);
    },

    toWeb(url) {
        if (!url) {
            return;
        }
        if (url.indexOf('http') < 0) {
            url = domain + '/' + url;
        }
        const queries = commonUrl.buildQuery({
            specialUrl: true, // 免登录带这个参数
            src: url || ''
        });
        url = webUrl + '?' + queries;
        this.navigateTo(url);
    },

    forward(url) {
        if (!url) {
            return;
        }

        url = url.trim();
        const originUrl = url.split('?')[0];
        const path = urlList.find(item => {
            return originUrl.indexOf(item) >= 0;
        });

        if (path) {
            this.navigateTo(this.getRoute(url));
        } else {
            this.toWeb(url);
        }
    },

    navigateTo(url) {
        Taro.navigateTo({
            url: url
        });
    },

    home() {
        this.navigateTo('/pages/index/index');
    },

    reload() {

    }
};

export default navigation;
