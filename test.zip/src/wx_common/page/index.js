import user from "@wx_common/user/index";

const noop = function() {};

const pageResult = {
  prepare() {
    return user.ensureLogin();
  }
};

export default pageResult;
