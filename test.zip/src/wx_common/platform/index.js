
function returnFalse() {
    return false;
}

const falseFn = ['getAppVersion', 'getDDJBVersion', 'isAliPayAvailable', 'isAndroidMaskSpinnerVersion',
    'isAndroidSupportWeChatSessionImage', 'isAndroidWeChatPlatform', 'isCallNativeNotification', 'isComponentPackageEnv',
    'isEmbeddedBrowser', 'isIOSWeChatPlatform', 'isIOSWeChatUIWebView', 'isMinVersionSatisfied', 'isMobileBrowser',
    'isNativePlatform', 'isPureWeChatPlatform', 'isQQPayAvailable', 'isQQPlatform', 'isShowSMAlertPlatform',
    'isSupportWechatFloatingWindow', 'isWeChatMiniProgram', 'isWeChatPayAvailable', 'isWeChatPlatform', 'isWeiboPlatform'];

// const falseValue = ['AndroidSystemVersion', 'IOSSystemVersion', 'WeChatAndroid', 'WeChatCurrent', 'WeChatIOS',
//     'WeChatUnknown', 'isAliPayDirectDebitVersion', 'isCouponGroupShare', 'isEletricShowNativeTab', 'isGroupAudioRecordVersion',
//     'isGroupFastBackVersion', 'isGroupShareImageVersion', 'isHBInstallmentPayVersion', 'isHorizontalScrollVersion',
//     'isIOSCompressShareImage', 'isIOSShareUninstallNotifition', 'isMobile', 'isModuleVersion', 'isNativeChatVersion',
//     'isNativeContactVersion', 'isNativeFriendsVersion', 'isNativeImageViewerVersion', 'isNativeIndexVersion', 'isNativeLogVersion',
//     'isNativeLoginVersion', 'isNativeMallPageVersion', 'isNativeOrdersPageVersion', 'isNativeQQPayVersion',
//     'isNativeSpikeCalendardVersion', 'isNativeSpikeRemindVersion', 'isNativeSubjectsPageVersion', 'isNativeTabBarVersion',
//     'isNativeUpdateVersion', 'isNewGroupFastBackVersion', 'isNewOrderStatusVersion', 'isNoHaitaoVersion',
//     'isPDDTimelineFeedDeleteNotification', 'isPddPushSocketVersion', 'isPhotoDisabledVersion', 'isPlayAudioWithSettleVol',
//     'isPlayAudioWithSystemVol', 'isShowAddressCantReceiveVersion', 'isShowHUDVersion', 'isSpikeNoticeUnionVersion',
//     'isSupportAudioMsgVersion', 'isSupportCheckNotify', 'isSupportCheckWebviewInScreen', 'isSupportCheckWebviewInTab',
//     'isSupportNativeLog', 'isSupportSetTitleAnimation', 'isTakeCouponAfterCommentVersion', 'isTakeCouponInCommentPage',
//     'isUpdateTimelineOrderStatusNotification', 'isUrgeShipmentVersion', 'launchAppVersion'];

const Enums = {
    Unknown: 'unknown',
    IOS: 'ios',
    Android: 'android',
    WeChat: 'wechat',
    Weibo: 'weibo',
    QQ: 'qq',
    WxApp: 'wxapp',
    WxaNative: 'wxa',
}

const platform = {};

platform.compareVersion = function (v1, v2) {
    const toIntArray = function(version) {
        const ret = [];
        if (!version || version.length <= 0) {
            return ret;
        }
        version.split('.').forEach(function(token) {
            ret.push(parseInt(token, 10) || 0);
        });
        return ret;
    };
    const parts1 = toIntArray(v1);
    const parts2 = toIntArray(v2);
    const length = Math.max(parts1.length, parts2.length);
    for (let i = 0; i < length; ++i) {
        const part1 = parts1[i] || 0;
        const part2 = parts2[i] || 0;
        if (part1 !== part2) {
            return part1 - part2;
        }
    }
    return 0;
}

falseFn.forEach(name => {
   platform[name] = returnFalse;
});

Object.assign(platform, Enums);
platform.Current = Enums.WxaNative;

export default platform;
