/*
 * @Description: 
 * @Author: luke
 * @Date: 2018-12-14 17:54:45
 */
import Taro from '@tarojs/taro';
import { missionList, defaultShareInfo } from '@wx_common/share/shareInfo';

//share的用法
// <Button openType="share" id={123} >wwww</Button>

function genShareInfo(mission) {
    const path = getSharePath();
    return {
        title: mission.title,
        imageUrl: mission.imageUrl,
        path: path + '?' + mission.shareUrl,
        callback: mission.callback || '',
    };
}

export const getSharePath = function () {
    const pages = Taro.getCurrentPages()    //获取加载的页面
    const currentPage = pages[pages.length-1]    //获取当前页面的对象
    const path = currentPage.route;
    return path;
}

export const getShareInfo = function (missionType) {
    const info = missionList[missionType];
    if (!info) {
        return genShareInfo(defaultShareInfo);
    }
    return genShareInfo(info);

}