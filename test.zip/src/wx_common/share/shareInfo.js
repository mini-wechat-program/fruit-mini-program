/*
 * @Description: 
 * @Author: luke
 * @Date: 2018-12-14 18:56:03
 */

export const shareInfo = {

};

export const shareStatus = {
    isFromShare: false,
};

export const missionList = {
    '1': {
        title: '多多果园，种树得水果，包邮送到家~',
        imageUrl: 'https://pinduoduoimg.yangkeduo.com/cartoon_activity/fruiter/wx_share_gain_water.jpg',
        shareUrl: '',
        callback: function () {
            console.log('succ');
        }
    },
    '2': {
        title: '多多果园送福袋，种树得水果，包邮送到家~',
        imageUrl: 'https://pinduoduoimg.yangkeduo.com/cartoon_activity/fruiter/wx_share_gain_water.jpg',
        shareUrl: '',
        callback: function () { }
    },
    '5': {
        title: '多多果园，种树得水果，包邮送到家~',
        imageUrl: 'https://pinduoduoimg.yangkeduo.com/cartoon_activity/fruiter/wx_share_gain_water.jpg',
        shareUrl: '',
        callback: function () { }
    }
};

export const defaultShareInfo = {
    title: '多多果园，种树得水果，包邮送到家~',
    imageUrl: 'https://pinduoduoimg.yangkeduo.com/cartoon_activity/fruiter/wx_share_gain_water.jpg',
    shareUrl: '',
}

export const addShareCallback = (type, fun) => {
    missionList[type].callback = fun;
}