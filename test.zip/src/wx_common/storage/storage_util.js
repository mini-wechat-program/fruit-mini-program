import Promise from '../libs/es6-promise.min';
// 异步请求依赖
// import co from '../libs/co/we-index';
// import '@tarojs/async-await';

const StorageUtil = {
    /**
     * getStorage promise化
     */
    getStorage(key) {
        return new Promise((resolve) => {
            wx.getStorage({
                key: key,
                success: function (res) {
                    resolve(res.data);
                },
                fail: function() {
                    resolve(false);
                }
            });
        });
    },

    /**
     * setStorage promise化
     */
    setStorage(key, data) {
        return new Promise((resolve) => {
            wx.setStorage({
                key: key,
                data: data,
                success: resolve,
                fail: resolve
            });
        });
    },

    /**
     * removeStorage promise化
     */
    removeStorage(key) {
        return new Promise((resolve) => {
            wx.removeStorage({
                key: key,
                success: resolve,
                fail: resolve
            });
        });
    },

    /**
     * getStorage 同步函数
     */
    getStorageSync(key) {
        try {
            return wx.getStorageSync(key);
        } catch (e) {
            console.error(e);
        }
    },

    setStorageSync(key, data) {
        try {
            wx.setStorageSync(key, data);
        } catch (e) {
            console.error(e);
        }
    },

    /**
     * removeStorageSync 同步
     */
    removeStorageSync(key) {
        try {
            wx.removeStorageSync(key);
        } catch (e) {
            console.error(e);
        }
    },

    /**
     * 根据 storageName 查询今天内 storageName 对应的状态
     */
    // checkStorage: co.wrap(function * (storageName) {
    //     try {
    //         let flag = false;
    //
    //         const value = yield StorageUtil.getStorage(storageName);
    //         if (value) {
    //             const today = new Date().setHours(0, 0, 0, 0);
    //
    //             const timeStamp = new Date(today).getTime();
    //             if (value <= timeStamp) {
    //                 flag = true;
    //             }
    //         } else {
    //             flag = true;
    //         }
    //         return flag;
    //     } catch (e) {
    //         console.error(e);
    //     }
    // })
};

export default StorageUtil;
