// @flow
/**
 * 用户相关信息
 * @Author: QingYou
 * @Filename: user_storage.js
 * @Last modified by:   QingYou
 * @Last modified time: 2017-04-23
 */

import StorageKeys from '../constants/storage_keys';
import ObjectUtil from '../util/object_util';
import DataUtil from '../util/data_util';
import StorageUtil from '../storage/storage_util';
import WebUtil from '../util/web_util';
import WebConfig from '../configs/web_config';

const UserStorage = {

    userInfo: null,

    saveUserLocalInfo(object) {
        if (!object || object.length == 0) {
            return;
        }

        let userInfo = this.getUserLocalInfo() || {};
        userInfo = ObjectUtil.assign(userInfo, object);
        try {
            wx.setStorageSync(StorageKeys.USER_INFO, userInfo);
            this.userInfo = userInfo;
        } catch (e) {
            console.error(e);
        }
    },

    clearUserLocalInfo() {
        try {
            wx.removeStorageSync(StorageKeys.USER_INFO);
            this.userInfo = null;
        } catch (e) {
            console.error(e);
        }
    },

    getUserLocalInfo() {
        try {
            if (!this.userInfo) {
                this.userInfo = StorageUtil.getStorageSync(StorageKeys.USER_INFO);
            }
        } catch (e) {
            this.userInfo = null;
        }
        return this.userInfo;
    },

    getAccessToken() {
        if (WebUtil.isTest) {
            return WebUtil.getAccessToken();
        }
        const userLocalInfo = this.getUserLocalInfo();
        if (userLocalInfo) {
            return userLocalInfo.accessToken;
        }
        return null;
    },
    setAccessToken(access_token) {
        this.saveUserInfo({ access_token });
    },

    saveUserInfo(userInfo) {
        if (userInfo) {
            const accessToken = userInfo['access_token'];
            const uid = userInfo['uid'];
            const saveParam = {};
            if (uid) {
                saveParam[StorageKeys.UID] = parseInt(uid, 10).toString(36);
            }
            if (accessToken) {
                saveParam['accessToken'] = accessToken;
            }
            // 静默登录获取到的用户昵称，头像
            if (userInfo.nickName) {
                saveParam['nickName'] = userInfo.nickName;
            }
            if (userInfo.avatarUrl) {
                saveParam['avatarUrl'] = userInfo.avatarUrl;
            }
            if (userInfo.gender) {
                saveParam['gender'] = userInfo.gender;
            }
            if (userInfo.province) {
                saveParam['province'] = userInfo.province;
            }
            if (userInfo.city) {
                saveParam['city'] = userInfo.city;
            }
            if (userInfo.createTime) {
                saveParam['createTime'] = userInfo.createTime;
            }
            saveParam['is_weapp_newer'] = userInfo.is_weapp_newer;
            this.saveUserLocalInfo(saveParam);
        }
    },

    getUserId() {
        if (window) {
            return WebConfig.userInfo.testUid;
        }
        const userLocalInfo = this.getUserLocalInfo();
        if (userLocalInfo && userLocalInfo[StorageKeys.UID]) {
            return DataUtil.trans36To10(userLocalInfo[StorageKeys.UID]);
        }
        return null;
    },

    getEgrp() {
        const userLocalInfo = this.getUserLocalInfo();
        if (userLocalInfo) {
            const egrpInfo = userLocalInfo.EGRP;
            if (egrpInfo) {
                if (Date.now() < egrpInfo.expTime) {
                    return egrpInfo.value;
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }
        return null;
    },

    setEgrp(EGRP) {
        const msec = 10 * 60 * 1000; // 10分钟
        if (EGRP != null) {
            this.saveUserLocalInfo({
                EGRP: {
                    expTime: Date.now() + msec,
                    value: parseInt(EGRP, 10)
                }
            });
        }
    },

    getProvinceId() {
        const userLocalInfo = this.getUserLocalInfo();
        if (userLocalInfo) {
            const provinceInfo = userLocalInfo.provinceId;
            if (provinceInfo) {
                if (Date.now() < provinceInfo.expTime) {
                    return provinceInfo.value;
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }
        return null;
    },

    setProvinceId(provinceId) {
        const msec = 24 * 60 * 60 * 1000; // 24小时
        if (provinceId != null) {
            this.saveUserLocalInfo({
                provinceId: {
                    expTime: Date.now() + msec,
                    value: parseInt(provinceId, 10)
                }
            });
        }
    },

    setNickNameAndAvatarUrl(data) {
        data = data || {};
        const nickName = data.nickName || '';
        const avatarUrl = data.avatarUrl || '';
        const gender = data.gender || '';
        this.saveUserLocalInfo({
            nickName: nickName,
            avatarUrl: avatarUrl,
            gender: gender
        });
    }
};
export default UserStorage;
