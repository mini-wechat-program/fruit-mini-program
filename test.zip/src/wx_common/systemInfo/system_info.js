//@flow
/**
 * @Author: QingYou
 * @Filename: system_info.js
 * @Last modified by:   QingYou
 * @Last modified time: 2017-06-02
 */

let systemInfo = {

    sysInfo: null,

    getSystemInfoSync() {
        let systemInfo = this.sysInfo;
        if (!systemInfo) {
            try {
                systemInfo = wx.getSystemInfoSync();
                this.sysInfo = systemInfo;
            } catch (e) {
                systemInfo = {};
            }
        }
        return systemInfo;
    },

    getWindowWidthSync() {
        let systemInfo = this.getSystemInfoSync();
        let windowWidth = systemInfo.windowWidth || wx.getSystemInfoSync().windowWidth;
        return windowWidth;
    },

    getWindowHeightSync() {
        /**
         * 计算窗口高度的时候，systemInfo不能去取缓存的，要每次取新的，因为窗口高度有可能变化
         */
        let systemInfo = wx.getSystemInfoSync();
        let windowHeight;
        if (systemInfo) {
             windowHeight = systemInfo.windowHeight;
        }
        return windowHeight;
    },

    getSDKVersionInt() {
        let info = this.getSystemInfoSync(),
            sdkVersion = info.SDKVersion;
        if (!sdkVersion) {
            return false;
        }
       return sdkVersion.split('.').join('') * 1;
    },

    getIpxJudgment() {
        if (!this.sysInfo) {
            this.sysInfo = this.getSystemInfoSync();
        }
        return this.sysInfo.model.indexOf('iPhone X') > -1; // 这里判断model字符串里是否包含'iPhone X', 'iPhone XR', 'iPhone XS', 'iPhone XS MAX' 都会判断为true
    }
};

export default systemInfo;
