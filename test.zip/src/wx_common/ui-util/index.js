
// 小程序不支持
function getOffsetTopOnBody() {
    return 0;
}

function getWindowWidth() {
    return wx.getSystemInfoSync().windowWidth;
}

// 小程序不支持
function getScrollTop() {
    return 0;
}

// 小程序不支持传入node
function setScrollTop(value, node) {
    wx.pageScrollTo && wx.pageScrollTo({
        scrollTop: value
    })
}

export default {
    getOffsetTopOnBody,
    getWindowWidth,
    getScrollTop,
    setScrollTop,
}