import tips from './tips';

const uiManager = {
    showToast: tips.showToast,
    showConfirm2: tips.showConfirm2
};
export default uiManager;
