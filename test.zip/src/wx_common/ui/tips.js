import Taro from '@tarojs/taro';
import Toast from './toast';

export default {
    showToast(message, duration) {
        if (message.length <= 0) {
            return;
        }

        // 获取当前页面
        const pages = getCurrentPages() || [];
        const curPage = pages[pages.length - 1];
        if (curPage) {
            if (!curPage.$fruitToast) {
                curPage.$fruitToast = new Toast({
                    setDataFunc(toastData) {
                        // 给页面设置数据，以达到控制模板显示的目的
                        curPage.setData({
                            $toastInfo: toastData
                        });
                    }
                });
            }
            curPage.$fruitToast.setText(message).show({
                showDuration: duration
            });
        } else {
            // 兜底
            Taro.showToast({
                title: message || '',
                duration: duration || 1500
            });
        }
    },

    showConfirm2(opts = {}) {
        const {
            title,
            text,
            onConfirm,
            onCancel,
            confirmButtonLabel = '确认',
            cancelButtonLabel = '取消'
        } = opts;

        // 获取当前页面
        const pages = getCurrentPages() || [];
        const curPage = pages[pages.length - 1];

        if (curPage) {
            const onConfirmFunc = function() {
                this.setData({
                    ['$confirm2Data.visible']: false
                });
                typeof onConfirm === 'function' && onConfirm();
            };

            const onCancelFunc = function() {
                this.setData({
                    ['$confirm2Data.visible']: false
                });
                typeof onCancel === 'function' && onCancel();
            };

            curPage.$c2Confirm = onConfirmFunc;
            curPage.$c2Cancel = onCancelFunc;
            
            curPage.setData({
                $confirm2Data: {
                    visible: true,
                    title,
                    text,
                    confirmButtonLabel,
                    cancelButtonLabel
                }
            });
        }
    }
};