import UserStorage from '../storage/user_storage';
import AppConfig from '../configs/app_config';
import Request from '@wx_common/baseRequest/baseRequest';
import API from '../configs/api';

import {
    Message,
    KEYS
} from '../message';

const User = {
    init() {
        if (!this._initModel) {
            this.setupLisener();
            this._initModel = true;
        }
    },

    setupLisener() {
        const self = this;
        Message.on(KEYS.REQUEST_TOKEN_INVALID, function() {
            self.requireLogin();
        });
    },

    get userID() {
        if (!this.uid) {
            this.uid = UserStorage.getUserId() || 0;
        }
        return this.uid;
    },

    hasAccessToken() {
        return UserStorage.getAccessToken();
    },

    hasLogin() {
        return this.hasAccessToken();
    },

    /**
     * 获取存在本地的用户信息
     * @return {Object} 用户信息
     */
    getUserLocalInfo() {
        return UserStorage.getUserLocalInfo();
    },

    ensureLogin() {
        this.init(); // 初始化
        if (this.hasLogin()) { //如果已经登录了，直接返回
            return Promise.resolve();
        } else {
            // 进行静默登录
            return this.requireLogin();
        }
    },

    requireLogin(){
        if(!this.requireLoginPromise){
            this.requireLoginPromise = this.requireSilentLogin().then(() => {
                this.requireLogin = undefined
            }).catch((e) => {
                this.requireLogin = undefined
                throw e
            })
        }

        return this.requireLoginPromise
    },

    /**
     * 静默登录
     */
    requireSilentLogin() {
        return new Promise((resolve, reject) => {
            wx.login({
                success: (res) => {
                    if (!res.code) {
                        reject(res);
                    }
                    let code = res.code;
                    let reqParam = {
                        code: code,
                        has_auth: false,
                        app_id: AppConfig.appId
                    };
                    Request.apiRequest('POST', API.silentLogin, reqParam, data => {
                        UserStorage.saveUserInfo(data);
                        Message.emit(KEYS.USER_LOGIN_FINISHED);
                        resolve();
                    }, _ => {
                        Message.emit(KEYS.USER_LOGIN_FINISHED);
                        reject();
                    }, true)
                },
                fail: (res) => {
                    Message.emit(KEYS.USER_LOGIN_FINISHED);
                    reject(res);
                }
            });
        })
    }
};
export default User;
