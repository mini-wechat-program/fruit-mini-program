// @flow
/**
 * @Author: QingYou
 * @Filename: data_util.js
 * @Last modified by:   QingYou
 * @Last modified time: 2017-05-31
 */

'use strict';

const dataUtil = {
    isArray(o) {
        return Object.prototype.toString.call(o) === '[object Array]';
    },

    // 下划线转驼峰
    transToCamel(s) {
        if (s) {
            return s.replace(/_(\w)/g, function (all, letter) {
                return letter.toUpperCase();
            });
        }
    },

    formatByPos(formatString) {
        const args = [];
        for (let i = 1; i < arguments.length; ++i) {
            args.push(arguments[i]);
        }
        return formatString.replace(/{(\d+)}/g, function (match, index) {
            if (args[index] == null) {
                return match;
            } else {
                return args[index];
            }
        });
    },

    getLogId() {
        const logId = [
            Date.now(),
            this.getRandomString(16)
        ].join('');
        return logId;
    },

    // 生成随机字符串
    getRandomString(len) {
        len = len || 32;
        const base = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        const baseLen = base.length;
        let str = '';
        for (let i = 0; i < len; i++) {
            str += base.charAt(Math.floor(Math.random() * baseLen));
        }
        return str;
    },

    getStringCharLength(str) {
        let intLength = 0;
        for (let i = 0; i < str.length; i++) {
            if ((str.charCodeAt(i) < 0) || (str.charCodeAt(i) > 255)) {
                intLength = intLength + 2;
            } else {
                intLength = intLength + 1;
            }
        }
        return intLength;
    },

    // 处理电话号码中的不可见字符，去掉非法字符
    formatMobile(mobile) {
        let validateCode = '';
        const length = mobile.length;
        for (let i = 0; i < length; i++) {
            if (mobile.charCodeAt(i) < 255) {
                validateCode += mobile.substr(i, 1);
            }
        }
        // remove space & '-' & '+86'
        return validateCode.replace(/\s|-/g, '').replace(/^\+86/, '');
    },

    dealWithAvatarURL(avatarURL) {
        if (avatarURL == null || avatarURL == '') {
            return 'https://pinduoduoimg.yangkeduo.com/wxapp/local_group_avatar.png';
        } else if (avatarURL.substr(-2) == '/0') {
            return avatarURL.slice(0, -1) + '132';
        } else {
            return avatarURL;
        }
    },

    /**
     * 把36进制字符串转换为10进制
     */
    trans36To10(valueStr) {
        valueStr = valueStr || '';
        const base = '0123456789abcdefghijklmnopqrstuvwxyz';
        const len = base.length;
        let res = 0;
        let u = 1;
        if (valueStr.length > 0) {
            for (let i = valueStr.length - 1; i >= 0; i--) {
                res += base.indexOf(valueStr[i]) * u;
                u *= len;
            }
        }
        return res;
    },

    formatSpecs(specsString) {
        let specs = null;
        try {
            specs = JSON.parse(specsString);
        } catch (e) {
            specs = [];
        }
        if (specs && Array.isArray(specs)) {
            return specs.map(function (item) {
                if (item.spec_key && item.spec_value) {
                    return item.spec_key + ':' + item.spec_value;
                }
                return '';
            });
        }
        return [];
    },

    /**
     * 检测请求的数据是否异常
     * @param  {Object} data      请求得到的数据
     * @param  {Function} showToast 弹出toast的方法
     * @param  {Object} opts      一些选项
     * @return {Boolean}           是否数据请求出错
     */
    detectReqDataIsError(data, showToast) {
        if (data['error_code']) {
            if (typeof showToast === 'function') {
                showToast(data['error_msg']);
            }
            return true;
        }
        return false;
    },

    /**
     * 对象数组去重
     * @param  {Array} arr      请求得到的数据
     * @param  {Function} key 数组对象的唯一key
     * @filter {Function} 过滤函数
     * @param  指定过滤个数
     * @return {Array}           去重后的数组
     */
    objectArrayDuplicateRemove(arr, key, filter, count) {
        let res = [];
        const map = {};

        if (!count) { // 默认是只过滤10个
            count = Math.min(arr.length, 10);
        }

        if (count > arr.length) {
            count = arr.length;
        }
        res = arr.slice(0, arr.length - count) || [];

        for (let i = arr.length - count; i < arr.length; i++) {
            const item = arr[i];
            if (key ? map[item[key]] : map[item]) {
                continue;
            }
            if (typeof filter === 'function' && filter(item)) {
                continue;
            }
            res.push(item);
            if (key) {
                map[item[key]] = true;
            } else {
                map[item] = true;
            }
        }
        return res;
    },
    /**
     * 通过key来移除对象数组的某个对象
     * @param  {Array} arr 源数据
     * @param  {String} key 唯一键
     * @param  {String} value 要移除的key的值
     * @return {Array}      移除后的数组
     */
    removeItemByKey(arr, key, value) {
        !Array.isArray(arr) && (arr = []);
        return arr.filter((item) => {
            return item[key] != value;
        });
    },

    /**
     *
     * @param {*} arr
     * @param {*} key
     */
    ObjectArrToStringArr(arr, value, key) {
        return arr.map(function (item) {
            return item[key];
        });
    },

    checkByKey(arr, value, key) {
        if (!Array.isArray(arr)) {
            return {};
        }
        for (const item of arr) {
            if (item[key] == value) {
                return item;
            }
        }
        return {};
    },

    checkIndexByKey(arr, value, key) {
        if (!Array.isArray(arr)) {
            return;
        }
        let targetIndex;
        arr.forEach((item, index) => {
            if (item[key] == value) {
                targetIndex = index;
            }
        });
        return targetIndex;
    },
    // accMul(arg1,arg2){
    //     var m=0,s1=arg1.toString(),s2=arg2.toString();
    //     try{m+=s1.split(".")[1].length}catch(e){}
    //     try{m+=s2.split(".")[1].length}catch(e){}
    //     return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m)
    // },

    /**
     ** 加法函数，用来得到精确的加法结果
     ** 说明：javascript的加法结果会有误差，在两个浮点数相加的时候会比较明显。这个函数返回较为精确的加法结果。
     ** 调用：accAdd(arg1,arg2)
     ** 返回值：arg1加上arg2的精确结果
     **/
    accAdd(arg1, arg2) {
        let r1, r2, m, c;
        try {
            r1 = arg1.toString().split('.')[1].length;
        } catch (e) {
            r1 = 0;
        }
        try {
            r2 = arg2.toString().split('.')[1].length;
        } catch (e) {
            r2 = 0;
        }
        c = Math.abs(r1 - r2);
        m = Math.pow(10, Math.max(r1, r2));
        if (c > 0) {
            const cm = Math.pow(10, c);
            if (r1 > r2) {
                arg1 = Number(arg1.toString().replace('.', ''));
                arg2 = Number(arg2.toString().replace('.', '')) * cm;
            } else {
                arg1 = Number(arg1.toString().replace('.', '')) * cm;
                arg2 = Number(arg2.toString().replace('.', ''));
            }
        } else {
            arg1 = Number(arg1.toString().replace('.', ''));
            arg2 = Number(arg2.toString().replace('.', ''));
        }
        return (arg1 + arg2) / m;
    },

    /**
     ** 减法函数，用来得到精确的减法结果
     ** 说明：javascript的减法结果会有误差，在两个浮点数相减的时候会比较明显。这个函数返回较为精确的减法结果。
     ** 调用：accSub(arg1,arg2)
     ** 返回值：arg1加上arg2的精确结果
     **/
    accSub(arg1, arg2) {
        let r1, r2, m, n;
        try {
            r1 = arg1.toString().split('.')[1].length;
        } catch (e) {
            r1 = 0;
        }
        try {
            r2 = arg2.toString().split('.')[1].length;
        } catch (e) {
            r2 = 0;
        }
        m = Math.pow(10, Math.max(r1, r2)); // last modify by deeka //动态控制精度长度
        n = (r1 >= r2) ? r1 : r2;
        return ((arg1 * m - arg2 * m) / m).toFixed(n);
    },

    /**
     ** 乘法函数，用来得到精确的乘法结果
     ** 说明：javascript的乘法结果会有误差，在两个浮点数相乘的时候会比较明显。这个函数返回较为精确的乘法结果。
     ** 调用：accMul(arg1,arg2)
     ** 返回值：arg1乘以 arg2的精确结果
     **/
    accMul(arg1, arg2) {
        let m = 0;

        const s1 = arg1.toString();

        const s2 = arg2.toString();
        try {
            if (s1.indexOf('.') !== -1) {
                m += s1.split('.')[1].length;
            }
        } catch (e) {
            console.error(e);
        }
        try {
            if (s2.indexOf('.') !== -1) {
                m += s2.split('.')[1].length;
            }
        } catch (e) {
            console.error(e);
        }
        return Number(s1.replace('.', '')) * Number(s2.replace('.', '')) / Math.pow(10, m);
    },

    /**
     ** 除法函数，用来得到精确的除法结果
     ** 说明：javascript的除法结果会有误差，在两个浮点数相除的时候会比较明显。这个函数返回较为精确的除法结果。
     ** 调用：accDiv(arg1,arg2)
     ** 返回值：arg1除以arg2的精确结果
     **/
    accDiv(arg1, arg2) {
        let t1 = 0;

        let t2 = 0;

        let r1; let r2;
        try {
            t1 = arg1.toString().split('.')[1] ? arg1.toString().split('.')[1].length : 0;
        } catch (e) {
            console.error(e);
        }
        try {
            t2 = arg2.toString().split('.')[1] ? arg2.toString().split('.')[1].length : 0;
        } catch (e) {
            console.error(e);
        }

        r1 = Number(arg1.toString().replace('.', ''));
        r2 = Number(arg2.toString().replace('.', ''));
        return (r1 / r2) * Math.pow(10, t2 - t1);
    },
    // 非空对象
    isObject(t) {
        return t && t.toString() === '[object Object]' && Object.keys(t).length > 0;
    },

    // 针对setData到页面的变量过滤掉ad字段(针对广告商品有相应的广告字段)
    filterAdObj (data) {
        if (!Array.isArray(data)) return;
        data = data.map((item) => {
            if (!this.isObject(item)) return;

            item['ad'] && delete item['ad'];
            item['transData'] && delete item['transData'];

            return item;
        });
        return data;
    },

    // 获取商品列表的AD字段,用于埋点，不涉及setData至页面
    getAdKeyData(dataList, goodsAdData = {}) {
        dataList.forEach(item => {
            const adKeyData = {};

            // 商品列表过多的时候，每个都遍历，性能方面体验不是很好
            // 广告字段的key
            item['ad'] && (adKeyData['ad'] = item['ad']);
            item['transData'] && (adKeyData['transData'] = item['transData']);
            item['p_rec'] && (adKeyData['p_rec'] = item['p_rec']);
            item['p_search'] && (adKeyData['p_search'] = item['p_search']);

            // 当adKeyData不为空对象的时候再赋值
            if (this.isObject(adKeyData)) {
                goodsAdData[item.goodsId] = adKeyData;
            }
        });
        return goodsAdData;
    },

    // 专题2742查询，将新接口出参映射成旧接口出参
    mapResultFromNew(res) {
        const ret = {
            goods_list: [],
            server_time: res.server_time
        };
        // 新接口为goods
        if (res.goods) {
            res.goods.forEach(function(item) {
                item.group = {
                    customer_num: item.customer_num,
                    price: item.group_price
                };
                item.lucky_end_time = item.end_time;
                item.lucky_start_time = item.start_time;
                item.short_name = item.lucky_comment_rpc_vo && item.lucky_comment_rpc_vo.goods_name;
                item.thumb_url = item.hd_thumb_url;
                ret.goods_list.push(item);
            });
        } else {
            // 旧接口为goods_list
            ret.goods_list = res.goods_list;
        }
        return ret;
    },

    /**
     * js截取字符串，中英文都能用,超过自定义范围的，则用省略号表示
     * @param str：需要截取的字符串
     * @param len: 需要截取的长度
     */
    cutstr(str, len) {
        if (typeof str !== 'string') return;
        let strLength = 0; // 用于记录当前字符串截取的进度
        let strLen = 0; // 传入字符串的长度
        let strCut = new String();
        strLen = str.length;
        for (let i = 0; i < strLen; i++) {
            const a = str.charAt(i);
            strLength++;
            if (escape(a).length > 4) {
                // 中文字符的长度经编码之后大于4
                strLength++;
            }
            strCut = strCut.concat(a);
            if (strLength > len) {
                strCut = strCut.concat('...');
                return strCut;
            }
        }
        // 如果给定字符串小于指定长度，则返回源字符串
        if (strLength <= len) return str;
    },

    // 汉字算两个字符，字母数字算一个
    getByteLen(str) {
        if (str == null) return 0;
        if (typeof str !== 'string') str += '';
        let len = 0;
        for (let i = 0; i < str.length; i++) {
            const length = str.charCodeAt(i);
            if (length >= 0 && length <= 128) {
                len += 1;
            } else {
                len += 2;
            }
        }
        return len;
    }
};
export default dataUtil;
