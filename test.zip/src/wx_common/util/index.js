/**
 * @file util.js, 一些工具函数
 * @author danggui
 */
'use strict';

const CompleteLotteryHostname = 'm.ishangtong.com';

import Share from '@wx_common/constants/share';
const ShareChannel = Share.ShareChannel;

import LocalStorageKey from '@wx_common/constants/storage_keys';

import StorageUtil from '@wx_common/storage/storage_util';

/**
 * 根据传入的函数来自动执行
 *
 * @param {?Function} func, 当前要传入的要执行函数的名称
 */
export function call(func) {
    if (!func) {
        return;
    }
    const args = [];
    for (let i = 1; i < arguments.length; ++i) {
        args.push(arguments[i]);
    }
    func.apply(this, args);
}

export function format(formatString) {
    const args = [];
    for (let i = 1; i < arguments.length; ++i) {
        args.push(arguments[i]);
    }
    return formatString.replace(/{(\d+)}/g, function(match, index) {
        if (args[index] === 0) {
            return 0;
        }
        return args[index] || '';
    });
}

export function isArray(o) {
    return Object.prototype.toString.call(o) === '[object Array]';
}

export function removeArrayItem(arr, item) {
    // 只移除第一个匹配的元素
    if (isArray(item)) {
        for (let i = 0; i < item.length; i++) {
            const index = arr.indexOf(item[i]);
            if (index >= 0) {
                arr.splice(index, 1);
            }
        }
    } else {
        const index = arr.indexOf(item);
        if (index >= 0) {
            arr.splice(index, 1);
        }
    }
    return arr;
}

export function saveToLocalStorage(key, value) {
    if (key == null) {
        return;
    }
    if (value == null) {
        StorageUtil.removeStorageSync(key);
    } else {
        StorageUtil.setStorageSync(key, value);
    }
}

export function saveToSessionStorage(key, value) {
    if (key == null || typeof sessionStorage === 'undefined') {
        return;
    }
    if (value == null) {
        sessionStorage.removeItem(key);
    } else {
        sessionStorage.setItem(key, value);
    }
}

export function loadFromSessionStorage(key) {
    if (key == null || typeof sessionStorage === 'undefined') {
        return;
    }
    return sessionStorage.getItem(key);
}

export function getCookies() {
    // not supported in wxa
    return;
}

export function getCookieByName(name) {
    // not supported in wxa
    return;
}

export function setCookie(params) {
    // not supported in wxa
    return;
}

export function getRandomString(len) {
    len = len || 32;
    const base =
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const baseLen = base.length;
    let str = '';
    for (let i = 0; i < len; i++) {
        str += base.charAt(Math.floor(Math.random() * baseLen));
    }
    return str;
}

/**
 * 获取随机整数
 * @param  {(Object|number)} rangeOrDigitNum 随机整数范围或者需要生成的随机整数的位数
 * @return {number}                 随机整数
 */
export function getRandomInteger(rangeOrDigitNum) {
    let min = 0;
    let max = 0; // 注意生成的随机数是包含min和max的值的
    if (typeof rangeOrDigitNum === 'number') {
        if (rangeOrDigitNum < 1) {
            return 0;
        }
        min = Math.pow(10, rangeOrDigitNum - 1);
        max = Math.pow(10, rangeOrDigitNum) - 1;
    } else {
        rangeOrDigitNum = rangeOrDigitNum || {};
        min = rangeOrDigitNum.min || 0;
        max = rangeOrDigitNum.max || 0;
    }
    return Math.floor(Math.random() * (max - min + 1) + min);
}

export function getUIDback_(uid) {
    uid = uid || '';
    const base = '0123456789abcdefghijklmnopqrstuvwxyz';
    const len = base.length;
    let res = 0;
    let u = 1;
    if (uid.length > 0) {
        for (let i = uid.length - 1; i >= 0; i--) {
            res += base.indexOf(uid[i]) * u;
            u *= len;
        }
    }
    return res;
}

export function getSelfUID() {
    const uidBase36 = StorageUtil.getStorageSync(LocalStorageKey.UID);
    // fix bad case
    if ((uidBase36 || '').toString().match(/[0-9]{10}/)) {
        StorageUtil.setStorageSync(
            LocalStorageKey.UID,
            parseInt(uidBase36, 10).toString(36)
        );
        return uidBase36;
    }
    return getUIDback_(uidBase36);
}

export function getValueFromUserAgent(key, userAgent = '') {
    // not supported in wxa
    return;
}

export function pick(obj, keys = []) {
    obj = obj || {};
    return keys.reduce((result, key) => {
        const val = obj[key];
        if (val !== undefined) {
            result[key] = val;
        }
        return result;
    }, {});
}

export function isEmptyObject(obj) {
    return Object.keys(obj).length === 0;
}

export function httpsSafe(url) {
    if (!url) {
        return url;
    }
    let isHybrid = false;
    // if (process.env.BROWSER) {
    //     // 前端渲染
    //     isHybrid = !(location || {}).href.match(/^https?:/); // 判断组件包页面的方法：href开头是否为/^https?:/
    //     // 后端渲染一定不是组件包页面
    // }
    // 组件包页面全部使用http:协议
    // 非组件包页面全部使用相对协议
    return url.replace(/^https?:\/\//, isHybrid ? 'http://' : '//'); // 将页面协议卸载成相对协议
}

/**
 * 获得avatar url
 *
 * @param {string} url, 当前avatar image的url
 * @param {string} logo, 默认的logo
 * @param {number} width, 需要修改的图片宽度
 *
 * @return {string}
 */
export function getAvatarURL(url, logo, width) {
    url = httpsSafe(url || '');
    width = width || 100;

    if (url.length === 0) {
        return httpsSafe(logo);
    } else if (url.indexOf('avatar.yangkeduo.com') >= 0) {
        return [
            url.split('?')[0],
            'x-oss-process=image/resize,w_' + width
        ].join('?');
    } else if (url.substr(-2, 2) === '/0') {
        return url.substring(0, url.length - 1) + '132';
    }

    return url;
}

/**
 * 扩展一个object
 *
 */
export function extend() {
    const res = {};
    for (let i = 0; i < arguments.length; i++) {
        if (typeof arguments[i] === 'object') {
            for (const key in arguments[i]) {
                if (key != null && arguments[i].hasOwnProperty(key)) {
                    res[key] = arguments[i][key];
                }
            }
        }
    }
    return res;
}

export function merge(src, target) {
    if (
        src == 'undefined' ||
        src == null ||
        target == 'undefined' ||
        target == null
    ) {
        return target;
    }
    for (const skey in src) {
        if (isArray(src[skey])) {
            target[skey] = src[skey].concat();
        } else if (typeof src[skey] === 'object') {
            if (target[skey] == 'undefined' || target[skey] == null) {
                target[skey] = {};
            }
            merge(src[skey], target[skey]);
        } else if (typeof src[skey] === 'function') {
        } else {
            target[skey] = src[skey];
        }
    }
    return target;
}

/**
 * 用于快速为分享绑定同一回调
 * @param {Object} shareInfo config
 * @param {Function} onFinish 对所有分享结果（成功或失败），只需传入onFinish
 * @param {Function} onSuccess/onFail 只对成功或失败，onFinish为null 传入onSucc 和 onFail
 * @param {Object} params: 使用自定义回调返回的result, 如{qqShareSuccess:{platform:'QQ'}},则在成功分享QQ后会得到{platform:'QQ'}的返回;
 * 如不添加，默认返回对应channel
 * @param {Object} given: 为特定分享结果绑定指定回调
 **/
export function bindShareCallback(
    shareInfo,
    onFinish,
    onSuccess,
    onFail,
    params,
    given
) {
    const finalShareInfo = shareInfo || {};
    const success = function(result) {
        if (onFinish) {
            onFinish(result);
        } else if (onSuccess) {
            onSuccess(result);
        }
    };
    const fail = function(result) {
        if (onFinish) {
            onFinish(result);
        } else if (onFail) {
            onFail(result);
        }
    };
    const givenParams = params || {};
    const shareSuccess = {
        appMessageShareSuccess: ShareChannel.AppMessage,
        timelineShareSuccess: ShareChannel.Timeline,
        qqShareSuccess: ShareChannel.QQ,
        qqZoneShareSuccess: ShareChannel.QQZone,
        qqWeiboShareSuccess: ShareChannel.QQWeibo,
        sinaWeiboShareSuccess: ShareChannel.SinaWeibo
    };
    const shareFail = {
        appMessageShareCancel: ShareChannel.AppMessage,
        timelineShareCancel: ShareChannel.Timeline,
        qqShareCancel: ShareChannel.QQ,
        qqZoneShareCancel: ShareChannel.QQZone,
        qqWeiboShareCancel: ShareChannel.QQWeibo,
        sinaWeiboShareCancel: ShareChannel.SinaWeibo
    };
    if (onFinish || onSuccess) {
        for (const sKey in shareSuccess) {
            finalShareInfo[sKey] = (function(key) {
                return function() {
                    success(givenParams[key] || shareSuccess[key]);
                };
            })(sKey);
        }
    }
    if (onFinish || onFail) {
        for (const fKey in shareFail) {
            finalShareInfo[fKey] = (function(key) {
                return function() {
                    fail(givenParams[key] || shareFail[key]);
                };
            })(fKey);
        }
    }
    if (given) {
        for (const key in given) {
            finalShareInfo[key] = given[key];
        }
    }
    return finalShareInfo;
}

/**
 * @param {Object} obj
 * @param {String} sep1 seperator for key-value
 * @param {String} sep2 seperator for each prop
 */
export function joinObjKeyAndValue(obj, sep1, sep2) {
    if (!obj || !sep1 || !sep2) {
        return null;
    }
    const array = [];
    for (const key in obj) {
        if (typeof obj[key] === 'string' || typeof obj[key] === 'number') {
            array.push(key.toString() + sep1 + obj[key]);
        }
    }
    return array.join(sep2);
}

export function isFunc(func) {
    return typeof func === 'function';
}

export function isFunction(func) {
    return isFunc(func);
}

export function getStringCharLength(str) {
    let intLength = 0;
    for (let i = 0; i < str.length; i++) {
        if (str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255) {
            intLength = intLength + 2;
        } else {
            intLength = intLength + 1;
        }
    }
    return intLength;
}

export function utfStrTruncation(str, num, endMark) {
    endMark = endMark || '...';
    const allNum = getStringCharLength(str);

    if (allNum <= num) {
        return str;
    }

    let result = str;
    const tempNum = 0;

    for (let i = 0, tempNum = 0; i < str.length; i++) {
        if (str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255) {
            tempNum += 2;
        } else {
            tempNum += 1;
        }
        if (tempNum > num) {
            result = str.slice(0, i) + endMark;
            break;
        }
    }

    return result;
}

export function compareVersion(version1, version2) {
    const toIntArray = function(version) {
        const ret = [];

        if (version == null || version.length <= 0) {
            return ret;
        }

        version.split('.').forEach(function(token) {
            ret.push(parseInt(token));
        });

        return ret;
    };
    const parts1 = toIntArray(version1);
    const parts2 = toIntArray(version2);
    const length = Math.max(parts1.length, parts2.length);

    for (let i = 0; i < length; ++i) {
        const part1 = parseInt(parts1[i] || '0');
        const part2 = parseInt(parts2[i] || '0');

        if (part1 != part2) {
            return part1 - part2;
        }
    }
    return 0;
}

export function getWechatVersion(userAgent = '') {
    if (!userAgent) {
        return wx.getSystemInfoSync().version;
    }
    let version = getValueFromUserAgent('micromessenger/', userAgent);

    if (version === null) {
        version = '';
    }

    return version;
}

/**
 * Note that callback is call only if all animations finish with no interruption.
 *
 * @param nodes the JQuery nodes to be animated.
 */
export function animate(nodes, params, duration, callback) {
    // not supported in wxa
    return;
}

export function getCompleteLotteryHostname(hostname) {
    if (['m.hutaojie.com', 'panduoduo.yangkeduo.com'].indexOf(hostname) >= 0) {
        return hostname;
    }
    return CompleteLotteryHostname;
}

export default {
    call,
    format,
    isArray,
    removeArrayItem,
    saveToLocalStorage,
    saveToSessionStorage,
    loadFromSessionStorage,
    getCookies,
    getCookieByName,
    setCookie,
    getRandomString,
    getRandomInteger,
    getUIDback_,
    getSelfUID,
    getValueFromUserAgent,
    pick,
    isEmptyObject,
    getAvatarURL,
    extend,
    merge,
    bindShareCallback,
    joinObjKeyAndValue,
    isFunc,
    isFunction,
    getStringCharLength,
    utfStrTruncation,
    compareVersion,
    getWechatVersion,
    animate,
    getCompleteLotteryHostname
};
