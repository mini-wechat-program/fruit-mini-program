// @flow
'use strict';

const ObjectUtil = {

    /**
     * 该方法只会拷贝源对象自身的并且可枚举的属性到目标对象身上，注意该方法为浅拷贝
     * @params {object} target 目标对象
     * @params ...sources 任意多个源对象
     */
    assign(target) {
        if (typeof Object.assign !== 'function') {
            if (target == null) {
                throw new TypeError('Cannot convert undefined or null to object');
            }

            target = Object(target);
            for (let index = 1; index < arguments.length; index++) {
                const source = arguments[index];
                if (source != null) {
                    for (const key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
            }
            return target;
        } else {
            return Object.assign(...arguments);
        }
    },
    clone: function(obj) {
        const _this = this;

        function deepClone(obj) {
            const _obj = {};
            for (const key in obj) {
                if (obj[key] instanceof Array) {
                    _obj[key] = _this.cloneArray(obj[key]);
                    continue;
                }
                if (obj.hasOwnProperty(key) && typeof obj[key] !== 'object') {
                    _obj[key] = obj[key];
                }
                if (obj.hasOwnProperty(key) && typeof obj[key] === 'object') {
                    _obj[key] = deepClone(obj[key]);
                }
            }
            return _obj;
        }
        return deepClone(obj);
    },
    cloneArray: function(arr) {
        const len = arr.length;

        const arrNew = [];
        for (let i = 0; i < len; i++) {
            arrNew[i] = this.clone(arr[i]);
        }
        return arrNew;
    }
};
export default ObjectUtil;
