//@flow
/**
 * page相关的帮助量
 * @Author: QingYou
 * @Filename: page_util.js
 * @Last modified by:   QingYou
 * @Last modified time: 2017-05-11
 */

import { PageInfo } from '../constants/page';
import UrlUtil from './url_util';
import ObjectUtil from './object_util';

let pageInfos = {};

export default {

    /**
     * 获取当前页面
     * @return {Object} 当前页面
     */
    getCurPage() {
        let pages = getCurrentPages();
        let curPage = {};
        if (pages.length > 0) {
            curPage = pages[pages.length - 1] || {};
        }
        return curPage;
    },

    /**
     * 从URL查询参数中获取埋点需要的keyParams
     */
    getKeyParamsFromQuery(curPage) {
        if (!curPage) {
            curPage = this.getCurPage();
        }

        // 查询参数对象
        let query = curPage.$urlQueryObj || {};
        let pageKey = this.getCurPageKey();
        let pvInfos = (PageInfo[pageKey] || {}).pv || {};
        let params = {};
        (pvInfos.keys || []).forEach(function (item) {
            let key, value;
            if (typeof item === 'string') {
                key = item;
                value = query[key];
            } else if (typeof item === 'object') {
                key = item.key;
                value = query[key];
                if (value == null && item.default != null) {
                    value = item.default;
                }
            }
            if (key != null && value != null) {
                params[key] = value;
            }
        });
        return params;
    },

    /**
     * 获取埋点需要的keyParams
     */
    getKeyParams() {
        let curPage = this.getCurPage();
        let trackingKeyParams = curPage.$trackingKeyParams || {};
        let keyParamsFromQuery = this.getKeyParamsFromQuery(curPage) || {};
        return ObjectUtil.assign(keyParamsFromQuery, trackingKeyParams);
    },

    /**
     * 获取当前页面的page name
     */
    getCurPageName() {
        let pageKey = this.getCurPageKey() || '';
        return (PageInfo[pageKey] || {}).pageName || pageKey;
    },

    /**
     * 获取当前页面的page key
     */
    getCurPageKey() {
        let pageKey = '';
        let curRoute = this.getCurPageRoute();
        let routesSplit = curRoute.split('/');
        if (routesSplit.length > 0) {
            pageKey = routesSplit[routesSplit.length - 1];
        }
        pageKey = pageKey === 'subjects_new' ? 'subjects' : pageKey;    // 中间层灰度期间，专题集页面存在两套，埋点时subjects_new应该替换成subjects
        return pageKey;
    },

    /**
     * 获取当前页面的完整路径(包含查询参数)
     * @return {String} 页面路径
     */
    getCurPageFullPath() {
        let curPage = this.getCurPage();
        let curRoute = curPage['__route__'] || '';
        return curRoute + '?' + UrlUtil.buildQuery(curPage.$urlQueryObj || {});
    },

    /**
     * 获取当前页面的查询参数对象
     */
    getCurPageQueryObj() {
        let curPage = this.getCurPage();
        return curPage.$urlQueryObj || {};
    },

    /**
     * 获取当前页面的路由（除去查询参数）
     * @return {String} 当前页面的路由（除去查询参数）
     */
    getCurPageRoute() {
        let curPage = this.getCurPage() || {};
        return curPage['__route__'] || '';
    },

    getPageInfo(key) {
        if (!pageInfos[key]) {
            pageInfos[key] = {};
        }
        return pageInfos[key];
    },

    removePageInfo(fullPath) {
        delete pageInfos[fullPath];
    }
};
