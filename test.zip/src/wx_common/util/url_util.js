//@flow
let urlUtil = {
    buildQuery(params, encode = true) {

        if (typeof params === 'string') {
            return params;
        }

        let paramsPairs = {};
        if (params) {
            for (let key in params) {
                let value = params[key];
                if (key != null && value != null) {
                    if (encode) {
                        paramsPairs[encodeURIComponent(key)] = encodeURIComponent(value);
                    } else {
                        paramsPairs[key] = value;
                    }
                }
            }
        }
        let res = '';
        for (let key in paramsPairs) {
            if (res.length > 0) {
                res += '&';
            }
            res += key + '=' + paramsPairs[key];
        }
        return res;
    },

    /**
     * decode查询参数
     */
    parseQuery(params) {
        let decodeParams = {};
        if (!params) {
            return params;
        }
        for (let key in params) {
            decodeParams[decodeURIComponent(key)] = decodeURIComponent(params[key]).trim();
        }
        return decodeParams;
    },

    /**
     * decodeURL查询字符串
     */
    parseUrlQueryStr(search) {
        let queries = {};
        let tokens = search.split('&');

        for (let i = 0; i < tokens.length; ++i) {
            let pair = tokens[i].split('=');

            if (pair[0] != null && pair[0].length > 0) {
                let value = pair[1] || '';
                queries[decodeURIComponent(pair[0])] = decodeURIComponent(value);
            }
        }
        return queries;
    },

    filterLink(url, fallback, filterArea) {
        let urlPart = url.trim().split('//');
        let name = urlPart[0].split('.')[0];
        if (urlPart.length > 1) {
            name = urlPart[1].split('/')[1].split('.')[0];
        }

        let pageData = ['subject', 'subjects', 'subjects_new', 'goods', 'mall_page', 'spike', 'brand_spike'];
        if (filterArea && filterArea.length > 0) {
            pageData = filterArea;
        }

        if (pageData.indexOf(name) < 0) {
            return fallback ? 'spike' : '';
        }

        return name;
    },

    urlDraw(url) {
        let paramObj = {};
        if (!url) {
            return paramObj;
        }

        url = url.trim();  //去掉首尾空格
        let paramString = url.split('?').length > 1 ? url.split('?')[1] : '';
        if (paramString) {
            let paramArr = paramString.split('&');
            paramArr.forEach((key) => {
                paramObj[key.split('=')[0]] = key.split('=')[1];
            });
        }
        return paramObj;
    },

    /**
     * 接收标准url格式protocol :// hostname[:port] / path / [;parameters][?query]#fragment和需要添加的参数，指定添加规则，生成新的url
     * @param oldUrl {string} 接收标准url格式protocol :// hostname[:port] / path / [;parameters][?query]#fragment,其中每一部分均可省略
     * @param params {object, string} 接受string格式的query或者query解析出来的对象，添加到原url中
     * @param options {object} 指定添加参数时的可选操作项。replace指定新增加的参数和原有参数相同时，是否使用新参数值替代，默认为true；isEncode指定原url的参数是否编码过，默认为false；encode指定是否对新组成的url参数编码，默认为false
     * @return {string} 返回由原url和新加参数组成的新url
     * @example
     * // returns '/package_d/subjects/subjects?subjects_id=15&refer_page_el_sn=99290'
     * getNewUrlWithParams('/package_d/subjects/subjects?subjects_id=15', {refer_page_el_sn: 99290});
     * @example
     * // returns '/package_d/subjects/subjects?refer_page_el_sn=99290&subjects_id=15&refer_page_url=pages%2Findex%2Findex'
     * getNewUrlWithParams('/package_d/subjects/subjects?subjects_id=15', {refer_page_el_sn: 99290, subjects_id: 14, refer_page_url : 'pages/index/index'}, {replace: false, encode: true});
     * @example
     * // returns '/package_d/subjects/subjects?subjects_id=15&refer_page_url=pages/index/index&refer_page_el_sn=99290'
     * getNewUrlWithParams('/package_d/subjects/subjects?subjects_id=15&refer_page_url=pages%2Findex%2Findex', {refer_page_el_sn: 99290}, {isEncode: true});
     */
    getNewUrlWithParams(oldUrl = '', params, options = {}) {
        if (typeof (oldUrl) !== 'string') {
            return oldUrl;
        }

        let {replace = true, isEncode = false, encode = false} = {...options},
            [baseUrl, oldQuerysAndFragments = ''] = oldUrl.trim().split('?'),
            [oldQuerys = '', fragments = ''] = oldQuerysAndFragments.split('#'),
            oldQueryObj = isEncode ? this.parseUrlQueryStr(oldQuerys) : this.getObjFromParamString(oldQuerys),
            addQueryObj = typeof (params) === 'object' ? params : this.getObjFromParamString(params),
            queryObj = replace ? {...oldQueryObj, ...addQueryObj} : {...addQueryObj, ...oldQueryObj},
            queryParams = this.buildQuery(queryObj, encode);

        fragments = fragments ? `#${fragments}` : '';
        if (queryParams) {
            return `${baseUrl}?${this.buildQuery(queryObj, encode)}${fragments}`;
        } else {
            return `${baseUrl}${fragments}`;
        }
    },

    getObjFromParamString(paramString) {
        let paramObj = {};
        if (paramString) {
            let paramArr = paramString.split('&');
            paramArr.forEach((key) => {
                paramObj[key.split('=')[0]] = key.split('=')[1];
            });
        }
        return paramObj;
    },

    /**
     * @param {String} targetPage h5 Url
     * @param {String} options 相关参数
     * @param {String} revealUrl 兜底Url
     */
    h5UrlMapping(targetPage, options, revealUrl) {
        let pageUrl;
        if (/goods2?\.html/.test(targetPage)) {
            pageUrl = '/package_c/goods/goods?' + this.buildQuery(options);
        } else if (/subjects\.html/.test(targetPage)) {
            let subjectsId = options.subjects_id;
            if (subjectsId == 17) {
                let htmlUrl = targetPage + "?subjects_id=" + subjectsId;
                pageUrl = '/pages/web/web?specialUrl=1&src=' + encodeURIComponent(htmlUrl);
            } else {
                pageUrl = '/package_d/subjects/subjects?subjects_id=' + subjectsId;
            }
        } else if (/subject\.html/.test(targetPage)) {
            pageUrl = '/package_d/subject/subject?' + this.buildQuery(options);
        } else if (/brand_spike\.html/.test(targetPage)) {
            pageUrl = '/package_a/brand_spike/brand_spike?' + this.buildQuery(options);
        } else if (/spike\.html/.test(targetPage)) {
            pageUrl = '/package_a/spike/spike?' + this.buildQuery(options);
        } else if (/order_checkout\.html/.test(targetPage)) {
            pageUrl = '/package_c/order_checkout/order_checkout?' + this.buildQuery(options);
        } else if (/orders\.html/.test(targetPage)) {
            pageUrl = '/package_e/orders/orders';
        } else if (/order\.html/.test(targetPage)) {
            pageUrl = '/package_a/order/order?ordersn=' + options.order_sn;
        }  else if (/mall_page\.html/.test(targetPage)) {
            pageUrl = '/package_a/mall_page/mall_page?' + this.buildQuery(options);
        } else if (/coupons\.html/.test(targetPage)) {
            pageUrl = '/package_e/coupons/coupons';
        } else if (/personal\.html/.test(targetPage)) {
            pageUrl = '/pages/personal/personal';
        } else if (/chat_detail\.html/.test(targetPage) || /chat_detail_logistics\.html/.test(targetPage)) {
            pageUrl = '/package_a/custom_service/custom_service?' + this.buildQuery(options);
        } else if (/group\d*.html/.test(targetPage)) {
            pageUrl = '/package_c/group/group?' + this.buildQuery(options);
        } else if (/comm_brand_page\.html/.test(targetPage)) {
            pageUrl = '/package_a/mall_page/mall_page?is_brand=true&' + this.buildQuery(options);
        } else if (/catgoods\.html/.test(targetPage)) {
            pageUrl = '/package_a/catgoods/catgoods?' + this.buildQuery(options);
        } else if (/psnl_coupon_center\.html/.test(targetPage)) {
            pageUrl = '/package_a/coupon_center/coupon_center?' + this.buildQuery(options);
        } else {
            pageUrl = revealUrl;
        }
        return pageUrl;
    }

};
export default urlUtil;
