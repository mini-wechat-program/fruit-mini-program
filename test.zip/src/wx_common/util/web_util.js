import WebConfig from '../configs/web_config';
// import AppConfig from '../configs/app_config';
export default {
    isTest: WebConfig.isTest,
    getAccessToken() {
        return WebConfig.userInfo.accessToken;
    },
    requirerLogin(successCallback) {
        typeof successCallback === 'function' && successCallback(WebConfig.userInfo, WebConfig.loginExtraInfo);
    },
    getUserInfo(callback) {
        callback && callback(true, WebConfig.userInfo);
    },
    getGZToken() {
        return WebConfig.userInfo.gzToken;
    }
};

// https://wxapp.yangkeduo.com/hawaii/likes?page_name=likes&app_name=yangkeduo&token=0d1547d6f428505daf4e947c5b458188527a4a86
